-- MySQL dump 10.13  Distrib 8.4.8-8, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: axisrym
-- ------------------------------------------------------
-- Server version	8.4.8-8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `access_logs`
--

DROP TABLE IF EXISTS `access_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `recorded_by` bigint unsigned NOT NULL,
  `qr_code_id` bigint unsigned DEFAULT NULL,
  `visitor_id` bigint unsigned DEFAULT NULL,
  `type` enum('entry','exit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `visitor_type` enum('pedestrian','vehicle') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pedestrian',
  `visit_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vehicle_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `visitor_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `plate_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo_plate_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo_exit_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `entry_log_id` bigint unsigned DEFAULT NULL,
  `gate_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_logs_unit_id_foreign` (`unit_id`),
  KEY `access_logs_recorded_by_foreign` (`recorded_by`),
  KEY `access_logs_qr_code_id_foreign` (`qr_code_id`),
  KEY `access_logs_visitor_id_foreign` (`visitor_id`),
  KEY `condominium_id_created_at` (`condominium_id`,`created_at`),
  CONSTRAINT `access_logs_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `access_logs_qr_code_id_foreign` FOREIGN KEY (`qr_code_id`) REFERENCES `qr_codes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `access_logs_recorded_by_foreign` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `access_logs_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `access_logs_visitor_id_foreign` FOREIGN KEY (`visitor_id`) REFERENCES `visitors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_logs`
--

LOCK TABLES `access_logs` WRITE;
/*!40000 ALTER TABLE `access_logs` DISABLE KEYS */;
INSERT INTO `access_logs` VALUES (2,2,297,6,10,NULL,'entry','vehicle',NULL,NULL,'tae','','writable/uploads/access/id_1774660882_1774660882_75202f41dbcc2e6089dd.jpg','writable/uploads/access/plate_1774660882_1774660882_a9894c144084672fcd5b.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-03-28 01:21:22'),(3,2,297,6,10,NULL,'exit','vehicle',NULL,NULL,'tae','',NULL,NULL,NULL,2,'Caseta Principal','Salida registrada por guardia','2026-03-28 18:31:33'),(4,2,296,6,NULL,NULL,'entry','',NULL,NULL,'Tiffani',NULL,'writable/uploads/access/id_1774814208_1774814208_7a862d97d16d76895c01.jpg','writable/uploads/access/plate_1774814208_1774814208_8d0a829b123cafc84eb7.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Visita. Vehículo: Auto.','2026-03-29 13:56:48'),(5,2,296,6,NULL,NULL,'exit','',NULL,NULL,'Tiffani',NULL,NULL,NULL,NULL,4,'Caseta Principal','Salida registrada por guardia','2026-03-29 13:57:33'),(6,2,297,6,NULL,NULL,'entry','',NULL,NULL,'PEPE',NULL,'writable/uploads/access/id_1774814311_1774814311_13b22755a77e923b41c3.jpg','writable/uploads/access/plate_1774814311_1774814311_34f30a487304047fe253.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Motocicleta.','2026-03-29 13:58:31'),(7,2,297,6,NULL,NULL,'entry','',NULL,NULL,'PAU',NULL,'writable/uploads/access/id_1774814385_1774814385_f6be538056c68124c354.jpg','writable/uploads/access/plate_1774814385_1774814385_2865feac3a703514cd36.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Entrega de paquetería. Vehículo: Auto.','2026-03-29 13:59:45'),(8,2,296,6,NULL,NULL,'entry','vehicle','Residente','Auto','YUTE',NULL,'writable/uploads/access/id_1774814755_1774814755_7d7d07688f163c689f05.jpg','writable/uploads/access/plate_1774814755_1774814755_d970cc1448260459b4dd.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-03-29 14:05:55'),(9,2,297,6,NULL,NULL,'exit','',NULL,NULL,'PEPE',NULL,NULL,NULL,NULL,6,'Caseta Principal','Salida registrada por guardia','2026-03-29 14:15:49'),(10,2,297,6,NULL,NULL,'exit','',NULL,NULL,'PAU',NULL,NULL,NULL,NULL,7,'Caseta Principal','Salida registrada por guardia','2026-03-29 14:16:14'),(11,2,296,6,NULL,NULL,'exit','vehicle',NULL,NULL,'YUTE',NULL,NULL,NULL,NULL,8,'Caseta Principal','Salida registrada por guardia','2026-03-29 15:49:05'),(12,2,297,6,NULL,NULL,'entry','vehicle','Residente','Auto','ARACELI',NULL,'writable/uploads/access/id_1774851735_1774851735_0b3039dad3627833e86f.jpg','writable/uploads/access/plate_1774851735_1774851735_653d82aa1ab1f08033c9.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-03-30 00:22:15'),(13,2,297,6,NULL,NULL,'entry','pedestrian','Proveedor de servicios','Sin vehículo','LEO',NULL,NULL,NULL,NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Proveedor de servicios. Vehículo: Sin vehículo.','2026-03-30 00:33:33'),(14,2,297,6,NULL,NULL,'exit','pedestrian',NULL,NULL,'LEO',NULL,NULL,NULL,NULL,13,'Caseta Principal','Salida registrada por guardia','2026-03-30 12:45:22'),(15,2,297,13,NULL,NULL,'exit','vehicle',NULL,NULL,'ARACELI',NULL,NULL,NULL,NULL,12,'Caseta Principal','Salida registrada por guardia','2026-03-30 13:56:25'),(16,2,296,6,13,NULL,'entry','vehicle',NULL,NULL,'FRODO','','writable/uploads/access/id_1774902660_1774902660_9e03f0894f6f540967af.jpg','writable/uploads/access/plate_1774902660_1774902660_e11f3a42f671f5596b21.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-03-30 14:31:00'),(17,2,296,6,13,NULL,'exit','vehicle',NULL,NULL,'FRODO','',NULL,NULL,NULL,16,'Caseta Principal','Salida registrada por guardia','2026-03-30 15:07:28'),(18,2,296,6,NULL,NULL,'entry','vehicle','Visita','Auto','Daniel ',NULL,'writable/uploads/access/id_1774904900_1774904900_3597d60277fd9f5fb60a.jpg','writable/uploads/access/plate_1774904900_1774904900_b157d1e23b38330076f8.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Visita. Vehículo: Auto.','2026-03-30 15:08:20'),(19,2,296,6,NULL,NULL,'exit','vehicle',NULL,NULL,'Daniel ',NULL,NULL,NULL,'writable/uploads/access/exit_1774905149_1774905149_a169277b64bc1d2dc765.jpg',18,'Caseta Principal','Salida registrada por guardia','2026-03-30 15:12:29'),(20,2,296,6,19,NULL,'entry','vehicle',NULL,NULL,'tat','','writable/uploads/access/id_1775098668_1775098668_700a21620aea3f029a27.jpg','writable/uploads/access/plate_1775098668_1775098668_5a3de6825ed702cb0da9.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-01 20:57:48'),(21,2,296,6,19,NULL,'exit','vehicle',NULL,NULL,'tat','',NULL,NULL,'writable/uploads/access/exit_1775098750_1775098750_7ca89d96ae31976fa7a0.jpg',20,'Caseta Principal','Salida registrada por guardia','2026-04-01 20:59:10'),(22,2,296,6,18,NULL,'entry','vehicle',NULL,NULL,'ARTURO','','writable/uploads/access/id_1775113831_1775113831_0ffd5c9fc7d37d094e3f.jpg','writable/uploads/access/plate_1775113831_1775113831_6be8aa3ff75e37e99af1.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-02 01:10:31'),(23,2,296,6,18,NULL,'exit','vehicle',NULL,NULL,'ARTURO','',NULL,NULL,'writable/uploads/access/exit_1775113866_1775113866_7c9a78ddeb13b407bc74.jpg',22,'Caseta Principal','Salida registrada por guardia','2026-04-02 01:11:06'),(24,2,296,6,18,NULL,'entry','vehicle',NULL,NULL,'ARTURO','','writable/uploads/access/id_1775113935_1775113935_3ff3c00c463fc26f3aff.jpg','writable/uploads/access/plate_1775113935_1775113935_0baf81b6910df447bfa5.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-02 01:12:15'),(25,2,296,14,18,NULL,'exit','vehicle',NULL,NULL,'ARTURO','',NULL,NULL,'writable/uploads/access/exit_1775503659_1775503659_c9c0eb4cee0ab42c2608.jpg',24,'Caseta Principal','Salida registrada por guardia','2026-04-06 13:27:39'),(26,2,419,14,NULL,NULL,'entry','vehicle','Visita','Auto','ADRIAN',NULL,'writable/uploads/access/id_1775505668_1775505668_ba0d978481d52c088ef3.jpg','writable/uploads/access/plate_1775505668_1775505668_8da73136b41ae52cb7b2.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Visita. Vehículo: Auto.','2026-04-06 14:01:08'),(27,2,419,14,NULL,NULL,'exit','vehicle',NULL,NULL,'ADRIAN',NULL,NULL,NULL,'writable/uploads/access/exit_1775516237_1775516237_fb0994f191b1552767e4.jpg',26,'Caseta Principal','Salida registrada por guardia','2026-04-06 16:57:17'),(28,2,297,14,NULL,NULL,'entry','vehicle','Residente','Auto','PEPE',NULL,'writable/uploads/access/id_1775669049_1775669049_f66eaf5c95fc79323cfb.jpg','writable/uploads/access/plate_1775669049_1775669049_2e6566ffaf82e658a4ac.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-04-08 11:24:09'),(29,2,297,14,NULL,NULL,'exit','vehicle',NULL,NULL,'PEPE',NULL,NULL,NULL,'writable/uploads/access/exit_1775687992_1775687992_8c4f47f14f51edd1801e.jpg',28,'Caseta Principal','Salida registrada por guardia','2026-04-08 16:39:52'),(30,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','juan',NULL,'writable/uploads/access/id_1775756347_1775756347_3bdc4e48b7b256ad8172.jpg','writable/uploads/access/plate_1775756347_1775756347_d469748035e0dcd11fb1.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-04-09 11:39:07'),(31,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'juan',NULL,NULL,NULL,'writable/uploads/access/exit_1775761639_1775761639_0061c60c87fbe567c55a.jpg',30,'Caseta Principal','Salida registrada por guardia','2026-04-09 13:07:19'),(32,2,297,14,NULL,NULL,'entry','vehicle','Residente','Auto','PACO ROJAS',NULL,'writable/uploads/access/id_1775782452_1775782452_92222d72f923edd26d21.jpg','writable/uploads/access/plate_1775782452_1775782452_2997a1772e1d6fbe6ecf.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-04-09 18:54:12'),(33,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','PACO',NULL,NULL,NULL,NULL,NULL,'Caseta Principal','[App Flutter] Motivo: Residente. Vehículo: Auto.','2026-04-09 19:42:26'),(34,2,296,14,NULL,NULL,'entry','vehicle','Visita','Auto','mauro ',NULL,'writable/uploads/access/id_1775787954_1775787954_6486481bd497c59f4399.jpg','writable/uploads/access/plate_1775787954_1775787954_e44326ac43a407c33294.jpg',NULL,NULL,'Caseta Principal','[App Flutter] Motivo: Visita. Vehículo: Auto.','2026-04-09 20:25:54'),(38,2,419,14,21,NULL,'entry','vehicle',NULL,NULL,'ANGELES','','writable/uploads/access/id_1775788994_1775788994_23c8fbbc7d3819391bed.jpg','writable/uploads/access/plate_1775788994_1775788994_967b40f74ded12e0d8ad.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-09 20:43:14'),(39,2,419,14,21,NULL,'entry','vehicle',NULL,NULL,'ANGELES','',NULL,NULL,NULL,NULL,'Caseta Principal',NULL,'2026-04-09 21:24:57'),(40,2,419,14,21,NULL,'exit','vehicle',NULL,NULL,'ANGELES','',NULL,NULL,'writable/uploads/access/exit_1775791789_1775791789_7d894f3e2059ada6d0d1.jpg',39,'Caseta Principal','Salida registrada por guardia','2026-04-09 21:29:49'),(41,2,297,14,NULL,NULL,'exit','vehicle',NULL,NULL,'PACO ROJAS',NULL,NULL,NULL,'writable/uploads/access/exit_1775791804_1775791804_1c020eb1578e4c5d82e9.jpg',32,'Caseta Principal','Salida registrada por guardia','2026-04-09 21:30:04'),(42,2,419,14,21,NULL,'exit','vehicle',NULL,NULL,'ANGELES','',NULL,NULL,'writable/uploads/access/exit_1775792007_1775792007_163cd5a3fdff0f45ccc0.jpg',38,'Caseta Principal','Salida registrada por guardia','2026-04-09 21:33:27'),(43,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'mauro ',NULL,NULL,NULL,'writable/uploads/access/exit_1775792028_1775792028_9f3688f1e607617caeb2.jpg',34,'Caseta Principal','Salida registrada por guardia','2026-04-09 21:33:48'),(44,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'PACO',NULL,NULL,NULL,'writable/uploads/access/exit_1775792044_1775792044_a5ad51e235a97f112ecd.jpg',33,'Caseta Principal','Salida registrada por guardia','2026-04-09 21:34:04'),(45,2,297,14,20,NULL,'entry','vehicle',NULL,NULL,'Arturo','','writable/uploads/access/id_1775792314_1775792314_c0911e227af5f0ed36cb.jpg','writable/uploads/access/plate_1775792314_1775792314_ef19d2eae9f9abbbd2a6.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-09 21:38:34'),(46,2,297,14,20,NULL,'exit','vehicle',NULL,NULL,'Arturo','',NULL,NULL,'writable/uploads/access/exit_1775794358_1775794358_ba8deab9dc3ec0d8e266.jpg',45,'Caseta Principal','Salida registrada por guardia','2026-04-09 22:12:38'),(47,2,296,14,22,NULL,'entry','vehicle',NULL,NULL,'DANIEL QR TEMPORAL','','writable/uploads/access/id_1775832244_1775832244_b3313b9c5b70683eada9.jpg','writable/uploads/access/plate_1775832244_1775832244_5c7dbb045bbaa486cf08.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 08:44:04'),(48,2,296,14,22,NULL,'exit','vehicle',NULL,NULL,'DANIEL QR TEMPORAL','',NULL,NULL,'writable/uploads/access/exit_1775832364_1775832364_1b69f4eacb13090f890c.jpg',47,'Caseta Principal','Salida registrada por guardia','2026-04-10 08:46:04'),(49,2,419,14,24,NULL,'entry','vehicle',NULL,NULL,'memo','','writable/uploads/access/id_1775832824_1775832824_c999e939fd0498b9e1f9.jpg','writable/uploads/access/plate_1775832824_1775832824_07e8ff5591881388ef57.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 08:53:44'),(50,2,419,14,24,NULL,'exit','vehicle',NULL,NULL,'memo','',NULL,NULL,'writable/uploads/access/exit_1775833320_1775833320_3c753da3dd1048dddd72.jpg',49,'Caseta Principal','Salida registrada por guardia','2026-04-10 09:02:00'),(51,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','',NULL,NULL,NULL,NULL,'Caseta Principal',NULL,'2026-04-10 09:03:09'),(52,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775833428_1775833428_316bfc14802d69afa5ee.jpg',51,'Caseta Principal','Salida registrada por guardia','2026-04-10 09:03:48'),(53,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775835696_1775835696_b49d43f98e58328c1232.jpg','writable/uploads/access/plate_1775835696_1775835696_466adf62f823318284ad.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 09:41:36'),(54,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775836268_1775836268_66d835bb8e97866c595a.jpg',53,'Caseta Principal','Salida registrada por guardia','2026-04-10 09:51:08'),(55,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775836435_1775836435_4354422e5213f6d3e000.jpg','writable/uploads/access/plate_1775836435_1775836435_ee4e41e784da75112923.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 09:53:55'),(56,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775839989_1775839989_6da82821b61c7e7f2e21.jpg',55,'Caseta Principal','Salida registrada por guardia','2026-04-10 10:53:09'),(57,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775840557_1775840557_1b9483f515eb18ba4d9d.jpg','writable/uploads/access/plate_1775840557_1775840557_24505732b844b0a25d97.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 11:02:37'),(58,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775841619_1775841619_a93d8040061127743302.jpg',57,'Caseta Principal','Salida registrada por guardia','2026-04-10 11:20:19'),(59,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775842007_1775842007_c04981025ee7a9f1fb26.jpg','writable/uploads/access/plate_1775842007_1775842007_76b5b9079e994b438267.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 11:26:47'),(60,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775842027_1775842027_c269aad566f9cb9fa022.jpg',59,'Caseta Principal','Salida registrada por guardia','2026-04-10 11:27:07'),(61,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775842692_1775842692_01a5f365c068c54ba81f.jpg','writable/uploads/access/plate_1775842692_1775842692_b4ee978dc7c11515d422.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 11:38:12'),(62,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775842711_1775842711_45e05adcb4edc4a24845.jpg',61,'Caseta Principal','Salida registrada por guardia','2026-04-10 11:38:31'),(63,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','atyrri ',NULL,'writable/uploads/access/id_1775842776_1775842776_970aee50262f135c89db.jpg','writable/uploads/access/plate_1775842776_1775842776_1e44bfb9eea1c5666d9d.jpg',NULL,NULL,'Caseta Principal','[App Flutter] Motivo: Residente. Vehículo: Auto.','2026-04-10 11:39:36'),(64,2,427,14,NULL,NULL,'entry','vehicle','Entrega de comida','Motocicleta','panda',NULL,'writable/uploads/access/id_1775843214_1775843214_81961aa44ce7b56fa7ba.jpg','writable/uploads/access/plate_1775843214_1775843214_7e07c4d62f4abd00cbe2.jpg',NULL,NULL,'Caseta Principal','[App Flutter] Motivo: Entrega de comida. Vehículo: Motocicleta.','2026-04-10 11:46:54'),(65,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775852482_1775852482_0b3208bf2c01e005388c.jpg','writable/uploads/access/plate_1775852482_1775852482_60b4de7b4fd431fb53f3.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 14:21:22'),(66,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775855348_1775855348_f98f4b7af1c5942aef45.jpg',65,'Caseta Principal','Salida registrada por guardia','2026-04-10 15:09:08'),(67,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','ethan',NULL,'writable/uploads/access/id_1775855858_1775855858_5555a2883ec37609eb62.jpg','writable/uploads/access/plate_1775855858_1775855858_1646037bc14f7d033d85.jpg',NULL,NULL,'Caseta Principal','[App Flutter] Motivo: Residente. Vehículo: Auto.','2026-04-10 15:17:38'),(68,2,296,14,25,NULL,'entry','vehicle',NULL,NULL,'DANO','','writable/uploads/access/id_1775857437_1775857437_6cd6288ca5c09bdb8e19.jpg','writable/uploads/access/plate_1775857437_1775857437_cbc89fce3ff6fc725f6d.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-10 15:43:57'),(69,2,296,14,25,NULL,'exit','vehicle',NULL,NULL,'DANO','',NULL,NULL,'writable/uploads/access/exit_1775858664_1775858664_4c1226af53fd467db791.jpg',68,'Caseta Principal','Salida registrada por guardia','2026-04-10 16:04:24'),(70,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'ethan',NULL,NULL,NULL,'writable/uploads/access/exit_1775866768_1775866768_d03361598b2ce2f5aebd.jpg',67,'Caseta Principal','Salida registrada por guardia','2026-04-10 18:19:28'),(71,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'atyrri ',NULL,NULL,NULL,'writable/uploads/access/exit_1775866787_1775866787_2ab8fb85329dce077543.jpg',63,'Caseta Principal','Salida registrada por guardia','2026-04-10 18:19:47'),(72,2,427,14,NULL,NULL,'exit','vehicle',NULL,NULL,'panda',NULL,NULL,NULL,'writable/uploads/access/exit_1775866807_1775866807_778253f5a0c1a3d0e605.jpg',64,'Caseta Principal','Salida registrada por guardia','2026-04-10 18:20:07'),(73,2,296,14,26,NULL,'entry','vehicle',NULL,NULL,'mina','','writable/uploads/access/id_1776033825_1776033825_f1145abf89a098599eae.jpg','writable/uploads/access/plate_1776033825_1776033825_088d343d2ee5d7c5816a.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-12 16:43:45'),(74,2,296,14,26,NULL,'exit','vehicle',NULL,NULL,'mina','',NULL,NULL,'writable/uploads/access/exit_1776054313_1776054313_312753273314acc0338f.jpg',73,'Caseta Principal','Salida registrada por guardia','2026-04-12 22:25:13'),(75,2,296,14,38,NULL,'entry','vehicle',NULL,NULL,'una','','writable/uploads/access/id_1776054964_1776054964_053e4faa9a6fc2d66c73.jpg','writable/uploads/access/plate_1776054964_1776054964_990b9f762dabbbc11ee9.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-12 22:36:04'),(76,2,296,14,38,NULL,'exit','vehicle',NULL,NULL,'una','',NULL,NULL,'writable/uploads/access/exit_1776055091_1776055091_14d20efa9291ec4eaea4.jpg',75,'Caseta Principal','Salida registrada por guardia','2026-04-12 22:38:11'),(77,2,296,14,45,NULL,'entry','vehicle',NULL,NULL,'zubiri','','writable/uploads/access/id_1776058732_1776058732_299908c9267d3a6fe469.jpg','writable/uploads/access/plate_1776058732_1776058732_ff7314ba7c16b05e1e0f.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-12 23:38:52'),(78,2,296,14,45,NULL,'exit','vehicle',NULL,NULL,'zubiri','',NULL,NULL,'writable/uploads/access/exit_1776059736_1776059736_51c38d75a30ea42a8878.jpg',77,'Caseta Principal','Salida registrada por guardia','2026-04-12 23:55:36'),(79,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','Pepe ',NULL,NULL,NULL,NULL,NULL,'Caseta Principal',NULL,'2026-04-12 23:56:05'),(80,2,296,14,44,NULL,'entry','vehicle',NULL,NULL,'angeles López','','writable/uploads/access/id_1776059851_1776059851_c1625e292c76722d6d46.jpg','writable/uploads/access/plate_1776059851_1776059851_74cbd44dbba090ad692b.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-12 23:57:31'),(81,2,296,14,44,NULL,'exit','vehicle',NULL,NULL,'angeles López','',NULL,NULL,'writable/uploads/access/exit_1776060782_1776060782_23ca339d9efef1d96002.jpg',80,'Caseta Principal','Salida registrada por guardia','2026-04-13 00:13:02'),(82,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'Pepe ',NULL,NULL,NULL,'writable/uploads/access/exit_1776096211_1776096211_992ad7bc34a8ce8d79cb.jpg',79,'Caseta Principal','Salida registrada por guardia','2026-04-13 10:03:31'),(83,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','juan ',NULL,'writable/uploads/access/id_1776128318_1776128318_0ff15f6b7c968f7e031c.jpg','writable/uploads/access/plate_1776128318_1776128318_203e6f4e417d449717d2.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-13 18:58:38'),(84,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'juan ',NULL,NULL,NULL,'writable/uploads/access/exit_1776139702_1776139702_50f131c73d32b866d64d.jpg',83,'Caseta Principal','Salida registrada por guardia','2026-04-13 22:08:22'),(85,2,296,11,NULL,NULL,'entry','vehicle','Visita','Auto','angeles ',NULL,'writable/uploads/access/id_1776221953_1776221953_fc965ada8c664840c4bb.jpg','writable/uploads/access/plate_1776221953_1776221953_1e81759c28e65dd97579.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-14 20:59:13'),(86,2,296,11,54,NULL,'entry','vehicle',NULL,NULL,'Derek','','writable/uploads/access/id_1776222750_1776222750_2a7c2796cb10747d2e61.jpg','writable/uploads/access/plate_1776222750_1776222750_f9d4f99a47d0985d1afc.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-14 21:12:30'),(87,2,296,14,54,NULL,'exit','vehicle',NULL,NULL,'Derek','',NULL,NULL,'writable/uploads/access/exit_1776223165_1776223165_cd7dfc3fa08364b0eba6.jpg',86,'Caseta Principal','Salida registrada por guardia','2026-04-14 21:19:25'),(88,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'angeles ',NULL,NULL,NULL,'writable/uploads/access/exit_1776223222_1776223222_b7e10044bc61c4e1c878.jpg',85,'Caseta Principal','Salida registrada por guardia','2026-04-14 21:20:22'),(89,2,296,14,NULL,NULL,'entry','vehicle','Proveedor de servicios','Auto','Bimbo ',NULL,'writable/uploads/access/id_1776363184_1776363184_c8dfefccb9ef9bd606fe.jpg','writable/uploads/access/plate_1776363184_1776363184_71d6709b96c2707bf320.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-16 12:13:04'),(90,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'Bimbo ',NULL,NULL,NULL,'writable/uploads/access/exit_1776363240_1776363240_b7b7e26ccd51cf5dac85.jpg',89,'Caseta Principal','Salida registrada por guardia','2026-04-16 12:14:00'),(91,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','KAREN',NULL,NULL,NULL,NULL,NULL,'Caseta Principal',NULL,'2026-04-17 11:02:43'),(92,2,296,14,NULL,NULL,'entry','vehicle','Visita','Auto','bay',NULL,NULL,NULL,NULL,NULL,'Caseta Principal',NULL,'2026-04-17 11:20:03'),(93,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'KAREN',NULL,NULL,NULL,'writable/uploads/access/exit_1776446557_1776446557_23e8946da611bcfe92ce.jpg',91,'Caseta Principal','Salida registrada por guardia','2026-04-17 11:22:37'),(94,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'bay',NULL,NULL,NULL,'writable/uploads/access/exit_1776446629_1776446629_15ecfdfcedaa1f3bec22.jpg',92,'Caseta Principal','Salida registrada por guardia','2026-04-17 11:23:49'),(95,2,296,14,59,NULL,'entry','vehicle',NULL,NULL,'dulce','','writable/uploads/access/id_1776448400_1776448400_fd7366f56dac04c105e4.jpg','writable/uploads/access/plate_1776448400_1776448400_1f197358c2411df82635.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-17 11:53:20'),(96,2,296,14,59,NULL,'exit','vehicle',NULL,NULL,'dulce','',NULL,NULL,'writable/uploads/access/exit_1776450312_1776450312_0234c75fb777d438ebe4.jpg',95,'Caseta Principal','Salida registrada por guardia','2026-04-17 12:25:12'),(97,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','JUEZ',NULL,'writable/uploads/access/id_1776451426_1776451426_70b5e41109d8b40d2f43.jpg','writable/uploads/access/plate_1776451426_1776451426_905abb10ec5bf063abc2.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-04-17 12:43:46'),(98,2,296,14,NULL,NULL,'exit','vehicle',NULL,NULL,'JUEZ',NULL,NULL,NULL,'writable/uploads/access/exit_1776452218_1776452218_ddf1cb1a11212f9dc443.jpg',97,'Caseta Principal','Salida registrada por guardia','2026-04-17 12:56:58'),(99,2,296,14,60,NULL,'entry','vehicle',NULL,NULL,'DENISE','','writable/uploads/access/id_1776452278_1776452278_35e1769e7ac04e91ea15.jpg','writable/uploads/access/plate_1776452278_1776452278_c91de7ac535526a551a8.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-17 12:57:58'),(100,2,296,14,60,NULL,'exit','vehicle',NULL,NULL,'DENISE','',NULL,NULL,'writable/uploads/access/exit_1776453052_1776453052_dadc337b99f5d2595c2e.jpg',99,'Caseta Principal','Salida registrada por guardia','2026-04-17 13:10:52'),(101,2,296,14,61,NULL,'entry','vehicle',NULL,NULL,'PEPELOBO','','writable/uploads/access/id_1776453674_1776453674_b4ea69eb5c85ae7f465c.jpg','writable/uploads/access/plate_1776453674_1776453674_dc7fce25e75515af1479.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-17 13:21:14'),(102,2,296,14,61,NULL,'exit','vehicle',NULL,NULL,'PEPELOBO','',NULL,NULL,'writable/uploads/access/exit_1776453727_1776453727_84c182651badd80a7dba.jpg',101,'Caseta Principal','Salida registrada por guardia','2026-04-17 13:22:07'),(103,2,296,14,NULL,NULL,'entry','vehicle','Residente','Auto','NIKA',NULL,'writable/uploads/access/id_1776462506_1776462506_d5aecc02518f9942aeaf.jpg','writable/uploads/access/plate_1776462506_1776462506_090a7b4c4023da8cf8b6.jpg',NULL,NULL,'Caseta Principal','[Registro Manual] Motivo: Residente. Vehículo: Auto.','2026-04-17 15:48:26'),(104,2,296,14,62,NULL,'entry','vehicle',NULL,NULL,'MARIA DE LOD ANGELES','','writable/uploads/access/id_1776462949_1776462949_33475ab2063c360ab8ce.jpg','writable/uploads/access/plate_1776462949_1776462949_1386e029825d715d87d1.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-17 15:55:49'),(105,2,296,20,NULL,NULL,'exit','vehicle',NULL,NULL,'NIKA',NULL,NULL,NULL,'writable/uploads/access/exit_1776482930_1776482930_f4379dc0e299026a709c.jpg',103,'Caseta Principal','Salida registrada por guardia','2026-04-17 21:28:51'),(106,2,296,14,62,NULL,'exit','vehicle',NULL,NULL,'MARIA DE LOD ANGELES','',NULL,NULL,'writable/uploads/access/exit_1776485626_1776485626_0cee0945e8d4e68e352b.jpg',104,'Caseta Principal','Salida registrada por guardia','2026-04-17 22:13:46'),(107,2,296,14,64,NULL,'entry','vehicle',NULL,NULL,'saul','','writable/uploads/access/id_1776539687_1776539687_3e08d3e167ec02680f3e.jpg','writable/uploads/access/plate_1776539687_1776539687_0351bf76393e3eae4450.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-18 13:14:47'),(108,2,296,14,64,NULL,'exit','vehicle',NULL,NULL,'saul','',NULL,NULL,'writable/uploads/access/exit_1776739687_1776739687_6db2859c36f95cd628a8.jpg',107,'Caseta Principal','Salida registrada por guardia','2026-04-20 20:48:07'),(109,2,296,14,68,NULL,'entry','vehicle',NULL,NULL,'paco','','writable/uploads/access/id_1777264593_1777264593_ca2ed43fbb4ec3c7e53d.jpg','writable/uploads/access/plate_1777264593_1777264593_49083c5af0cad6f70ff5.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-26 22:36:33'),(110,2,296,14,68,NULL,'exit','vehicle',NULL,NULL,'paco','',NULL,NULL,'writable/uploads/access/exit_1777264611_1777264611_ebab78adf61a06c871ac.jpg',109,'Caseta Principal','Salida registrada por guardia','2026-04-26 22:36:51'),(111,8,480,27,71,NULL,'entry','vehicle',NULL,NULL,'PAOC','','writable/uploads/access/id_1777321787_1777321787_c64d289a87d4dfea1efe.jpg','writable/uploads/access/plate_1777321787_1777321787_0748b21df49b154247db.jpg',NULL,NULL,'Caseta Principal',NULL,'2026-04-27 14:29:47'),(112,8,480,27,71,NULL,'exit','vehicle',NULL,NULL,'PAOC','',NULL,NULL,'writable/uploads/access/exit_1777321903_1777321903_91e32993c2e4b779e0af.jpg',111,'Caseta Principal','Salida registrada por guardia','2026-04-27 14:31:43');
/*!40000 ALTER TABLE `access_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amenities`
--

DROP TABLE IF EXISTS `amenities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amenities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `capacity` int DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_reservable` tinyint(1) DEFAULT '1',
  `price` decimal(10,2) DEFAULT '0.00',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `reservation_interval` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '1',
  `max_active_reservations` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'unlimited',
  `has_cost` tinyint(1) DEFAULT '0',
  `requires_approval` tinyint(1) DEFAULT '0',
  `available_from` date DEFAULT NULL,
  `blocked_dates` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `reservation_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `hash_id` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id` (`condominium_id`),
  KEY `idx_amenities_hash_id` (`hash_id`),
  CONSTRAINT `amenities_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amenities`
--

LOCK TABLES `amenities` WRITE;
/*!40000 ALTER TABLE `amenities` DISABLE KEYS */;
INSERT INTO `amenities` VALUES (7,2,'Jacuzzi','Jacuzzi para residentes al corriente',NULL,1,1,0.00,'1777264071_070c8bedaafc238eeb06.png',NULL,NULL,NULL,'1','2',0,1,'2026-04-26',NULL,NULL,'503e04879c2909f317b2b42e','2026-04-26 22:27:51','2026-04-26 22:27:51',NULL);
/*!40000 ALTER TABLE `amenities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amenity_documents`
--

DROP TABLE IF EXISTS `amenity_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amenity_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `amenity_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `filename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `file_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `amenity_id` (`amenity_id`),
  CONSTRAINT `amenity_documents_amenity_id_foreign` FOREIGN KEY (`amenity_id`) REFERENCES `amenities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amenity_documents`
--

LOCK TABLES `amenity_documents` WRITE;
/*!40000 ALTER TABLE `amenity_documents` DISABLE KEYS */;
INSERT INTO `amenity_documents` VALUES (3,7,'REGLAMENTO JACUZZI','1777264071_bfa78ea05a16a408262b.pdf',47289,'application/pdf','2026-04-26 22:27:51');
/*!40000 ALTER TABLE `amenity_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amenity_schedules`
--

DROP TABLE IF EXISTS `amenity_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amenity_schedules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `amenity_id` bigint unsigned NOT NULL,
  `day_of_week` tinyint unsigned NOT NULL COMMENT '0=Lunes, 1=Martes, ..., 6=Domingo',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `open_time` time NOT NULL DEFAULT '09:00:00',
  `close_time` time NOT NULL DEFAULT '18:00:00',
  PRIMARY KEY (`id`),
  KEY `amenity_id_day_of_week` (`amenity_id`,`day_of_week`),
  CONSTRAINT `amenity_schedules_amenity_id_foreign` FOREIGN KEY (`amenity_id`) REFERENCES `amenities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amenity_schedules`
--

LOCK TABLES `amenity_schedules` WRITE;
/*!40000 ALTER TABLE `amenity_schedules` DISABLE KEYS */;
INSERT INTO `amenity_schedules` VALUES (113,7,0,1,'09:00:00','18:00:00'),(114,7,1,1,'09:00:00','18:00:00'),(115,7,2,1,'09:00:00','18:00:00'),(116,7,3,1,'09:00:00','18:00:00'),(117,7,4,1,'09:00:00','18:00:00'),(118,7,5,0,'09:00:00','18:00:00'),(119,7,6,0,'09:00:00','18:00:00');
/*!40000 ALTER TABLE `amenity_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_attachments`
--

DROP TABLE IF EXISTS `announcement_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` bigint unsigned NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `original_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `file_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcement_attachments_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `announcement_attachments_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_attachments`
--

LOCK TABLES `announcement_attachments` WRITE;
/*!40000 ALTER TABLE `announcement_attachments` DISABLE KEYS */;
INSERT INTO `announcement_attachments` VALUES (78,137,'ann_69eee8ac12e39_1777264812.jpg','10784106.jpg','10784106','image',114067,'image/jpeg','2026-04-26 22:40:12'),(79,137,'ann_69ef5106ef066_1777291526.jpg','599516.jpg','599516','image',74777,'image/jpeg','2026-04-27 06:05:27'),(80,139,'ann_69ef9eca225c0_1777311434.jpg','347234438_1537887376737628_5025264569093285237_n (1).jpg','347234438_1537887376737628_5025264569093285237_n (1)','image',34436,'image/jpeg','2026-04-27 11:37:14'),(81,140,'ann_69efa93d80d94_1777314109.jpg','70437343_10217859402264124_4308207125395406848_n.jpg','70437343_10217859402264124_4308207125395406848_n','image',151714,'image/jpeg','2026-04-27 12:21:49'),(82,141,'ann_69f00a4a5dd89_1777338954.mp4','ETHANYO__25674.mp4','ETHANYO__25674','video',25995172,'video/mp4','2026-04-27 19:15:54'),(83,141,'ann_69f00a4a5e0f1_1777338954.jpg','ETHAN2.jpg','ETHAN2','image',89576,'image/jpeg','2026-04-27 19:15:54'),(84,142,'ann_69f00efcea629_1777340156.mp4','ETHANYO__25674.mp4','ETHANYO__25674','video',25995172,'video/mp4','2026-04-27 19:35:56'),(85,143,'ann_69f01021b0104_1777340449.jpg','585046-msi-pc-gaming.jpg','585046-msi-pc-gaming','image',17094,'image/jpeg','2026-04-27 19:40:49'),(86,143,'ann_69f01021b16e7_1777340449.jpg','599516.jpg','599516','image',74777,'image/jpeg','2026-04-27 19:40:49'),(87,143,'ann_69f01021c2741_1777340449.jpg','10784106.jpg','10784106','image',114056,'image/jpeg','2026-04-27 19:40:49'),(88,143,'ann_69f01021d3b72_1777340449.jpg','MSI-GE75-Raider-9SE-409ES-cabecera.jpg','MSI-GE75-Raider-9SE-409ES-cabecera','image',32429,'image/jpeg','2026-04-27 19:40:49'),(89,144,'ann_69f0348ac592d_1777349770.jpg','compressed_1777349767681.jpg','compressed_1777349767681','image',85257,'application/octet-stream','2026-04-27 22:16:10'),(90,144,'ann_69f0348ac5b96_1777349770.jpg','compressed_1777349767853.jpg','compressed_1777349767853','image',13984,'application/octet-stream','2026-04-27 22:16:10'),(91,144,'ann_69f0348ac5d38_1777349770.jpg','compressed_1777349767867.jpg','compressed_1777349767867','image',89721,'application/octet-stream','2026-04-27 22:16:10');
/*!40000 ALTER TABLE `announcement_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_comments`
--

DROP TABLE IF EXISTS `announcement_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcement_comments_user_id_foreign` (`user_id`),
  KEY `announcement_id_created_at` (`announcement_id`,`created_at`),
  CONSTRAINT `announcement_comments_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `announcement_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_comments`
--

LOCK TABLES `announcement_comments` WRITE;
/*!40000 ALTER TABLE `announcement_comments` DISABLE KEYS */;
INSERT INTO `announcement_comments` VALUES (51,137,11,'oj','2026-04-26 22:40:26','2026-04-26 22:40:26',NULL),(52,140,11,'Ok','2026-04-27 12:55:22','2026-04-27 12:55:22',NULL),(53,143,11,'ok','2026-04-27 21:58:13','2026-04-27 21:58:13',NULL),(54,142,11,'ok me gusta','2026-04-27 21:58:44','2026-04-27 21:58:44',NULL),(55,144,4,'oj','2026-04-27 22:36:06','2026-04-27 22:36:06',NULL),(56,144,11,'ojbe','2026-04-27 22:50:17','2026-04-27 22:50:17',NULL);
/*!40000 ALTER TABLE `announcement_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_likes`
--

DROP TABLE IF EXISTS `announcement_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_likes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `announcement_id_user_id` (`announcement_id`,`user_id`),
  KEY `announcement_likes_user_id_foreign` (`user_id`),
  CONSTRAINT `announcement_likes_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `announcement_likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_likes`
--

LOCK TABLES `announcement_likes` WRITE;
/*!40000 ALTER TABLE `announcement_likes` DISABLE KEYS */;
INSERT INTO `announcement_likes` VALUES (46,140,11,NULL),(49,143,11,NULL),(50,142,11,NULL),(57,137,11,NULL),(59,138,11,NULL),(60,144,4,NULL),(61,144,11,NULL);
/*!40000 ALTER TABLE `announcement_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` enum('news','alert','maintenance','resident_post') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'news',
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'general',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `send_email` tinyint(1) DEFAULT '0',
  `email_target` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `view_count` int unsigned DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcements_created_by_foreign` (`created_by`),
  KEY `condominium_id_created_at` (`condominium_id`,`created_at`),
  CONSTRAINT `announcements_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `announcements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (137,2,4,'Anuncio','Anuncio','news','maintenance',1,1,1,'owners',19,'2026-04-26 22:40:12','2026-04-27 21:59:24',NULL),(138,2,4,'hOLA','hOLA','news','general',1,1,0,NULL,0,'2026-04-27 06:21:06','2026-04-27 06:21:06',NULL),(139,2,4,'Hola','Hola','news','maintenance',1,1,0,NULL,3,'2026-04-27 11:37:14','2026-04-27 12:21:33','2026-04-27 12:21:33'),(140,2,4,'NUEVO ANUNCIO ','NUEVO ANUNCIO&nbsp;','news','general',1,1,0,NULL,7,'2026-04-27 12:21:49','2026-04-27 22:11:31',NULL),(141,2,4,'Noticacion con video','Noticacion con video','news','maintenance',1,1,0,NULL,8,'2026-04-27 19:15:54','2026-04-27 19:35:12','2026-04-27 19:35:12'),(142,2,4,'puro videopuaiousdasd','puro videop<br>uaiousdasd','news','maintenance',1,1,0,NULL,15,'2026-04-27 19:35:56','2026-04-28 09:54:49',NULL),(143,2,4,'4 imagenes','4 imagenes<br><br>','news','event',1,1,0,NULL,12,'2026-04-27 19:40:49','2026-04-27 21:58:13',NULL),(144,2,4,'nuevo comunicado \npara todos','nuevo comunicado \npara todos','resident_post','general',1,1,0,NULL,6,'2026-04-27 22:16:10','2026-04-27 22:50:18',NULL),(145,2,4,'Nuevaapp','Nueva<div>app</div>','news','general',1,1,0,NULL,1,'2026-04-28 09:54:24','2026-04-28 17:41:36',NULL),(146,2,4,'test','test','news','general',1,1,0,NULL,0,'2026-04-28 13:54:12','2026-04-28 13:54:12',NULL);
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `amenity_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `status` enum('pending','approved','rejected','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_amenity_id_foreign` (`amenity_id`),
  KEY `bookings_unit_id_foreign` (`unit_id`),
  KEY `bookings_user_id_foreign` (`user_id`),
  KEY `condominium_id_amenity_id_start_time` (`condominium_id`,`amenity_id`,`start_time`),
  CONSTRAINT `bookings_amenity_id_foreign` FOREIGN KEY (`amenity_id`) REFERENCES `amenities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookings_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookings_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (26,2,7,296,11,'2026-04-30 09:00:00','2026-04-30 10:00:00','approved','2026-04-26 22:31:45','2026-04-26 22:47:19',NULL),(27,2,7,296,11,'2026-04-27 14:00:00','2026-04-27 15:00:00','pending','2026-04-27 13:34:32','2026-04-27 13:34:32',NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_event_reminder_recipients`
--

DROP TABLE IF EXISTS `calendar_event_reminder_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_event_reminder_recipients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reminder_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `staff_member_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_event_reminder_recipients_reminder_id_foreign` (`reminder_id`),
  CONSTRAINT `calendar_event_reminder_recipients_reminder_id_foreign` FOREIGN KEY (`reminder_id`) REFERENCES `calendar_event_reminders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_event_reminder_recipients`
--

LOCK TABLES `calendar_event_reminder_recipients` WRITE;
/*!40000 ALTER TABLE `calendar_event_reminder_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_event_reminder_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_event_reminders`
--

DROP TABLE IF EXISTS `calendar_event_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_event_reminders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint unsigned NOT NULL,
  `minutes_before` int unsigned NOT NULL DEFAULT '30',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_event_reminders_event_id_foreign` (`event_id`),
  CONSTRAINT `calendar_event_reminders_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_event_reminders`
--

LOCK TABLES `calendar_event_reminders` WRITE;
/*!40000 ALTER TABLE `calendar_event_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_event_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `all_day` tinyint(1) NOT NULL DEFAULT '0',
  `is_internal` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id_start_datetime` (`condominium_id`,`start_datetime`),
  CONSTRAINT `calendar_events_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_events`
--

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
INSERT INTO `calendar_events` VALUES (1,2,'Asamblea General','Reunion para mesa directiva','Salon de Eventos','2026-04-11 08:00:00','2026-04-11 09:00:00',0,1,NULL,'2026-04-06 22:20:56','2026-04-06 22:27:03','2026-04-06 22:27:03'),(2,2,'Asamblea','Junta','Salon de Eventos','2026-04-07 08:00:00','2026-04-07 09:00:00',0,0,4,'2026-04-06 22:27:30','2026-04-08 10:21:32','2026-04-08 10:21:32'),(3,2,'pOSADA','','','2026-04-10 00:00:00','2026-04-10 23:59:59',1,0,4,'2026-04-09 11:53:17','2026-04-27 12:53:00','2026-04-27 12:53:00'),(4,2,'Otra','','','2026-04-16 08:00:00','2026-04-16 09:00:00',0,0,4,'2026-04-09 12:10:20','2026-04-09 12:10:20',NULL),(5,2,'renuonb','detallebss','salonbde','2026-04-18 09:00:00','2026-04-18 10:00:00',0,0,11,'2026-04-17 19:42:48','2026-04-17 19:55:04','2026-04-17 19:55:04'),(6,2,'ku ho no ckto','svsvs','sals','2026-04-18 00:00:00','2026-04-18 23:59:59',1,0,11,'2026-04-17 19:55:18','2026-04-17 21:54:31','2026-04-17 21:54:31'),(7,2,'Hola evento','as','as','2026-04-01 00:00:00','2026-04-01 23:59:59',1,0,4,'2026-04-17 20:06:59','2026-04-17 20:07:53','2026-04-17 20:07:53'),(8,2,'pagos','no hay dess','salcon','2026-04-21 00:00:00','2026-04-21 23:59:59',1,0,11,'2026-04-20 22:01:15','2026-04-26 22:27:06','2026-04-26 22:27:06'),(9,2,'envto de prueba','jabw','bav','2026-04-26 00:00:00','2026-04-26 23:59:59',1,0,4,'2026-04-26 22:26:41','2026-04-26 22:26:41',NULL),(10,2,'nuevo','','vc','2026-04-27 00:00:00','2026-04-27 23:59:59',1,0,11,'2026-04-27 13:53:46','2026-04-27 13:53:46',NULL);
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `condominiums`
--

DROP TABLE IF EXISTS `condominiums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `condominiums` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint unsigned NOT NULL,
  `plan_id` int DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'monthly',
  `payment_method` enum('stripe','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'stripe',
  `plan_expires_at` datetime DEFAULT NULL,
  `stripe_customer_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `stripe_subscription_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cover_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'USD',
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'America/Mexico_City',
  `status` enum('active','suspended') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `subscription_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `grace_until` datetime DEFAULT NULL,
  `suspended_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `is_billing_active` tinyint(1) DEFAULT '0',
  `billing_start_date` date DEFAULT NULL,
  `billing_due_day` int DEFAULT NULL,
  `owner_financial_access` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'unit_community',
  `tenant_financial_access` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'none',
  `show_delinquent_units` tinyint(1) NOT NULL DEFAULT '0',
  `show_delinquency_amounts` tinyint(1) NOT NULL DEFAULT '0',
  `restrict_qr_delinquent` tinyint(1) NOT NULL DEFAULT '0',
  `restrict_amenities_delinquent` tinyint(1) NOT NULL DEFAULT '0',
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `bank_clabe` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `bank_rfc` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `bank_card` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `allow_resident_posts` tinyint(1) NOT NULL DEFAULT '0',
  `allow_post_comments` tinyint(1) NOT NULL DEFAULT '1',
  `always_email_posts` tinyint(1) NOT NULL DEFAULT '0',
  `payment_approval_mode` enum('manual','automatic') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `condominiums_subscription_id_foreign` (`subscription_id`),
  KEY `status` (`status`),
  CONSTRAINT `condominiums_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `condominiums`
--

LOCK TABLES `condominiums` WRITE;
/*!40000 ALTER TABLE `condominiums` DISABLE KEYS */;
INSERT INTO `condominiums` VALUES (2,1,NULL,'monthly','stripe',NULL,NULL,NULL,'ZUBIRI CONDO','MEXICO MEXIO67, NAUCALPAN DE JUAREZ, MEXICO, 53440, MEXICO','36f4550389bb392b_1777309322.jpg','71c4aa627d51705f_1777291496.jpg','MXN','America/Mexico_City','active','active',NULL,NULL,'2026-03-12 03:36:16','2026-04-27 11:02:02',NULL,1,'2026-03-01',10,'unit_community','none',0,0,0,0,'BANAMEX','77777777777777777777','OEZD87050447A','242433333333',0,1,0,'manual'),(5,4,NULL,'monthly','stripe',NULL,NULL,NULL,'LA ESTADIA','lA ESCALL 2, MEXICO, ATIZAPQAN, 57548, México','condominiums/5/logo_1776735954.jpg',NULL,'MXN','America/Mexico_City','suspended','active',NULL,NULL,'2026-04-20 20:02:49','2026-04-26 23:12:02','2026-04-26 23:12:02',1,'2026-04-01',10,'unit_community','none',0,0,0,0,'BANCOMER','454564564564654654','ioioipoipoi89','',1,1,0,''),(6,5,NULL,'monthly','stripe','2026-05-26 22:11:28','cus_UPVMKNlDEEsCQJ',NULL,'LAS TORRES','mEXICO, MEXICO, NACAULPAN, 45465, México','condominiums/6/logo_1776742964.jpg','condominiums/6/cover_1777262465.jpg','MXN','America/Mexico_City','suspended','active',NULL,NULL,'2026-04-20 20:29:44','2026-04-26 23:04:17','2026-04-26 23:04:17',0,NULL,10,'unit_community','none',0,0,0,0,'SANTANDER','554564654654564','','',0,1,0,'manual'),(7,6,NULL,'yearly','stripe','2026-05-26 22:14:03','cus_UPVYhp334J5GpW',NULL,'Condominio de JUAN OJEDA',NULL,NULL,NULL,'USD','America/Mexico_City','suspended','active',NULL,NULL,'2026-04-26 23:12:42','2026-04-26 22:20:33','2026-04-26 22:20:33',0,NULL,NULL,'unit_community','none',0,0,0,0,NULL,NULL,NULL,NULL,0,1,0,'manual'),(8,7,1,'monthly','stripe','2026-05-12 13:07:13','cus_UPk1mqB4YGLG7Y',NULL,'RESIDENCIAL ZUBIRI','Simurg, Mexico, CDMX, 54740, Mexico','75ec0db4c108b02c_1777316995.jpg',NULL,'MXN','America/Mexico_City','active','active',NULL,NULL,'2026-04-27 13:07:13','2026-04-28 09:57:10',NULL,1,'2026-04-01',10,'unit_community','none',0,0,0,0,'BANAMEX','450878409047898478','OZ7U6Y867YY47','45780548454545454545',0,1,0,'manual');
/*!40000 ALTER TABLE `condominiums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `couriers`
--

DROP TABLE IF EXISTS `couriers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `couriers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Identifier for SVG icon rendering on frontend',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `couriers`
--

LOCK TABLES `couriers` WRITE;
/*!40000 ALTER TABLE `couriers` DISABLE KEYS */;
INSERT INTO `couriers` VALUES (1,'Mercado Libre','mercadolibre',1,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(2,'Amazon','amazon',2,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(3,'DHL','dhl',3,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(4,'FedEx','fedex',4,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(5,'Estafeta','estafeta',5,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(6,'UPS','ups',6,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(7,'Redpack','redpack',7,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(8,'99 Minutos','99minutos',8,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(9,'Correos de México','correosmx',9,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(10,'Paquetexpress','paquetexpress',10,1,'2026-04-01 14:12:51','2026-04-01 14:12:51'),(11,'Otro','otro',99,1,'2026-04-01 14:12:51','2026-04-01 14:12:51');
/*!40000 ALTER TABLE `couriers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_push_subscriptions`
--

DROP TABLE IF EXISTS `device_push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_push_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `condominium_id` bigint unsigned DEFAULT NULL,
  `fcm_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `device_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Flutter Mobile',
  `platform` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'android',
  `device_id` bigint unsigned DEFAULT NULL,
  `endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `p256dh_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `auth_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_push_subscriptions_device_id_foreign` (`device_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `device_push_subscriptions_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `device_push_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_push_subscriptions`
--

LOCK TABLES `device_push_subscriptions` WRITE;
/*!40000 ALTER TABLE `device_push_subscriptions` DISABLE KEYS */;
INSERT INTO `device_push_subscriptions` VALUES (2,14,2,'cU0M6He4QCqtPm4nC7L5cy:APA91bFZhP_Zbw85FuC4qVjHFMpOaBRY3ptvoGxtlRgqU6dc-LqZFuR2It80RX12vbWZn5x2QwHVAiZWfKz57tpFXYxeNVCq5Gzq8dogDC0j3xss2HtvadE','Flutter Mobile','android',NULL,'','','','2026-04-15 13:13:54','2026-04-17 12:39:25'),(5,11,2,'dy530UaPRrCqm1s2FhG6FC:APA91bF3MGhw3HYyiZnb3cTvvtvIRrahzu1-wRhaRfk5jGvv__leTV1bjStmjZ6REj8r4O5UFPyOr9b3vouKRWHqJ2VqhM6zlTW3FytMZGf_5Vw5JcMTiIQ','Flutter Mobile','android',NULL,'','','','2026-04-20 20:36:22','2026-04-28 07:30:03');
/*!40000 ALTER TABLE `device_push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `device_identifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `app_version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `os_version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_identifier` (`device_identifier`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `devices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (2,14,'axis-sec-2-6cf43096','Caseta 3','active','2026-04-06 12:18:04','2026-04-06 12:18:04'),(3,20,'axis-sec-2-54e5608d','CASETA 7','active','2026-04-17 21:25:28','2026-04-17 21:25:28'),(4,27,'axis-sec-8-ac79f872','CASTA FLORE','active','2026-04-27 14:27:08','2026-04-27 14:27:08');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_views`
--

DROP TABLE IF EXISTS `document_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_views` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `document_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` enum('view','download') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'view',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id_document_id` (`condominium_id`,`document_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_views`
--

LOCK TABLES `document_views` WRITE;
/*!40000 ALTER TABLE `document_views` DISABLE KEYS */;
INSERT INTO `document_views` VALUES (1,2,2,4,'view','2026-04-06 21:07:02'),(2,2,2,4,'download','2026-04-06 21:07:03'),(3,2,2,NULL,'view','2026-04-06 21:09:43'),(4,2,2,4,'view','2026-04-06 21:19:03'),(5,2,2,4,'download','2026-04-06 21:19:04'),(6,2,2,4,'download','2026-04-06 21:19:28'),(7,2,2,4,'view','2026-04-06 21:20:21'),(8,2,2,4,'view','2026-04-06 21:25:33'),(9,2,5,4,'view','2026-04-06 21:29:02'),(10,2,5,4,'download','2026-04-06 21:29:03'),(11,2,4,4,'view','2026-04-06 22:29:18'),(12,2,2,4,'view','2026-04-06 22:29:20'),(13,2,2,NULL,'view','2026-04-07 10:13:56'),(14,2,4,NULL,'view','2026-04-07 10:13:58'),(15,2,4,NULL,'view','2026-04-07 10:14:03'),(16,2,2,NULL,'view','2026-04-07 10:14:05'),(17,2,2,NULL,'view','2026-04-08 09:52:54'),(18,2,2,NULL,'download','2026-04-08 09:52:55'),(19,2,4,4,'view','2026-04-11 01:22:37'),(20,2,4,4,'view','2026-04-11 01:26:22'),(21,2,4,4,'view','2026-04-11 01:26:26'),(22,2,2,4,'view','2026-04-11 01:33:06'),(23,2,4,4,'view','2026-04-11 01:33:08'),(24,2,4,4,'view','2026-04-12 19:05:44'),(25,2,4,4,'view','2026-04-12 19:05:46'),(26,2,4,4,'download','2026-04-12 19:05:47'),(27,2,4,4,'view','2026-04-16 18:50:34'),(28,2,4,4,'view','2026-04-16 18:50:35'),(29,2,4,4,'view','2026-04-16 19:18:04'),(30,2,4,11,'download','2026-04-16 20:47:43'),(31,2,2,4,'view','2026-04-16 20:48:46'),(32,2,10,11,'download','2026-04-16 20:49:25'),(33,2,2,11,'download','2026-04-16 20:50:05'),(34,2,2,11,'download','2026-04-16 20:50:12'),(35,2,2,4,'view','2026-04-16 20:50:44'),(36,2,2,4,'download','2026-04-16 20:50:47'),(37,2,4,11,'download','2026-04-16 20:50:54'),(38,2,9,4,'view','2026-04-16 20:51:27'),(39,2,9,4,'view','2026-04-16 20:54:32'),(40,2,9,4,'download','2026-04-16 20:54:33'),(41,2,4,11,'download','2026-04-16 20:55:10'),(42,2,10,11,'download','2026-04-16 20:55:15'),(43,2,10,11,'download','2026-04-16 20:55:24'),(44,2,10,11,'download','2026-04-16 20:57:13'),(45,2,10,11,'download','2026-04-16 20:57:16'),(46,2,10,11,'download','2026-04-16 21:04:07'),(47,2,10,11,'download','2026-04-16 21:45:22'),(48,2,10,11,'download','2026-04-16 21:46:55'),(49,2,11,11,'download','2026-04-16 21:46:58'),(50,2,10,11,'download','2026-04-17 01:22:27'),(51,2,10,11,'download','2026-04-17 08:32:09'),(52,2,10,11,'download','2026-04-17 10:26:45'),(53,2,10,11,'download','2026-04-17 15:35:51'),(54,2,10,11,'download','2026-04-17 20:28:03'),(55,2,10,11,'download','2026-04-18 20:38:07'),(56,2,10,4,'view','2026-04-20 20:39:27'),(57,2,10,11,'download','2026-04-26 22:45:41'),(58,2,10,4,'view','2026-04-27 12:15:53'),(59,2,10,4,'download','2026-04-27 12:15:54'),(60,2,10,11,'download','2026-04-27 22:04:34'),(61,2,12,4,'download','2026-04-27 22:48:52'),(62,2,10,4,'download','2026-04-27 22:48:54');
/*!40000 ALTER TABLE `document_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extraordinary_fees`
--

DROP TABLE IF EXISTS `extraordinary_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extraordinary_fees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `category_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `expected_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `extraordinary_fees_condominium_id_foreign` (`condominium_id`),
  KEY `extraordinary_fees_category_id_foreign` (`category_id`),
  CONSTRAINT `extraordinary_fees_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `financial_categories` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `extraordinary_fees_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extraordinary_fees`
--

LOCK TABLES `extraordinary_fees` WRITE;
/*!40000 ALTER TABLE `extraordinary_fees` DISABLE KEYS */;
/*!40000 ALTER TABLE `extraordinary_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_categories`
--

DROP TABLE IF EXISTS `financial_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` enum('income','expense') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'income',
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id` (`condominium_id`),
  CONSTRAINT `financial_categories_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_categories`
--

LOCK TABLES `financial_categories` WRITE;
/*!40000 ALTER TABLE `financial_categories` DISABLE KEYS */;
INSERT INTO `financial_categories` VALUES (1,2,'Cuota de Mantenimiento',NULL,'income',1,NULL,NULL,NULL),(2,2,'Cargo por Mora',NULL,'income',1,NULL,NULL,NULL),(3,2,'Cargo de Reserva de Amenidad',NULL,'income',1,NULL,NULL,NULL),(4,2,'Multa de Amenidad',NULL,'income',1,NULL,NULL,NULL),(5,2,'Multa de Estacionamiento',NULL,'income',1,NULL,NULL,NULL),(6,2,'Multa de Mascota',NULL,'income',1,NULL,NULL,NULL),(7,2,'Multa por Infracción',NULL,'income',1,NULL,NULL,NULL),(8,2,'Otro Ingreso',NULL,'income',1,NULL,NULL,NULL),(9,2,'Salario del Personal',NULL,'expense',1,NULL,NULL,NULL),(10,2,'Mantenimiento y Reparaciones',NULL,'expense',1,NULL,NULL,NULL),(11,2,'Servicios Públicos',NULL,'expense',1,NULL,NULL,NULL),(12,2,'Suministros',NULL,'expense',1,NULL,NULL,NULL),(13,2,'Servicios Profesionales',NULL,'expense',1,NULL,NULL,NULL),(14,2,'Seguro',NULL,'expense',1,NULL,NULL,NULL),(15,2,'Otro Gasto',NULL,'expense',1,NULL,NULL,NULL),(16,5,'Cuota de Mantenimiento',NULL,'income',1,'2026-04-20 20:02:49','2026-04-20 20:02:49',NULL),(17,5,'Cuota Extraordinaria',NULL,'income',1,'2026-04-20 20:02:49','2026-04-20 20:02:49',NULL),(18,5,'Mora / Recargo',NULL,'income',1,'2026-04-20 20:02:49','2026-04-20 20:02:49',NULL),(19,5,'Gastos Generales',NULL,'expense',1,'2026-04-20 20:02:49','2026-04-20 20:02:49',NULL),(20,6,'Cuota de Mantenimiento',NULL,'income',1,'2026-04-20 20:29:44','2026-04-20 20:29:44',NULL),(21,6,'Cuota Extraordinaria',NULL,'income',1,'2026-04-20 20:29:44','2026-04-20 20:29:44',NULL),(22,6,'Mora / Recargo',NULL,'income',1,'2026-04-20 20:29:44','2026-04-20 20:29:44',NULL),(23,6,'Gastos Generales',NULL,'expense',1,'2026-04-20 20:29:44','2026-04-20 20:29:44',NULL),(24,5,'Cargo por Mora',NULL,'income',1,NULL,NULL,NULL),(25,5,'Cargo de Reserva de Amenidad',NULL,'income',1,NULL,NULL,NULL),(26,5,'Multa de Amenidad',NULL,'income',1,NULL,NULL,NULL),(27,5,'Multa de Estacionamiento',NULL,'income',1,NULL,NULL,NULL),(28,5,'Multa de Mascota',NULL,'income',1,NULL,NULL,NULL),(29,5,'Multa por Infracción',NULL,'income',1,NULL,NULL,NULL),(30,5,'Otro Ingreso',NULL,'income',1,NULL,NULL,NULL),(31,5,'Salario del Personal',NULL,'expense',1,NULL,NULL,NULL),(32,5,'Mantenimiento y Reparaciones',NULL,'expense',1,NULL,NULL,NULL),(33,5,'Servicios Públicos',NULL,'expense',1,NULL,NULL,NULL),(34,5,'Suministros',NULL,'expense',1,NULL,NULL,NULL),(35,5,'Servicios Profesionales',NULL,'expense',1,NULL,NULL,NULL),(36,5,'Seguro',NULL,'expense',1,NULL,NULL,NULL),(37,5,'Otro Gasto',NULL,'expense',1,NULL,NULL,NULL),(38,5,'Cuota de Mantenimiento','Cargo mensual automático por mantenimiento','income',1,'2026-04-20 19:34:11','2026-04-20 19:34:11',NULL),(39,7,'Cuota de Mantenimiento',NULL,'income',1,NULL,NULL,NULL),(40,7,'Cargo por Mora',NULL,'income',1,NULL,NULL,NULL),(41,7,'Cargo de Reserva de Amenidad',NULL,'income',1,NULL,NULL,NULL),(42,7,'Multa de Amenidad',NULL,'income',1,NULL,NULL,NULL),(43,7,'Multa de Estacionamiento',NULL,'income',1,NULL,NULL,NULL),(44,7,'Multa de Mascota',NULL,'income',1,NULL,NULL,NULL),(45,7,'Multa por Infracción',NULL,'income',1,NULL,NULL,NULL),(46,7,'Otro Ingreso',NULL,'income',1,NULL,NULL,NULL),(47,7,'Salario del Personal',NULL,'expense',1,NULL,NULL,NULL),(48,7,'Mantenimiento y Reparaciones',NULL,'expense',1,NULL,NULL,NULL),(49,7,'Servicios Públicos',NULL,'expense',1,NULL,NULL,NULL),(50,7,'Suministros',NULL,'expense',1,NULL,NULL,NULL),(51,7,'Servicios Profesionales',NULL,'expense',1,NULL,NULL,NULL),(52,7,'Seguro',NULL,'expense',1,NULL,NULL,NULL),(53,7,'Otro Gasto',NULL,'expense',1,NULL,NULL,NULL),(54,8,'Cuota de Mantenimiento',NULL,'income',1,'2026-04-27 13:07:13','2026-04-27 13:07:13',NULL),(55,8,'Cuota Extraordinaria',NULL,'income',1,'2026-04-27 13:07:13','2026-04-27 13:07:13',NULL),(56,8,'Mora / Recargo',NULL,'income',1,'2026-04-27 13:07:13','2026-04-27 13:07:13',NULL),(57,8,'Gastos Generales',NULL,'expense',1,'2026-04-27 13:07:13','2026-04-27 13:07:13',NULL);
/*!40000 ALTER TABLE `financial_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_transactions`
--

DROP TABLE IF EXISTS `financial_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `extraordinary_fee_id` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  `type` enum('charge','credit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'charge',
  `amount` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `attachment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `due_date` date NOT NULL,
  `status` enum('pending','partial','paid','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `source` enum('manual','auto') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'manual',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `financial_transactions_unit_id_foreign` (`unit_id`),
  KEY `financial_transactions_category_id_foreign` (`category_id`),
  KEY `condominium_id_unit_id_status` (`condominium_id`,`unit_id`,`status`),
  KEY `fk_financial_transactions_extraordinary_fees` (`extraordinary_fee_id`),
  KEY `idx_condo_due_date` (`condominium_id`,`due_date`),
  CONSTRAINT `financial_transactions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `financial_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `financial_transactions_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `financial_transactions_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_financial_transactions_extraordinary_fees` FOREIGN KEY (`extraordinary_fee_id`) REFERENCES `extraordinary_fees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_transactions`
--

LOCK TABLES `financial_transactions` WRITE;
/*!40000 ALTER TABLE `financial_transactions` DISABLE KEYS */;
INSERT INTO `financial_transactions` VALUES (2,2,297,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(3,2,419,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(4,2,420,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(5,2,421,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(6,2,422,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(7,2,423,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(8,2,424,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(9,2,425,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(10,2,426,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(11,2,427,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(12,2,428,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-01 23:37:02','2026-04-09 03:07:11',NULL),(14,2,297,NULL,1,'charge',5000.00,5000.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','paid','manual','2026-02-10 23:39:07','2026-04-13 20:06:43',NULL),(15,2,419,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(16,2,420,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(17,2,421,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(18,2,422,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(19,2,423,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(20,2,424,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(21,2,425,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(22,2,426,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(23,2,427,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(24,2,428,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA DE FEBRERO MANUAL ','[\"financial\\/1775108347_af82bcbcf449e73c00c4.jpg\"]','2026-02-10','pending','manual','2026-02-10 23:39:07','2026-04-13 15:03:06',NULL),(26,2,297,NULL,1,'charge',4000.00,4000.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','paid','manual','2026-03-10 23:40:26','2026-04-13 20:06:43',NULL),(27,2,419,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(28,2,420,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(29,2,421,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(30,2,422,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(31,2,423,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(32,2,424,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(33,2,425,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(34,2,426,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(35,2,427,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(36,2,428,NULL,1,'charge',4000.00,0.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','pending','manual','2026-03-10 23:40:26','2026-04-13 14:59:53',NULL),(102,2,297,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:08:40',NULL),(104,2,419,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(106,2,420,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(108,2,421,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(110,2,422,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(112,2,423,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(114,2,424,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(116,2,425,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(118,2,426,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(120,2,427,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(122,2,428,NULL,1,'charge',500.00,0.00,'transferencia','CARGO Y PAGO AGUA',NULL,'2026-04-08','pending','manual','2026-04-08 09:47:30','2026-04-09 03:07:11',NULL),(199,2,429,NULL,1,'charge',5000.00,0.00,NULL,'CUOTA MANUAL c101',NULL,'2026-04-08','pending','manual','2026-04-08 13:05:58','2026-04-09 03:07:11',NULL),(200,2,429,NULL,1,'charge',1000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-08 13:43:00','2026-04-09 03:07:11',NULL),(203,2,297,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:08:40',NULL),(205,2,419,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(207,2,420,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(209,2,421,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-30','pending','manual','2026-04-30 17:51:46','2026-04-09 03:07:11',NULL),(211,2,422,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(213,2,423,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(215,2,424,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(217,2,425,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(219,2,426,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(221,2,427,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(223,2,428,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(225,2,429,NULL,4,'charge',1000.00,0.00,'transferencia','nueva cuota abril manual extra',NULL,'2026-04-08','pending','manual','2026-04-08 17:51:46','2026-04-09 03:07:11',NULL),(260,2,297,NULL,1,'charge',5000.00,0.00,NULL,'cuota de vencimiento manual ya vencio',NULL,'2026-04-08','pending','manual','2026-04-08 03:08:40','2026-04-09 03:10:39',NULL),(261,2,297,NULL,2,'charge',5000.00,0.00,NULL,'YA VENCIO CUOTA 2 ',NULL,'2026-04-01','pending','manual','2026-04-01 03:10:39','2026-04-13 20:05:49',NULL),(263,2,296,NULL,1,'charge',5000.00,5000.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','paid','auto','2026-04-13 15:02:25','2026-04-26 22:39:38',NULL),(264,2,296,NULL,1,'charge',5000.00,5000.00,NULL,'CUOTA MANUAL MARZO ',NULL,'2026-03-10','paid','manual','2026-03-10 15:08:13','2026-04-26 22:39:38',NULL),(265,2,296,NULL,8,'charge',5000.00,5000.00,NULL,'nueva cuota de abril ','[\"financial\\/1776114988_e1b305e7a8ec6580b703.jpg\"]','2026-04-13','paid','manual','2026-04-13 15:16:28','2026-04-26 22:39:38',NULL),(266,2,296,NULL,1,'credit',10000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-13','paid','manual','2026-04-13 15:20:14','2026-04-13 15:20:14',NULL),(270,2,NULL,NULL,9,'credit',4000.00,0.00,'transferencia','pago nomina','[\"financial\\/1776131501_dc9f0f8aad383f3c4b01.png\"]','2026-04-13','paid','manual','2026-04-13 19:51:41','2026-04-13 19:51:41',NULL),(271,2,NULL,NULL,11,'credit',2000.00,0.00,'transferencia','pago de luz','1776133808_bd6d796fdde716db9c7e.pdf','2026-04-13','paid','manual','2026-04-13 20:04:46','2026-04-13 20:30:08',NULL),(272,2,297,NULL,1,'credit',5000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-13','paid','manual','2026-04-13 20:05:49','2026-04-13 20:05:49',NULL),(273,2,297,NULL,3,'credit',4000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-13','paid','manual','2026-04-13 20:06:43','2026-04-13 20:06:43',NULL),(274,2,296,NULL,4,'charge',2500.00,2500.00,NULL,'multa por velocidad ',NULL,'2026-04-13','paid','manual','2026-04-13 20:41:57','2026-04-26 22:39:38',NULL),(275,2,NULL,NULL,14,'credit',1000.00,0.00,'transferencia','PAGO SEGURO','[\"financial\\/1776137574_e963cc4a55ade7b88ae4.pdf\"]','2026-04-13','paid','manual','2026-04-13 21:32:54','2026-04-13 21:32:54',NULL),(276,2,296,NULL,1,'credit',500.00,0.00,'Transferencia Bancaria','PAGO - COMPROBANTE APROBADO','payments/2/1776138946_a9b64841bb0269bcd82f.jpg','2026-04-13','paid','manual','2026-04-13 21:57:04','2026-04-13 21:57:04',NULL),(277,2,296,NULL,1,'credit',2000.00,0.00,'transferencia','liquidacon manual ',NULL,'2026-04-14','paid','manual','2026-04-14 18:45:56','2026-04-14 18:45:56',NULL),(297,2,296,NULL,1,'credit',2500.00,0.00,'Transferencia Bancaria','PAGO - COMPROBANTE APROBADO','payments/2/1776538656_24f28b87825249a9d3b4.jpg','2026-04-18','paid','manual','2026-04-18 22:04:33','2026-04-18 22:04:33',NULL),(298,2,296,NULL,1,'charge',5000.00,5000.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','paid','auto','2026-04-18 23:16:23','2026-04-26 22:39:38',NULL),(299,2,297,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(300,2,419,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(301,2,420,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(302,2,421,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(303,2,422,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(304,2,423,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(305,2,424,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(306,2,425,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(307,2,426,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(308,2,427,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(309,2,428,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(310,2,429,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-11','pending','auto','2026-04-18 23:16:23','2026-04-18 23:16:23',NULL),(311,2,296,NULL,1,'charge',5000.00,5000.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','paid','auto','2026-04-18 23:19:40','2026-04-26 22:39:38',NULL),(312,2,297,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(313,2,419,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(314,2,420,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(315,2,421,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(316,2,422,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(317,2,423,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(318,2,424,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(319,2,425,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(320,2,426,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(321,2,427,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(322,2,428,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(323,2,429,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-12','pending','auto','2026-04-18 23:19:40','2026-04-18 23:19:40',NULL),(324,2,296,NULL,1,'charge',5000.00,5000.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','paid','auto','2026-04-18 23:21:37','2026-04-26 22:39:38',NULL),(325,2,297,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(326,2,419,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(327,2,420,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(328,2,421,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(329,2,422,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(330,2,423,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(331,2,424,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(332,2,425,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(333,2,426,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(334,2,427,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(335,2,428,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(336,2,429,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-16','pending','auto','2026-04-18 23:21:37','2026-04-18 23:21:37',NULL),(337,2,296,NULL,1,'charge',5000.00,5000.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','paid','auto','2026-04-18 23:22:35','2026-04-26 22:39:38',NULL),(338,2,297,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(339,2,419,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(340,2,420,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(341,2,421,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(342,2,422,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(343,2,423,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(344,2,424,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(345,2,425,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(346,2,426,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(347,2,427,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(348,2,428,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(349,2,429,NULL,1,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-09','pending','auto','2026-04-18 23:22:35','2026-04-18 23:22:35',NULL),(350,2,296,NULL,1,'credit',22000.00,0.00,'Transferencia Bancaria','PAGO - COMPROBANTE APROBADO','payments/2/1776575879_7fc10ce8622473ea4863.jpg','2026-04-18','paid','manual','2026-04-18 23:29:47','2026-04-18 23:29:47',NULL),(351,2,296,NULL,1,'charge',500.00,500.00,NULL,'autos',NULL,'2026-04-29','paid','manual','2026-04-29 23:53:48','2026-04-26 22:39:39',NULL),(352,2,296,NULL,3,'charge',500.00,150.00,NULL,'Cargo generado manualmente',NULL,'2026-04-30','partial','manual','2026-04-19 00:04:01','2026-04-26 22:39:39',NULL),(354,2,296,NULL,1,'credit',500.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-19','paid','manual','2026-04-19 00:09:31','2026-04-19 00:09:31',NULL),(355,2,296,NULL,1,'charge',400.00,0.00,NULL,'pago de cole',NULL,'2026-04-30','pending','manual','2026-04-19 13:13:31','2026-04-20 20:20:21',NULL),(356,2,296,NULL,1,'credit',500.00,0.00,'transferencia','pago de la 100',NULL,'2026-04-19','paid','manual','2026-04-19 13:22:14','2026-04-19 13:22:14',NULL),(357,5,456,NULL,38,'charge',4000.00,4000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','paid','auto','2026-04-20 19:34:11','2026-04-20 22:21:25',NULL),(358,5,465,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(359,5,466,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(360,5,467,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(361,5,457,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(362,5,458,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(363,5,459,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(364,5,460,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(365,5,461,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:22',NULL),(366,5,462,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:23',NULL),(367,5,463,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:23',NULL),(368,5,464,NULL,38,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:34:11','2026-04-20 19:46:23',NULL),(369,5,456,NULL,16,'charge',4000.00,2000.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','partial','auto','2026-04-20 19:46:07','2026-04-20 22:21:25',NULL),(370,5,465,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(371,5,466,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(372,5,467,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(373,5,457,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(374,5,458,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(375,5,459,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(376,5,460,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(377,5,461,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(378,5,462,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(379,5,463,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(380,5,464,NULL,16,'charge',4000.00,0.00,NULL,'Cuota de Mantenimiento Abril 2026',NULL,'2026-04-10','pending','auto','2026-04-20 19:46:07','2026-04-20 19:46:07',NULL),(381,5,456,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(382,5,465,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(383,5,466,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(384,5,467,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(385,5,457,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(386,5,458,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(387,5,459,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(388,5,460,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(389,5,461,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(390,5,462,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(391,5,463,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(392,5,464,NULL,16,'credit',2000.00,0.00,'transferencia','Pago registrado manualmente',NULL,'2026-04-20','paid','manual','2026-04-20 19:46:22','2026-04-20 19:46:22',NULL),(393,2,296,NULL,1,'credit',50.00,0.00,'Transferencia Bancaria','PAGO - COMPROBANTE APROBADO','payments/2/1776737970_c78319573c93fa578d91.jpg','2026-04-20','paid','manual','2026-04-20 20:20:21','2026-04-20 20:20:21',NULL),(394,5,456,NULL,16,'credit',4000.00,0.00,'Transferencia Bancaria','PAGO - COMPROBANTE APROBADO','payments/5/1776745263_671b7fe5e6f16a66f6d3.jpg','2026-04-20','paid','manual','2026-04-20 22:21:25','2026-04-20 22:21:25',NULL),(395,2,296,NULL,1,'credit',100.00,0.00,'Transferencia Bancaria','PAGO - COMPROBANTE APROBADO','payments/2/1777264763_a943a39d3b6a715fe9d8.jpg','2026-04-26','paid','manual','2026-04-26 22:39:38','2026-04-26 22:39:38',NULL),(396,8,480,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(397,8,481,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(398,8,482,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(399,8,483,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(400,8,484,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(401,8,485,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(402,8,486,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(403,8,487,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(404,8,488,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(405,8,489,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(406,8,490,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(407,8,491,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL),(408,8,492,NULL,54,'charge',5000.00,0.00,NULL,'Cuota de Mantenimiento April 2026',NULL,'2026-04-10','pending','auto','2026-04-28 09:57:10','2026-04-28 09:57:10',NULL);
/*!40000 ALTER TABLE `financial_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (55,'2026-03-11-000001','App\\Database\\Migrations\\CreatePlansTable','default','App',1773253195,1),(56,'2026-03-11-000002','App\\Database\\Migrations\\CreateUsersTable','default','App',1773253195,1),(57,'2026-03-11-000003','App\\Database\\Migrations\\CreateRolesTable','default','App',1773253195,1),(58,'2026-03-11-000004','App\\Database\\Migrations\\CreatePermissionsTable','default','App',1773253196,1),(59,'2026-03-11-000005','App\\Database\\Migrations\\CreateRolePermissionsTable','default','App',1773253196,1),(60,'2026-03-11-000006','App\\Database\\Migrations\\CreateSubscriptionsTable','default','App',1773253196,1),(61,'2026-03-11-000007','App\\Database\\Migrations\\CreateCondominiumsTable','default','App',1773253196,1),(62,'2026-03-11-000008','App\\Database\\Migrations\\CreateUserCondominiumRolesTable','default','App',1773253196,1),(63,'2026-03-11-000009','App\\Database\\Migrations\\CreateSectionsTable','default','App',1773253196,1),(64,'2026-03-11-000010','App\\Database\\Migrations\\CreateUnitsTable','default','App',1773253196,1),(65,'2026-03-11-000011','App\\Database\\Migrations\\CreateResidentsTable','default','App',1773253196,1),(66,'2026-03-11-000012','App\\Database\\Migrations\\CreateFinancialCategoriesTable','default','App',1773253196,1),(67,'2026-03-11-000013','App\\Database\\Migrations\\CreateFinancialTransactionsTable','default','App',1773253196,1),(68,'2026-03-11-000014','App\\Database\\Migrations\\CreatePaymentsTable','default','App',1773253196,1),(69,'2026-03-11-000015','App\\Database\\Migrations\\CreatePersonalAccessTokensTable','default','App',1773253196,1),(70,'2026-03-11-000016','App\\Database\\Migrations\\CreateDevicesTable','default','App',1773253196,1),(71,'2026-03-11-000017','App\\Database\\Migrations\\CreateDevicePushSubscriptionsTable','default','App',1773253196,1),(72,'2026-03-11-000018','App\\Database\\Migrations\\CreateAmenitiesTable','default','App',1773253196,1),(73,'2026-03-11-000019','App\\Database\\Migrations\\CreateBookingsTable','default','App',1773253196,1),(74,'2026-03-11-000020','App\\Database\\Migrations\\CreateTicketsTable','default','App',1773253196,1),(75,'2026-03-11-000021','App\\Database\\Migrations\\CreatePollsTable','default','App',1773253196,1),(76,'2026-03-11-000022','App\\Database\\Migrations\\CreateAnnouncementsTable','default','App',1773253196,1),(77,'2026-03-11-000023','App\\Database\\Migrations\\CreateVisitorInvitationsTable','default','App',1773253196,1),(78,'2026-03-11-000024','App\\Database\\Migrations\\CreateVisitorsTable','default','App',1773253196,1),(79,'2026-03-11-000025','App\\Database\\Migrations\\CreateQrCodesTable','default','App',1773253197,1),(80,'2026-03-11-000026','App\\Database\\Migrations\\CreateAccessLogsTable','default','App',1773253197,1),(81,'2026-03-11-000027','App\\Database\\Migrations\\CreateParcelsTable','default','App',1773253197,1),(82,'2026-03-12-031223','App\\Database\\Migrations\\AddFloorAndFeeToUnits','default','App',1773285193,2),(83,'2026-03-12-032002','App\\Database\\Migrations\\AddAreaAndIndivisoToUnits','default','App',1773285737,3),(84,'2026-03-12-045854','App\\Database\\Migrations\\AddOccupancyToUnits','default','App',1773291572,4),(85,'2026-03-12-234500','App\\Database\\Migrations\\AddFeeStartMonthToUnits','default','App',1773293999,5),(86,'2026-03-12-235500','App\\Database\\Migrations\\CreateUnitNotesTable','default','App',1773294810,6),(87,'2026-03-12-235600','App\\Database\\Migrations\\CreateResidentInvitationsTable','default','App',1773361324,7),(88,'2026-03-13-225931','App\\Database\\Migrations\\AddBillingSettingsToCondominiums','default','App',1773442865,8),(89,'2026-03-14-031153','App\\Database\\Migrations\\AddAttachmentToFinancialTransactions','default','App',1773458013,9),(90,'2026-03-14-150000','App\\Database\\Migrations\\AddPaymentMethodToFinancialTransactions','default','App',1773460034,10),(91,'2026-03-15-060702','App\\Database\\Migrations\\MakeUnitIdNullableInTransactions','default','App',1773554866,11),(92,'2026-03-16-000001','App\\Database\\Migrations\\AddSourceToFinancialTransactions','default','App',1773719045,12),(93,'2026-03-18-000001','App\\Database\\Migrations\\AddInitialBalanceToUnits','default','App',1773797750,13),(94,'2026-03-22-140000','App\\Database\\Migrations\\CreateExtraordinaryFeesTable','default','App',1774212235,14),(95,'2026-03-22-140500','App\\Database\\Migrations\\AddExtraordinaryFeeIdToTransactions','default','App',1774212235,14),(96,'2026-03-26-233000','App\\Database\\Migrations\\AddHashIdToUnits','default','App',1774567763,15),(97,'2026-03-27-000000','App\\Database\\Migrations\\AddDetailsToQrCodes','default','App',1774648661,16),(98,'2026-03-27-100000','App\\Database\\Migrations\\AddPhotoPlateAndEntryLinkToAccessLogs','default','App',1774654984,17),(99,'2026-03-27-200000','App\\Database\\Migrations\\AddRenovadoStatusToQrCodes','default','App',1774658674,18),(100,'2026-03-29-200326','App\\Database\\Migrations\\AddVisitAndVehicleToAccessLogs','default','App',1774814631,19),(101,'2026-04-01-200001','App\\Database\\Migrations\\AddFieldsToParcels','default','App',1775074371,20),(102,'2026-04-01-200002','App\\Database\\Migrations\\CreateCouriersTable','default','App',1775074371,20),(103,'2026-04-01-203000','App\\Database\\Migrations\\AddDeliveryFieldsToParcels','default','App',1775075569,21),(104,'2026-04-02-041618','App\\Database\\Migrations\\CreatePollOptionsAndVotesTables','default','App',1775500834,22),(105,'2026-04-02-043934','App\\Database\\Migrations\\AddCategoryToPollsTable','default','App',1775501200,23),(106,'2026-04-06-120000','App\\Database\\Migrations\\CreateStaffMembersTable','default','App',1775501200,23),(107,'2026-04-06-140000','App\\Database\\Migrations\\AddDetailedFieldsToTicketsTable','default','App',1775506394,24),(108,'2026-04-06-205110','App\\Database\\Migrations\\AlterUnitIdNullableInTickets','default','App',1775508709,25),(109,'2026-04-06-220000','App\\Database\\Migrations\\AlterTicketHashLength','default','App',1775511409,26),(110,'2026-04-06-230000','App\\Database\\Migrations\\CreateTicketCommentsTable','default','App',1775513882,27),(111,'2026-04-06-231000','App\\Database\\Migrations\\AddMediaUrlsToTicketComments','default','App',1775513919,28),(112,'2026-04-07-014122','App\\Database\\Migrations\\CreateTenantDocumentsTable','default','App',1775526655,29),(113,'2026-04-07-023319','App\\Database\\Migrations\\AddIsStarredToTenantDocuments','default','App',1775529252,30),(114,'2026-04-07-030000','App\\Database\\Migrations\\CreateDocumentViewsTable','default','App',1775530930,31),(115,'2026-04-07-040000','App\\Database\\Migrations\\CreateCalendarEventsTable','default','App',1775535083,32),(116,'2026-04-07-040100','App\\Database\\Migrations\\CreateCalendarEventRemindersTable','default','App',1775535083,32),(117,'2026-04-07-040200','App\\Database\\Migrations\\CreateCalendarEventReminderRecipientsTable','default','App',1775535083,32),(118,'2026-04-07-050000','App\\Database\\Migrations\\AddFieldsToAnnouncementsTable','default','App',1775537134,33),(119,'2026-04-07-050100','App\\Database\\Migrations\\CreateAnnouncementAttachmentsTable','default','App',1775537134,33),(120,'2026-04-07-050200','App\\Database\\Migrations\\CreateAnnouncementLikesTable','default','App',1775537134,33),(121,'2026-04-07-050300','App\\Database\\Migrations\\CreateAnnouncementCommentsTable','default','App',1775537134,33),(122,'2026-04-09-000001','App\\Database\\Migrations\\AddLogoAndCoverToCondominiums','default','App',1775690574,34),(123,'2026-04-09-002214','App\\Database\\Migrations\\AddAvatarToUsers','default','App',1775694171,35),(124,'2026-04-10-000001','App\\Database\\Migrations\\AddUsedStatusToQrCodes','default','App',1775792821,36),(125,'2026-04-10-200000','App\\Database\\Migrations\\AddFieldsToAmenities','default','App',1775868404,37),(126,'2026-04-11-000001','App\\Database\\Migrations\\AddWizardFieldsToAmenities','default','App',1775884662,38),(127,'2026-04-11-000002','App\\Database\\Migrations\\CreateAmenitySchedulesTable','default','App',1775884662,38),(128,'2026-04-11-000003','App\\Database\\Migrations\\CreateAmenityDocumentsTable','default','App',1775884662,38),(129,'2026-04-11-060928','App\\Database\\Migrations\\AddHashIdToPolls','default','App',1775887795,39),(130,'2026-04-11-064558','App\\Database\\Migrations\\AllowNullUnitIdInBookings','default','App',1775889977,40),(131,'2026-04-11-072644','App\\Database\\Migrations\\AddHashIdToTenantDocuments','default','App',1775892565,41),(132,'2026-04-12-105600','App\\Database\\Migrations\\AddFinancialSettingsToCondominiums','default','App',1776013051,42),(133,'2026-04-13-214150','App\\Database\\Migrations\\ModifyPaymentsTransactionIdNullable','default','App',1776116563,43),(134,'2026-04-13-215340','App\\Database\\Migrations\\CreateNotificationsTable','default','App',1776117258,44),(135,'2026-04-15-050000','App\\Database\\Migrations\\AddFcmColumnsToDevicePushSubscriptions','default','App',1776230065,45),(136,'2026-04-18-234323','App\\Database\\Migrations\\CreatePaymentRemindersTable','default','App',1776555917,46),(137,'2026-04-19-034146','App\\Database\\Migrations\\AddDelinquencyRestrictionsToCondominiums','default','App',1776570129,47),(138,'2026-04-19-044200','App\\Database\\Migrations\\AddBankDetailsToCondominiums','default','App',1776573793,48),(139,'2026-04-20-230000','App\\Database\\Migrations\\AddBankCardToCondominiums','default','App',1776730546,49),(140,'2026-04-21-000001','App\\Database\\Migrations\\AddSuspendedAtToCondominiums','default','App',1777259738,50),(141,'2026-04-21-160000','App\\Database\\Migrations\\ExtendPlansForUnitBasedPricing','default','App',1777259738,50),(142,'2026-04-21-183818','App\\Database\\Migrations\\AddStripeFieldsToCondominiums','default','App',1777259738,50),(143,'2026-04-21-191645','App\\Database\\Migrations\\AddStripePricesToPlans','default','App',1777259738,50),(144,'2026-04-22-043700','App\\Database\\Migrations\\AddPaymentMethodToCondominiums','default','App',1777259738,50),(145,'2026-04-22-043701','App\\Database\\Migrations\\CreateSaasPaymentsTable','default','App',1777259738,50),(146,'2026-04-22-060457','App\\Database\\Migrations\\AddSubscriptionStatusToCondominiums','default','App',1777259738,50),(147,'2026-04-26-000001','App\\Database\\Migrations\\AddIsOwnerToUserCondominiumRoles','default','App',1777259739,50),(148,'2026-04-26-093942','App\\Database\\Migrations\\AddPaymentApprovalModeToCondominiums','default','App',1777259739,50),(149,'2026-04-26-193428','App\\Database\\Migrations\\Test','default','App',1777259739,50),(150,'2026-04-27-011806','App\\Database\\Migrations\\CreateMonthlyChargeRunsTable','default','App',1777259739,50),(151,'2026-04-27-012912','App\\Database\\Migrations\\AddIndexesToFinancialTransactions','default','App',1777259739,50);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monthly_charge_runs`
--

DROP TABLE IF EXISTS `monthly_charge_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_charge_runs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` int unsigned NOT NULL,
  `period` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `source` enum('cron','on_access') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'cron',
  `status` enum('processing','success','failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'processing',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_condominium_period` (`condominium_id`,`period`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monthly_charge_runs`
--

LOCK TABLES `monthly_charge_runs` WRITE;
/*!40000 ALTER TABLE `monthly_charge_runs` DISABLE KEYS */;
INSERT INTO `monthly_charge_runs` VALUES (1,2,'2026-04','2026-04-26 21:22:00','on_access','success','2026-04-26 21:22:00','2026-04-26 21:22:00'),(49,8,'2026-04','2026-04-28 09:57:12','on_access','success','2026-04-28 15:57:12','2026-04-28 15:57:12'),(55,5,'2026-04','2026-04-28 10:26:23','cron','success','2026-04-28 16:26:22','2026-04-28 16:26:22');
/*!40000 ALTER TABLE `monthly_charge_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'payment_approved, payment_rejected, general, maintenance, etc.',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `data` json DEFAULT NULL COMMENT 'Extra payload (payment_id, amount, etc.)',
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_condominium_id_foreign` (`condominium_id`),
  KEY `user_id_read_at` (`user_id`,`read_at`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `notifications_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=698 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (296,2,7,'announcement','? Nuevo Aviso','Comunicado&nbsp;Colonos\r\n\r\n&nbsp;\r\n\r\nQué hace:\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n&nbsp;\r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n&nbsp;\r\n\r\nRecomendación:\r\n\r\nUn co','{\"category\": \"general\", \"announcement_id\": 93}',NULL,'2026-04-15 13:56:33','2026-04-15 13:56:33'),(297,2,9,'announcement','? Nuevo Aviso','Comunicado&nbsp;Colonos\r\n\r\n&nbsp;\r\n\r\nQué hace:\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n&nbsp;\r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n&nbsp;\r\n\r\nRecomendación:\r\n\r\nUn co','{\"category\": \"general\", \"announcement_id\": 93}',NULL,'2026-04-15 13:56:33','2026-04-15 13:56:33'),(298,2,10,'announcement','? Nuevo Aviso','Comunicado&nbsp;Colonos\r\n\r\n&nbsp;\r\n\r\nQué hace:\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n&nbsp;\r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n&nbsp;\r\n\r\nRecomendación:\r\n\r\nUn co','{\"category\": \"general\", \"announcement_id\": 93}','2026-04-16 12:36:15','2026-04-15 13:56:33','2026-04-15 13:56:33'),(299,2,11,'announcement','? Nuevo Aviso','Comunicado&nbsp;Colonos\r\n\r\n&nbsp;\r\n\r\nQué hace:\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n&nbsp;\r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n&nbsp;\r\n\r\nRecomendación:\r\n\r\nUn co','{\"category\": \"general\", \"announcement_id\": 93}','2026-04-15 14:21:55','2026-04-15 13:56:33','2026-04-15 13:56:33'),(300,2,7,'announcement','? Nuevo Aviso','otro mas con foto y video&nbsp;','{\"category\": \"general\", \"announcement_id\": 94}',NULL,'2026-04-15 13:57:17','2026-04-15 13:57:17'),(301,2,9,'announcement','? Nuevo Aviso','otro mas con foto y video&nbsp;','{\"category\": \"general\", \"announcement_id\": 94}',NULL,'2026-04-15 13:57:17','2026-04-15 13:57:17'),(302,2,10,'announcement','? Nuevo Aviso','otro mas con foto y video&nbsp;','{\"category\": \"general\", \"announcement_id\": 94}','2026-04-16 12:36:15','2026-04-15 13:57:17','2026-04-15 13:57:17'),(303,2,11,'announcement','? Nuevo Aviso','otro mas con foto y video&nbsp;','{\"category\": \"general\", \"announcement_id\": 94}','2026-04-15 13:58:31','2026-04-15 13:57:17','2026-04-15 13:57:17'),(304,2,7,'announcement','? Nuevo Aviso','Nuevao anuncio miestrsa habro otra app','{\"category\": \"general\", \"announcement_id\": 95}',NULL,'2026-04-15 14:17:56','2026-04-15 14:17:56'),(305,2,9,'announcement','? Nuevo Aviso','Nuevao anuncio miestrsa habro otra app','{\"category\": \"general\", \"announcement_id\": 95}',NULL,'2026-04-15 14:17:56','2026-04-15 14:17:56'),(306,2,10,'announcement','? Nuevo Aviso','Nuevao anuncio miestrsa habro otra app','{\"category\": \"general\", \"announcement_id\": 95}','2026-04-16 12:36:15','2026-04-15 14:17:56','2026-04-15 14:17:56'),(307,2,11,'announcement','? Nuevo Aviso','Nuevao anuncio miestrsa habro otra app','{\"category\": \"general\", \"announcement_id\": 95}','2026-04-15 14:18:27','2026-04-15 14:17:56','2026-04-15 14:17:56'),(308,2,7,'announcement','? Nuevo Aviso','ok','{\"category\": \"general\", \"announcement_id\": 96}',NULL,'2026-04-15 14:18:35','2026-04-15 14:18:35'),(309,2,9,'announcement','? Nuevo Aviso','ok','{\"category\": \"general\", \"announcement_id\": 96}',NULL,'2026-04-15 14:18:35','2026-04-15 14:18:35'),(310,2,10,'announcement','? Nuevo Aviso','ok','{\"category\": \"general\", \"announcement_id\": 96}','2026-04-16 12:36:15','2026-04-15 14:18:35','2026-04-15 14:18:35'),(311,2,11,'announcement','? Nuevo Aviso','ok','{\"category\": \"general\", \"announcement_id\": 96}','2026-04-15 14:21:19','2026-04-15 14:18:35','2026-04-15 14:18:35'),(312,2,7,'announcement','? Nuevo Aviso','Nuevos anuncios','{\"category\": \"general\", \"announcement_id\": 97}',NULL,'2026-04-15 17:14:33','2026-04-15 17:14:33'),(313,2,9,'announcement','? Nuevo Aviso','Nuevos anuncios','{\"category\": \"general\", \"announcement_id\": 97}',NULL,'2026-04-15 17:14:33','2026-04-15 17:14:33'),(314,2,10,'announcement','? Nuevo Aviso','Nuevos anuncios','{\"category\": \"general\", \"announcement_id\": 97}','2026-04-16 12:36:15','2026-04-15 17:14:33','2026-04-15 17:14:33'),(315,2,11,'announcement','? Nuevo Aviso','Nuevos anuncios','{\"category\": \"general\", \"announcement_id\": 97}','2026-04-15 17:15:38','2026-04-15 17:14:33','2026-04-15 17:14:33'),(316,2,4,'amenidad','Nueva Reserva de Amenidad','El residente ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 19:53:29','2026-04-15 19:53:29'),(317,2,18,'amenidad','Nueva Reserva de Amenidad','El residente ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 19:53:29','2026-04-15 19:53:29'),(318,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva de amenidad ha sido aprobada.',NULL,'2026-04-15 19:54:14','2026-04-15 19:54:06','2026-04-15 19:54:06'),(319,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,'2026-04-16 18:13:06','2026-04-15 20:04:55','2026-04-15 20:04:55'),(320,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,NULL,'2026-04-15 20:04:55','2026-04-15 20:04:55'),(321,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 20:14:16','2026-04-15 20:14:16'),(322,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 20:14:16','2026-04-15 20:14:16'),(323,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 18/04/2026 a las 09:00 ha sido aprobada.',NULL,'2026-04-15 20:15:19','2026-04-15 20:14:43','2026-04-15 20:14:43'),(324,2,7,'announcement','? Nuevo Aviso','nUEVA FUNCION AMENIDAD','{\"category\": \"general\", \"announcement_id\": 100}',NULL,'2026-04-15 20:34:59','2026-04-15 20:34:59'),(325,2,9,'announcement','? Nuevo Aviso','nUEVA FUNCION AMENIDAD','{\"category\": \"general\", \"announcement_id\": 100}',NULL,'2026-04-15 20:34:59','2026-04-15 20:34:59'),(326,2,10,'announcement','? Nuevo Aviso','nUEVA FUNCION AMENIDAD','{\"category\": \"general\", \"announcement_id\": 100}','2026-04-16 12:36:15','2026-04-15 20:34:59','2026-04-15 20:34:59'),(327,2,11,'announcement','? Nuevo Aviso','nUEVA FUNCION AMENIDAD','{\"category\": \"general\", \"announcement_id\": 100}','2026-04-15 20:35:12','2026-04-15 20:34:59','2026-04-15 20:34:59'),(328,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 20:36:00','2026-04-15 20:36:00'),(329,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 20:36:00','2026-04-15 20:36:00'),(330,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 22/04/2026 a las 09:00 ha sido aprobada.',NULL,'2026-04-15 20:42:28','2026-04-15 20:36:45','2026-04-15 20:36:45'),(331,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 20:37:12','2026-04-15 20:37:12'),(332,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 20:37:12','2026-04-15 20:37:12'),(333,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 18/04/2026 a las 12:00 ha sido aprobada.',NULL,'2026-04-15 20:42:27','2026-04-15 20:37:21','2026-04-15 20:37:21'),(334,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 20:37:40','2026-04-15 20:37:40'),(335,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 20:37:40','2026-04-15 20:37:40'),(336,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 18/04/2026 a las 15:00 ha sido aprobada.',NULL,'2026-04-15 20:42:27','2026-04-15 20:37:50','2026-04-15 20:37:50'),(337,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 20:56:37','2026-04-15 20:56:37'),(338,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 20:56:37','2026-04-15 20:56:37'),(339,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 30/04/2026 a las 15:00 ha sido aprobada.',NULL,'2026-04-15 21:01:34','2026-04-15 20:57:59','2026-04-15 20:57:59'),(340,2,7,'announcement','? Nuevo Aviso','Nuevo EThan as','{\"category\": \"general\", \"announcement_id\": 101}',NULL,'2026-04-15 21:02:00','2026-04-15 21:02:00'),(341,2,9,'announcement','? Nuevo Aviso','Nuevo EThan as','{\"category\": \"general\", \"announcement_id\": 101}',NULL,'2026-04-15 21:02:00','2026-04-15 21:02:00'),(342,2,10,'announcement','? Nuevo Aviso','Nuevo EThan as','{\"category\": \"general\", \"announcement_id\": 101}','2026-04-16 12:36:15','2026-04-15 21:02:00','2026-04-15 21:02:00'),(343,2,11,'announcement','? Nuevo Aviso','Nuevo EThan as','{\"category\": \"general\", \"announcement_id\": 101}','2026-04-15 21:06:20','2026-04-15 21:02:00','2026-04-15 21:02:00'),(344,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-15 21:18:01','2026-04-15 21:18:01'),(345,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-15 21:18:01','2026-04-15 21:18:01'),(346,2,11,'amenidad','Reserva Rechazada','Tu solicitud de reserva para Jacuzzi el 18/04/2026 a las 09:00 no pudo ser aprobada.',NULL,'2026-04-15 21:18:37','2026-04-15 21:18:19','2026-04-15 21:18:19'),(347,2,7,'announcement','? Nuevo Aviso','Prueba de anuncio en app cerrada','{\"category\": \"general\", \"announcement_id\": 102}',NULL,'2026-04-15 21:21:18','2026-04-15 21:21:18'),(348,2,9,'announcement','? Nuevo Aviso','Prueba de anuncio en app cerrada','{\"category\": \"general\", \"announcement_id\": 102}',NULL,'2026-04-15 21:21:18','2026-04-15 21:21:18'),(349,2,10,'announcement','? Nuevo Aviso','Prueba de anuncio en app cerrada','{\"category\": \"general\", \"announcement_id\": 102}','2026-04-16 12:36:15','2026-04-15 21:21:18','2026-04-15 21:21:18'),(350,2,11,'announcement','? Nuevo Aviso','Prueba de anuncio en app cerrada','{\"category\": \"general\", \"announcement_id\": 102}','2026-04-15 21:22:21','2026-04-15 21:21:18','2026-04-15 21:21:18'),(351,2,7,'announcement','? Nuevo Aviso','Ultimo cerrado Android','{\"category\": \"general\", \"announcement_id\": 103}',NULL,'2026-04-15 21:52:11','2026-04-15 21:52:11'),(352,2,9,'announcement','? Nuevo Aviso','Ultimo cerrado Android','{\"category\": \"general\", \"announcement_id\": 103}',NULL,'2026-04-15 21:52:11','2026-04-15 21:52:11'),(353,2,10,'announcement','? Nuevo Aviso','Ultimo cerrado Android','{\"category\": \"general\", \"announcement_id\": 103}','2026-04-16 12:36:15','2026-04-15 21:52:11','2026-04-15 21:52:11'),(354,2,11,'announcement','? Nuevo Aviso','Ultimo cerrado Android','{\"category\": \"general\", \"announcement_id\": 103}','2026-04-15 21:52:49','2026-04-15 21:52:11','2026-04-15 21:52:11'),(355,2,7,'announcement','? Nuevo Aviso','ANgeles','{\"category\": \"general\", \"announcement_id\": 104}',NULL,'2026-04-16 09:21:41','2026-04-16 09:21:41'),(356,2,9,'announcement','? Nuevo Aviso','ANgeles','{\"category\": \"general\", \"announcement_id\": 104}',NULL,'2026-04-16 09:21:41','2026-04-16 09:21:41'),(357,2,10,'announcement','? Nuevo Aviso','ANgeles','{\"category\": \"general\", \"announcement_id\": 104}','2026-04-16 12:36:15','2026-04-16 09:21:41','2026-04-16 09:21:41'),(358,2,11,'announcement','? Nuevo Aviso','ANgeles','{\"category\": \"general\", \"announcement_id\": 104}','2026-04-16 11:09:11','2026-04-16 09:21:41','2026-04-16 09:21:41'),(359,2,7,'announcement','? Nuevo Aviso','Otrokas','{\"category\": \"general\", \"announcement_id\": 105}',NULL,'2026-04-16 11:02:53','2026-04-16 11:02:53'),(360,2,9,'announcement','? Nuevo Aviso','Otrokas','{\"category\": \"general\", \"announcement_id\": 105}',NULL,'2026-04-16 11:02:53','2026-04-16 11:02:53'),(361,2,10,'announcement','? Nuevo Aviso','Otrokas','{\"category\": \"general\", \"announcement_id\": 105}','2026-04-16 12:36:15','2026-04-16 11:02:53','2026-04-16 11:02:53'),(362,2,11,'announcement','? Nuevo Aviso','Otrokas','{\"category\": \"general\", \"announcement_id\": 105}','2026-04-16 11:09:11','2026-04-16 11:02:53','2026-04-16 11:02:53'),(363,2,7,'announcement','? Nuevo Aviso','Mantenimiento&nbsp;','{\"category\": \"general\", \"announcement_id\": 106}',NULL,'2026-04-16 11:07:15','2026-04-16 11:07:15'),(364,2,9,'announcement','? Nuevo Aviso','Mantenimiento&nbsp;','{\"category\": \"general\", \"announcement_id\": 106}',NULL,'2026-04-16 11:07:15','2026-04-16 11:07:15'),(365,2,10,'announcement','? Nuevo Aviso','Mantenimiento&nbsp;','{\"category\": \"general\", \"announcement_id\": 106}','2026-04-16 12:36:15','2026-04-16 11:07:15','2026-04-16 11:07:15'),(366,2,11,'announcement','? Nuevo Aviso','Mantenimiento&nbsp;','{\"category\": \"general\", \"announcement_id\": 106}','2026-04-16 11:09:11','2026-04-16 11:07:15','2026-04-16 11:07:15'),(367,2,7,'announcement','? Nuevo Aviso','Con imangegesSe hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de line','{\"category\": \"general\", \"announcement_id\": 107}',NULL,'2026-04-16 11:08:23','2026-04-16 11:08:23'),(368,2,9,'announcement','? Nuevo Aviso','Con imangegesSe hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de line','{\"category\": \"general\", \"announcement_id\": 107}',NULL,'2026-04-16 11:08:23','2026-04-16 11:08:23'),(369,2,10,'announcement','? Nuevo Aviso','Con imangegesSe hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de line','{\"category\": \"general\", \"announcement_id\": 107}','2026-04-16 12:36:15','2026-04-16 11:08:23','2026-04-16 11:08:23'),(370,2,11,'announcement','? Nuevo Aviso','Con imangegesSe hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de linea Se hace una salto de line','{\"category\": \"general\", \"announcement_id\": 107}','2026-04-16 11:09:11','2026-04-16 11:08:23','2026-04-16 11:08:23'),(371,2,7,'announcement','? Nuevo Aviso','as','{\"category\": \"general\", \"announcement_id\": 108}',NULL,'2026-04-16 11:08:41','2026-04-16 11:08:41'),(372,2,9,'announcement','? Nuevo Aviso','as','{\"category\": \"general\", \"announcement_id\": 108}',NULL,'2026-04-16 11:08:41','2026-04-16 11:08:41'),(373,2,10,'announcement','? Nuevo Aviso','as','{\"category\": \"general\", \"announcement_id\": 108}','2026-04-16 12:36:15','2026-04-16 11:08:41','2026-04-16 11:08:41'),(374,2,11,'announcement','? Nuevo Aviso','as','{\"category\": \"general\", \"announcement_id\": 108}','2026-04-16 11:09:07','2026-04-16 11:08:41','2026-04-16 11:08:41'),(375,2,7,'announcement','? Nuevo Aviso','Nueva&nbsp;SaldosOk&nbsp;','{\"category\": \"general\", \"announcement_id\": 109}',NULL,'2026-04-16 11:10:21','2026-04-16 11:10:21'),(376,2,9,'announcement','? Nuevo Aviso','Nueva&nbsp;SaldosOk&nbsp;','{\"category\": \"general\", \"announcement_id\": 109}',NULL,'2026-04-16 11:10:21','2026-04-16 11:10:21'),(377,2,10,'announcement','? Nuevo Aviso','Nueva&nbsp;SaldosOk&nbsp;','{\"category\": \"general\", \"announcement_id\": 109}','2026-04-16 12:36:15','2026-04-16 11:10:21','2026-04-16 11:10:21'),(378,2,11,'announcement','? Nuevo Aviso','Nueva&nbsp;SaldosOk&nbsp;','{\"category\": \"general\", \"announcement_id\": 109}','2026-04-16 11:17:19','2026-04-16 11:10:21','2026-04-16 11:10:21'),(379,2,7,'announcement','? Nuevo Aviso','Titulo&nbsp;saldos de tlinea&nbsp;lianasSaludos','{\"category\": \"general\", \"announcement_id\": 110}',NULL,'2026-04-16 11:18:09','2026-04-16 11:18:09'),(380,2,9,'announcement','? Nuevo Aviso','Titulo&nbsp;saldos de tlinea&nbsp;lianasSaludos','{\"category\": \"general\", \"announcement_id\": 110}',NULL,'2026-04-16 11:18:09','2026-04-16 11:18:09'),(381,2,10,'announcement','? Nuevo Aviso','Titulo&nbsp;saldos de tlinea&nbsp;lianasSaludos','{\"category\": \"general\", \"announcement_id\": 110}','2026-04-16 12:36:15','2026-04-16 11:18:09','2026-04-16 11:18:09'),(382,2,11,'announcement','? Nuevo Aviso','Titulo&nbsp;saldos de tlinea&nbsp;lianasSaludos','{\"category\": \"general\", \"announcement_id\": 110}','2026-04-16 12:14:37','2026-04-16 11:18:09','2026-04-16 11:18:09'),(383,2,7,'announcement','? Nuevo Aviso','Nuevo&nbsp;comunicado&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de l','{\"category\": \"general\", \"announcement_id\": 111}',NULL,'2026-04-16 12:15:55','2026-04-16 12:15:55'),(384,2,9,'announcement','? Nuevo Aviso','Nuevo&nbsp;comunicado&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de l','{\"category\": \"general\", \"announcement_id\": 111}',NULL,'2026-04-16 12:15:55','2026-04-16 12:15:55'),(385,2,10,'announcement','? Nuevo Aviso','Nuevo&nbsp;comunicado&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de l','{\"category\": \"general\", \"announcement_id\": 111}','2026-04-16 12:36:15','2026-04-16 12:15:55','2026-04-16 12:15:55'),(386,2,11,'announcement','? Nuevo Aviso','Nuevo&nbsp;comunicado&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de linea&nbsp;&nbsp;Saltos de l','{\"category\": \"general\", \"announcement_id\": 111}','2026-04-16 12:20:34','2026-04-16 12:15:55','2026-04-16 12:15:55'),(387,2,4,'amenidad','Nueva Reserva de Amenidad','Angeles Lopez de la unidad A-104 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-16 12:38:23','2026-04-16 12:38:23'),(388,2,18,'amenidad','Nueva Reserva de Amenidad','Angeles Lopez de la unidad A-104 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-16 12:38:23','2026-04-16 12:38:23'),(389,2,10,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 23/04/2026 a las 15:00 ha sido aprobada.',NULL,'2026-04-16 12:39:00','2026-04-16 12:38:50','2026-04-16 12:38:50'),(390,2,7,'announcement','? Nuevo Aviso','Beaas&nbsp;aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 114}',NULL,'2026-04-16 12:43:40','2026-04-16 12:43:40'),(391,2,9,'announcement','? Nuevo Aviso','Beaas&nbsp;aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 114}',NULL,'2026-04-16 12:43:40','2026-04-16 12:43:40'),(392,2,10,'announcement','? Nuevo Aviso','Beaas&nbsp;aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 114}','2026-04-20 23:08:53','2026-04-16 12:43:40','2026-04-16 12:43:40'),(393,2,11,'announcement','? Nuevo Aviso','Beaas&nbsp;aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 114}','2026-04-16 12:53:15','2026-04-16 12:43:40','2026-04-16 12:43:40'),(394,2,7,'announcement','? Nuevo Aviso','Beaas aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 115}',NULL,'2026-04-16 12:48:34','2026-04-16 12:48:34'),(395,2,9,'announcement','? Nuevo Aviso','Beaas aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 115}',NULL,'2026-04-16 12:48:34','2026-04-16 12:48:34'),(396,2,10,'announcement','? Nuevo Aviso','Beaas aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 115}','2026-04-20 23:08:53','2026-04-16 12:48:34','2026-04-16 12:48:34'),(397,2,11,'announcement','? Nuevo Aviso','Beaas aashsa sh ahsjdhasjdhasdj h asjdsahdajsdhsa dSalusod','{\"category\": \"general\", \"announcement_id\": 115}','2026-04-16 12:52:04','2026-04-16 12:48:34','2026-04-16 12:48:34'),(398,2,7,'announcement','? Nuevo Aviso','Nuevo Anuncio salto otro salto Saludos','{\"category\": \"maintenance\", \"announcement_id\": 116}',NULL,'2026-04-16 12:52:53','2026-04-16 12:52:53'),(399,2,9,'announcement','? Nuevo Aviso','Nuevo Anuncio salto otro salto Saludos','{\"category\": \"maintenance\", \"announcement_id\": 116}',NULL,'2026-04-16 12:52:53','2026-04-16 12:52:53'),(400,2,10,'announcement','? Nuevo Aviso','Nuevo Anuncio salto otro salto Saludos','{\"category\": \"maintenance\", \"announcement_id\": 116}','2026-04-20 23:08:53','2026-04-16 12:52:53','2026-04-16 12:52:53'),(401,2,11,'announcement','? Nuevo Aviso','Nuevo Anuncio salto otro salto Saludos','{\"category\": \"maintenance\", \"announcement_id\": 116}','2026-04-16 12:53:15','2026-04-16 12:52:53','2026-04-16 12:52:53'),(402,2,7,'announcement','? Nuevo Aviso','Nuevo Anuncio Salto daniel salto angeles ','{\"category\": \"general\", \"announcement_id\": 117}',NULL,'2026-04-16 12:54:10','2026-04-16 12:54:10'),(403,2,9,'announcement','? Nuevo Aviso','Nuevo Anuncio Salto daniel salto angeles ','{\"category\": \"general\", \"announcement_id\": 117}',NULL,'2026-04-16 12:54:10','2026-04-16 12:54:10'),(404,2,10,'announcement','? Nuevo Aviso','Nuevo Anuncio Salto daniel salto angeles ','{\"category\": \"general\", \"announcement_id\": 117}','2026-04-20 23:08:53','2026-04-16 12:54:10','2026-04-16 12:54:10'),(405,2,11,'announcement','? Nuevo Aviso','Nuevo Anuncio Salto daniel salto angeles ','{\"category\": \"general\", \"announcement_id\": 117}','2026-04-16 12:55:47','2026-04-16 12:54:10','2026-04-16 12:54:10'),(406,2,7,'announcement','? Nuevo Aviso','asd','{\"category\": \"general\", \"announcement_id\": 118}',NULL,'2026-04-16 12:55:57','2026-04-16 12:55:57'),(407,2,9,'announcement','? Nuevo Aviso','asd','{\"category\": \"general\", \"announcement_id\": 118}',NULL,'2026-04-16 12:55:57','2026-04-16 12:55:57'),(408,2,10,'announcement','? Nuevo Aviso','asd','{\"category\": \"general\", \"announcement_id\": 118}','2026-04-20 23:08:53','2026-04-16 12:55:57','2026-04-16 12:55:57'),(409,2,11,'announcement','? Nuevo Aviso','asd','{\"category\": \"general\", \"announcement_id\": 118}','2026-04-16 13:01:57','2026-04-16 12:55:57','2026-04-16 12:55:57'),(410,2,7,'announcement','? Nuevo Aviso','QUE HACEMOS\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n \r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n \r\n\r\nRecomendación:\r\n\r\nUn commit debe representar un cambio específico.','{\"category\": \"general\", \"announcement_id\": 119}',NULL,'2026-04-16 12:57:24','2026-04-16 12:57:24'),(411,2,9,'announcement','? Nuevo Aviso','QUE HACEMOS\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n \r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n \r\n\r\nRecomendación:\r\n\r\nUn commit debe representar un cambio específico.','{\"category\": \"general\", \"announcement_id\": 119}',NULL,'2026-04-16 12:57:24','2026-04-16 12:57:24'),(412,2,10,'announcement','? Nuevo Aviso','QUE HACEMOS\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n \r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n \r\n\r\nRecomendación:\r\n\r\nUn commit debe representar un cambio específico.','{\"category\": \"general\", \"announcement_id\": 119}','2026-04-20 23:08:53','2026-04-16 12:57:24','2026-04-16 12:57:24'),(413,2,11,'announcement','? Nuevo Aviso','QUE HACEMOS\r\n\r\nGuarda un punto de respaldo del código.\r\n\r\n \r\n\r\nCuándo usarlo:\r\n\r\nDespués de completar un cambio importante.\r\n\r\n \r\n\r\nRecomendación:\r\n\r\nUn commit debe representar un cambio específico.','{\"category\": \"general\", \"announcement_id\": 119}','2026-04-16 12:58:57','2026-04-16 12:57:24','2026-04-16 12:57:24'),(414,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Aviso urgen te','{\"category\": \"urgent\", \"announcement_id\": 120}',NULL,'2026-04-16 13:00:42','2026-04-16 13:00:42'),(415,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Aviso urgen te','{\"category\": \"urgent\", \"announcement_id\": 120}',NULL,'2026-04-16 13:00:42','2026-04-16 13:00:42'),(416,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Aviso urgen te','{\"category\": \"urgent\", \"announcement_id\": 120}','2026-04-20 23:08:53','2026-04-16 13:00:42','2026-04-16 13:00:42'),(417,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Aviso urgen te','{\"category\": \"urgent\", \"announcement_id\": 120}','2026-04-16 13:01:57','2026-04-16 13:00:42','2026-04-16 13:00:42'),(418,2,4,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ok s','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"7\"}','2026-04-16 18:13:06','2026-04-16 14:03:56','2026-04-16 14:03:56'),(419,2,18,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ok s','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"7\"}',NULL,'2026-04-16 14:03:56','2026-04-16 14:03:56'),(420,2,11,'ticket','? Daniel Zubiri respondió tu reporte','Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"7\"}','2026-04-16 14:11:56','2026-04-16 14:11:10','2026-04-16 14:11:10'),(421,2,4,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ya quefo ?','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"7\"}','2026-04-16 18:13:06','2026-04-16 14:24:39','2026-04-16 14:24:39'),(422,2,18,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ya quefo ?','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"7\"}',NULL,'2026-04-16 14:24:39','2026-04-16 14:24:39'),(423,2,11,'ticket','? Daniel Zubiri respondió tu reporte','si','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"7\"}','2026-04-16 14:29:52','2026-04-16 14:26:12','2026-04-16 14:26:12'),(424,2,11,'ticket','? Daniel Zubiri respondió tu reporte','El problema ha sido resuelto. Por favor háganos saber si necesita algo más.','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"7\"}','2026-04-16 14:29:52','2026-04-16 14:29:15','2026-04-16 14:29:15'),(425,2,11,'ticket','? Daniel Zubiri respondió tu reporte','Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"7\"}','2026-04-16 14:29:52','2026-04-16 14:29:30','2026-04-16 14:29:30'),(426,2,11,'ticket','✅ Tu reporte fue resuelto','Tu reporte \"orovlea en piso\" ha sido marcado como resuelto.','{\"type\": \"ticket_resolved\", \"ticket_id\": \"7\"}','2026-04-16 14:29:52','2026-04-16 14:29:31','2026-04-16 14:29:31'),(427,2,4,'ticket','? Nuevo Reporte','benjamin zubiri3 reportó: prueba video','{\"type\": \"ticket_created\", \"ticket_id\": 8}','2026-04-16 18:13:06','2026-04-16 14:41:37','2026-04-16 14:41:37'),(428,2,18,'ticket','? Nuevo Reporte','benjamin zubiri3 reportó: prueba video','{\"type\": \"ticket_created\", \"ticket_id\": 8}',NULL,'2026-04-16 14:41:37','2026-04-16 14:41:37'),(429,2,11,'ticket','? Daniel Zubiri respondió tu reporte','El trabajo en su reporte ha comenzado. Le mantendremos informado.','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"8\"}','2026-04-16 17:18:17','2026-04-16 14:42:38','2026-04-16 14:42:38'),(430,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,'2026-04-16 18:13:06','2026-04-16 17:41:31','2026-04-16 17:41:31'),(431,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,NULL,'2026-04-16 17:41:31','2026-04-16 17:41:31'),(432,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,'2026-04-16 18:13:06','2026-04-16 17:54:10','2026-04-16 17:54:10'),(433,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,NULL,'2026-04-16 17:54:10','2026-04-16 17:54:10'),(434,2,4,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ? Adjunto','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"8\"}','2026-04-16 18:13:06','2026-04-16 18:00:04','2026-04-16 18:00:04'),(435,2,18,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ? Adjunto','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"8\"}',NULL,'2026-04-16 18:00:04','2026-04-16 18:00:04'),(436,2,4,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ? Adjunto','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"8\"}','2026-04-16 18:13:06','2026-04-16 18:00:38','2026-04-16 18:00:38'),(437,2,18,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ? Adjunto','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"8\"}',NULL,'2026-04-16 18:00:38','2026-04-16 18:00:38'),(438,2,11,'ticket','? Daniel Zubiri respondió tu reporte','Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"8\"}','2026-04-16 19:14:22','2026-04-16 18:00:54','2026-04-16 18:00:54'),(439,2,4,'ticket','✅ Tu reporte fue resuelto','Tu reporte \"tiCKET DE PRUEBA\" ha sido marcado como resuelto.','{\"type\": \"ticket_resolved\", \"ticket_id\": \"6\"}','2026-04-16 18:13:06','2026-04-16 18:06:26','2026-04-16 18:06:26'),(440,2,1,'ticket','? Daniel Zubiri respondió tu reporte','Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"5\"}',NULL,'2026-04-16 18:06:41','2026-04-16 18:06:41'),(441,2,1,'ticket','✅ Tu reporte fue resuelto','Tu reporte \"teas\" ha sido marcado como resuelto.','{\"type\": \"ticket_resolved\", \"ticket_id\": \"5\"}',NULL,'2026-04-16 18:06:41','2026-04-16 18:06:41'),(442,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-16 18:13:06','2026-04-16 18:08:49','2026-04-16 18:08:49'),(443,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-16 18:08:49','2026-04-16 18:08:49'),(444,2,4,'payment_status','Comprobante Subido','benjamin zubiri3 subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-17 00:19:16','2026-04-16 18:18:50','2026-04-16 18:18:50'),(445,2,18,'payment_status','Comprobante Subido','benjamin zubiri3 subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-16 18:18:50','2026-04-16 18:18:50'),(446,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $5,000.00 ha sido aprobado por la administración.','{\"amount\": 5000, \"payment_id\": 29}','2026-04-16 19:14:22','2026-04-16 18:21:52','2026-04-16 18:21:52'),(447,2,11,'payment_rejected','Pago rechazado','Tu comprobante de pago ha sido rechazado. Motivo: duplicado','{\"payment_id\": 28}','2026-04-16 19:14:22','2026-04-16 18:58:01','2026-04-16 18:58:01'),(448,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 29/04/2026 a las 09:00 ha sido aprobada.',NULL,'2026-04-16 21:05:31','2026-04-16 21:05:14','2026-04-16 21:05:14'),(449,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado UrgenteComunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Co','{\"category\": \"general\", \"announcement_id\": 121}',NULL,'2026-04-16 21:18:05','2026-04-16 21:18:05'),(450,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado UrgenteComunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Co','{\"category\": \"general\", \"announcement_id\": 121}',NULL,'2026-04-16 21:18:05','2026-04-16 21:18:05'),(451,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado UrgenteComunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Co','{\"category\": \"general\", \"announcement_id\": 121}','2026-04-20 23:08:53','2026-04-16 21:18:05','2026-04-16 21:18:05'),(452,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado UrgenteComunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Comunicado Urgente, Co','{\"category\": \"general\", \"announcement_id\": 121}','2026-04-16 21:44:55','2026-04-16 21:18:05','2026-04-16 21:18:05'),(453,2,4,'payment_status','Comprobante Subido','benjamin zubiri3 subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-17 00:19:16','2026-04-16 21:35:05','2026-04-16 21:35:05'),(454,2,18,'payment_status','Comprobante Subido','benjamin zubiri3 subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-16 21:35:05','2026-04-16 21:35:05'),(455,2,11,'ticket','? Daniel Zubiri respondió tu reporte','Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"8\"}','2026-04-16 22:13:40','2026-04-16 21:55:05','2026-04-16 21:55:05'),(456,2,11,'ticket','✅ Tu reporte fue resuelto','Tu reporte \"prueba video\" ha sido marcado como resuelto.','{\"type\": \"ticket_resolved\", \"ticket_id\": \"8\"}','2026-04-16 22:13:39','2026-04-16 21:55:06','2026-04-16 21:55:06'),(457,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,'2026-04-17 00:19:16','2026-04-16 22:14:32','2026-04-16 22:14:32'),(458,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,NULL,'2026-04-16 22:14:32','2026-04-16 22:14:32'),(459,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Prueba Mensaje','{\"category\": \"general\", \"announcement_id\": 122}',NULL,'2026-04-16 22:56:28','2026-04-16 22:56:28'),(460,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Prueba Mensaje','{\"category\": \"general\", \"announcement_id\": 122}',NULL,'2026-04-16 22:56:28','2026-04-16 22:56:28'),(461,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Prueba Mensaje','{\"category\": \"general\", \"announcement_id\": 122}','2026-04-20 23:08:53','2026-04-16 22:56:28','2026-04-16 22:56:28'),(462,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Prueba Mensaje','{\"category\": \"general\", \"announcement_id\": 122}','2026-04-16 22:57:05','2026-04-16 22:56:28','2026-04-16 22:56:28'),(463,2,7,'poll_new','Nueva encuesta','? Nueva encuesta disponible: nueva 3','{\"type\": \"poll\"}',NULL,'2026-04-17 00:38:54','2026-04-17 00:38:54'),(464,2,9,'poll_new','Nueva encuesta','? Nueva encuesta disponible: nueva 3','{\"type\": \"poll\"}',NULL,'2026-04-17 00:38:54','2026-04-17 00:38:54'),(465,2,10,'poll_new','Nueva encuesta','? Nueva encuesta disponible: nueva 3','{\"type\": \"poll\"}','2026-04-20 23:08:53','2026-04-17 00:38:54','2026-04-17 00:38:54'),(466,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: nueva 3','{\"type\": \"poll\"}','2026-04-17 00:39:04','2026-04-17 00:38:54','2026-04-17 00:38:54'),(467,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente benjamin zubiri3 de la unidad Sin unidad votó en la encuesta \'nueva 3\'','{\"type\": \"poll\"}','2026-04-17 15:40:22','2026-04-17 00:44:11','2026-04-17 00:44:11'),(468,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente benjamin zubiri3 de la unidad Sin unidad votó en la encuesta \'nueva 3\'','{\"type\": \"poll\"}',NULL,'2026-04-17 00:44:11','2026-04-17 00:44:11'),(469,2,4,'poll_activity','Cambio de voto','? El residente benjamin zubiri3 cambió su voto en la encuesta \'nueva 3\'','{\"type\": \"poll\"}','2026-04-17 15:40:22','2026-04-17 00:52:06','2026-04-17 00:52:06'),(470,2,18,'poll_activity','Cambio de voto','? El residente benjamin zubiri3 cambió su voto en la encuesta \'nueva 3\'','{\"type\": \"poll\"}',NULL,'2026-04-17 00:52:06','2026-04-17 00:52:06'),(471,2,7,'poll_new','Nueva encuesta','? Nueva encuesta disponible: otra encuesta de prueba','{\"type\": \"poll\"}',NULL,'2026-04-17 00:55:47','2026-04-17 00:55:47'),(472,2,9,'poll_new','Nueva encuesta','? Nueva encuesta disponible: otra encuesta de prueba','{\"type\": \"poll\"}',NULL,'2026-04-17 00:55:47','2026-04-17 00:55:47'),(473,2,10,'poll_new','Nueva encuesta','? Nueva encuesta disponible: otra encuesta de prueba','{\"type\": \"poll\"}','2026-04-20 23:08:53','2026-04-17 00:55:47','2026-04-17 00:55:47'),(474,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: otra encuesta de prueba','{\"type\": \"poll\"}','2026-04-17 00:55:58','2026-04-17 00:55:47','2026-04-17 00:55:47'),(475,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente benjamin zubiri3 de la unidad A-100 votó en la encuesta \'otra encuesta de prueba\'','{\"type\": \"poll\"}','2026-04-17 15:40:22','2026-04-17 01:06:41','2026-04-17 01:06:41'),(476,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente benjamin zubiri3 de la unidad A-100 votó en la encuesta \'otra encuesta de prueba\'','{\"type\": \"poll\"}',NULL,'2026-04-17 01:06:41','2026-04-17 01:06:41'),(477,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-17 15:40:22','2026-04-17 01:13:53','2026-04-17 01:13:53'),(478,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-17 01:13:53','2026-04-17 01:13:53'),(479,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 24/04/2026 a las 09:00 ha sido aprobada.',NULL,'2026-04-17 01:25:29','2026-04-17 01:25:08','2026-04-17 01:25:08'),(480,2,4,'ticket','? Nuevo Reporte','benjamin zubiri3 reportó: no funciona luminaria','{\"type\": \"ticket_created\", \"ticket_id\": 9}','2026-04-17 15:40:22','2026-04-17 01:26:26','2026-04-17 01:26:26'),(481,2,18,'ticket','? Nuevo Reporte','benjamin zubiri3 reportó: no funciona luminaria','{\"type\": \"ticket_created\", \"ticket_id\": 9}',NULL,'2026-04-17 01:26:26','2026-04-17 01:26:26'),(482,2,4,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-17 15:40:22','2026-04-17 01:28:49','2026-04-17 01:28:49'),(483,2,18,'amenidad','Nueva Reserva de Amenidad','benjamin zubiri3 de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-17 01:28:49','2026-04-17 01:28:49'),(484,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Rafael','{\"category\": \"general\", \"announcement_id\": 123}',NULL,'2026-04-17 08:46:53','2026-04-17 08:46:53'),(485,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Rafael','{\"category\": \"general\", \"announcement_id\": 123}',NULL,'2026-04-17 08:46:53','2026-04-17 08:46:53'),(486,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Rafael','{\"category\": \"general\", \"announcement_id\": 123}','2026-04-20 23:08:53','2026-04-17 08:46:53','2026-04-17 08:46:53'),(487,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Rafael','{\"category\": \"general\", \"announcement_id\": 123}','2026-04-17 08:47:13','2026-04-17 08:46:53','2026-04-17 08:46:53'),(488,2,4,'poll_activity','Cambio de voto','? El residente benjamin zubiri3 cambió su voto en la encuesta \'otra encuesta de prueba\'','{\"type\": \"poll\"}','2026-04-17 15:40:22','2026-04-17 09:35:47','2026-04-17 09:35:47'),(489,2,18,'poll_activity','Cambio de voto','? El residente benjamin zubiri3 cambió su voto en la encuesta \'otra encuesta de prueba\'','{\"type\": \"poll\"}',NULL,'2026-04-17 09:35:47','2026-04-17 09:35:47'),(490,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente benjamin zubiri3 de la unidad A-100 votó en la encuesta \'nUEVA DANIEL\'','{\"type\": \"poll\"}','2026-04-17 15:40:22','2026-04-17 10:24:21','2026-04-17 10:24:21'),(491,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente benjamin zubiri3 de la unidad A-100 votó en la encuesta \'nUEVA DANIEL\'','{\"type\": \"poll\"}',NULL,'2026-04-17 10:24:21','2026-04-17 10:24:21'),(492,2,4,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ok','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-17 15:40:22','2026-04-17 10:26:57','2026-04-17 10:26:57'),(493,2,18,'ticket','? Nuevo comentario en reporte','benjamin zubiri3: ok','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-17 10:26:57','2026-04-17 10:26:57'),(494,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','cARLOTA','{\"category\": \"general\", \"announcement_id\": 127}',NULL,'2026-04-17 10:39:54','2026-04-17 10:39:54'),(495,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','cARLOTA','{\"category\": \"general\", \"announcement_id\": 127}',NULL,'2026-04-17 10:39:54','2026-04-17 10:39:54'),(496,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','cARLOTA','{\"category\": \"general\", \"announcement_id\": 127}','2026-04-20 23:08:53','2026-04-17 10:39:54','2026-04-17 10:39:54'),(497,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','cARLOTA','{\"category\": \"general\", \"announcement_id\": 127}','2026-04-17 11:21:07','2026-04-17 10:39:54','2026-04-17 10:39:54'),(498,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','hOLAS','{\"category\": \"general\", \"announcement_id\": 128}',NULL,'2026-04-17 10:42:21','2026-04-17 10:42:21'),(499,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','hOLAS','{\"category\": \"general\", \"announcement_id\": 128}',NULL,'2026-04-17 10:42:21','2026-04-17 10:42:21'),(500,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','hOLAS','{\"category\": \"general\", \"announcement_id\": 128}','2026-04-20 23:08:53','2026-04-17 10:42:21','2026-04-17 10:42:21'),(501,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','hOLAS','{\"category\": \"general\", \"announcement_id\": 128}','2026-04-17 11:15:10','2026-04-17 10:42:21','2026-04-17 10:42:21'),(502,2,11,'access_entry','Tu visita ha llegado','Entrada – CONDOMINIO ZUBIRI\nbay acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 0, \"condominio_id\": 2}','2026-04-17 11:20:14','2026-04-17 11:20:04','2026-04-17 11:20:04'),(503,2,11,'access_exit','Tu visita ha salido','Salida – CONDOMINIO ZUBIRI\nKAREN acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 91, \"condominio_id\": 2}','2026-04-17 11:29:07','2026-04-17 11:22:37','2026-04-17 11:22:37'),(504,2,11,'access_exit','Tu visita ha salido','Salida – CONDOMINIO ZUBIRI\nbay acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 92, \"condominio_id\": 2}','2026-04-17 11:28:58','2026-04-17 11:23:49','2026-04-17 11:23:49'),(505,2,11,'access_entry','Tu visita ha llegado','Entrada – CONDOMINIO ZUBIRI\ndulce acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 59, \"condominio_id\": 2}','2026-04-17 12:11:18','2026-04-17 11:53:20','2026-04-17 11:53:20'),(506,2,11,'parcel_arrival','Tu paquete ha llegado','? Paquete recibido – CONDOMINIO ZUBIRI\nTienes 1 Paquete recibido(s) en portería vía Mercado Libre.','{\"tipo\": \"paquete_entrada\", \"unit_id\": 296, \"parcel_id\": 23, \"condominio_id\": 2}','2026-04-17 12:08:44','2026-04-17 12:08:34','2026-04-17 12:08:34'),(507,2,11,'parcel_delivered','Paquete entregado','? Paquete entregado – CONDOMINIO ZUBIRI\nPaquete recogido por: benjamin zubiri3','{\"tipo\": \"paquete_salida\", \"unit_id\": 296, \"parcel_id\": 23, \"condominio_id\": 2}','2026-04-17 12:11:16','2026-04-17 12:10:55','2026-04-17 12:10:55'),(508,2,11,'parcel_arrival','Tu paquete ha llegado','Paquete recibido – CONDOMINIO ZUBIRI\nTienes 3 Sobre recibido(s) en Caseta 3 vía Mercado Libre.','{\"tipo\": \"paquete_entrada\", \"unit_id\": 296, \"parcel_id\": 24, \"condominio_id\": 2}','2026-04-17 12:18:08','2026-04-17 12:17:35','2026-04-17 12:17:35'),(509,2,11,'parcel_delivered','Paquete entregado','? Paquete entregado – CONDOMINIO ZUBIRI\nSobre recogido por: benjamin zubiri3','{\"tipo\": \"paquete_salida\", \"unit_id\": 296, \"parcel_id\": 24, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 12:19:56','2026-04-17 12:19:56'),(510,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $5,000.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 5000, \"payment_id\": 30}','2026-04-17 12:21:12','2026-04-17 12:20:51','2026-04-17 12:20:51'),(511,2,4,'payment_status','Comprobante Subido','benjamin zubiri3 subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-17 15:40:22','2026-04-17 12:22:06','2026-04-17 12:22:06'),(512,2,18,'payment_status','Comprobante Subido','benjamin zubiri3 subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-17 12:22:06','2026-04-17 12:22:06'),(513,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $500.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 500, \"payment_id\": 31}','2026-04-17 12:22:44','2026-04-17 12:22:27','2026-04-17 12:22:27'),(514,2,11,'access_exit','Tu visita ha salido','Salida – CONDOMINIO ZUBIRI\ndulce acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 59, \"condominio_id\": 2}','2026-04-17 12:31:49','2026-04-17 12:25:12','2026-04-17 12:25:12'),(515,2,11,'parcel_arrival','Tu paquete ha llegado','Paquete recibido – CONDOMINIO ZUBIRI\nTienes 1 Paquete recibido(s) en Caseta 3 vía 99 Minutos.','{\"tipo\": \"paquete_entrada\", \"unit_id\": 296, \"parcel_id\": 25, \"condominio_id\": 2}','2026-04-17 12:40:28','2026-04-17 12:40:17','2026-04-17 12:40:17'),(516,2,11,'access_entry','Tu visita ha llegado','Entrada – CONDOMINIO ZUBIRI\nJUEZ acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 0, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 12:43:47','2026-04-17 12:43:47'),(517,2,11,'access_exit','Tu visita ha salido','Salida – CONDOMINIO ZUBIRI\nJUEZ acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 97, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 12:56:58','2026-04-17 12:56:58'),(518,2,11,'access_entry','Tu visita ha llegado','Entrada – CONDOMINIO ZUBIRI\nDENISE acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 60, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 12:57:58','2026-04-17 12:57:58'),(519,2,11,'parcel_delivered','Paquete entregado','? Paquete entregado – CONDOMINIO ZUBIRI\nPaquete recogido por: benjamin zubiri3','{\"tipo\": \"paquete_salida\", \"unit_id\": 296, \"parcel_id\": 25, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 13:02:08','2026-04-17 13:02:08'),(520,2,11,'parcel_arrival','Tu paquete ha llegado','Paquete recibido – CONDOMINIO ZUBIRI\nTienes 2 Sobre recibido(s) en Caseta 3 vía Amazon.','{\"tipo\": \"paquete_entrada\", \"unit_id\": 296, \"parcel_id\": 27, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 13:07:34','2026-04-17 13:07:34'),(521,2,11,'access_exit','Tu visita ha salido','Salida – CONDOMINIO ZUBIRI\nDENISE acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 60, \"condominio_id\": 2}','2026-04-17 13:20:00','2026-04-17 13:10:52','2026-04-17 13:10:52'),(522,2,11,'access_entry','Tu visita ha llegado','Entrada - PEPELOBO acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 61, \"condominio_id\": 2}','2026-04-17 13:25:52','2026-04-17 13:21:14','2026-04-17 13:21:14'),(523,2,11,'access_exit','Tu visita ha salido','Salida - PEPELOBO acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 61, \"condominio_id\": 2}','2026-04-17 13:25:37','2026-04-17 13:22:08','2026-04-17 13:22:08'),(524,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','prueba nueva','{\"category\": \"general\", \"announcement_id\": 130}',NULL,'2026-04-17 13:39:51','2026-04-17 13:39:51'),(525,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','prueba nueva','{\"category\": \"general\", \"announcement_id\": 130}',NULL,'2026-04-17 13:39:51','2026-04-17 13:39:51'),(526,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','prueba nueva','{\"category\": \"general\", \"announcement_id\": 130}','2026-04-20 23:08:53','2026-04-17 13:39:51','2026-04-17 13:39:51'),(527,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','prueba nueva','{\"category\": \"general\", \"announcement_id\": 130}','2026-04-17 13:42:44','2026-04-17 13:39:51','2026-04-17 13:39:51'),(528,2,4,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: hola','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-17 15:40:22','2026-04-17 15:36:44','2026-04-17 15:36:44'),(529,2,18,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: hola','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-17 15:36:44','2026-04-17 15:36:44'),(530,2,11,'parcel_delivered','Paquete entregado','? Paquete entregado – CONDOMINIO ZUBIRI\nSobre recogido por: Benjamin Lopencio','{\"tipo\": \"paquete_salida\", \"unit_id\": 296, \"parcel_id\": 27, \"condominio_id\": 2}','2026-04-17 15:42:17','2026-04-17 15:41:28','2026-04-17 15:41:28'),(531,2,11,'access_entry','Tu visita ha llegado','Entrada - NIKA acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 0, \"condominio_id\": 2}','2026-04-17 15:52:44','2026-04-17 15:48:26','2026-04-17 15:48:26'),(532,2,11,'parcel_arrival','Tu paquete ha llegado','Paquete recibido en Caseta 3 vía FedEx - Tienes 1 Paquete recibido(s)','{\"tipo\": \"paquete_entrada\", \"unit_id\": 296, \"parcel_id\": 28, \"condominio_id\": 2}','2026-04-17 15:53:23','2026-04-17 15:51:53','2026-04-17 15:51:53'),(533,2,11,'access_entry','Tu visita ha llegado','Entrada - MARIA DE LOD ANGELES acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 62, \"condominio_id\": 2}','2026-04-17 15:56:17','2026-04-17 15:55:49','2026-04-17 15:55:49'),(534,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','NUEVO ANUNCIO PDFPDF ','{\"category\": \"general\", \"announcement_id\": 131}',NULL,'2026-04-17 18:39:12','2026-04-17 18:39:12'),(535,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','NUEVO ANUNCIO PDFPDF ','{\"category\": \"general\", \"announcement_id\": 131}',NULL,'2026-04-17 18:39:12','2026-04-17 18:39:12'),(536,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','NUEVO ANUNCIO PDFPDF ','{\"category\": \"general\", \"announcement_id\": 131}','2026-04-20 23:08:53','2026-04-17 18:39:12','2026-04-17 18:39:12'),(537,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','NUEVO ANUNCIO PDFPDF ','{\"category\": \"general\", \"announcement_id\": 131}','2026-04-17 18:40:21','2026-04-17 18:39:12','2026-04-17 18:39:12'),(538,2,4,'calendar_event_new','Nuevo evento en calendario','? El residente Benjamin Lopencio (Unidad A-100) ha creado un evento: \'ku ho no ckto\' — Fecha: 2026-04-18 00:00:00','{\"type\": \"calendar\"}','2026-04-17 22:23:34','2026-04-17 19:55:18','2026-04-17 19:55:18'),(539,2,18,'calendar_event_new','Nuevo evento en calendario','? El residente Benjamin Lopencio (Unidad A-100) ha creado un evento: \'ku ho no ckto\' — Fecha: 2026-04-18 00:00:00','{\"type\": \"calendar\"}',NULL,'2026-04-17 19:55:18','2026-04-17 19:55:18'),(540,2,7,'calendar_event','? Nuevo Evento · CONDOMINIO ZUBIRI','Hola evento — 01/04/2026','{\"type\": \"calendar\", \"event_id\": 7}',NULL,'2026-04-17 20:06:59','2026-04-17 20:06:59'),(541,2,9,'calendar_event','? Nuevo Evento · CONDOMINIO ZUBIRI','Hola evento — 01/04/2026','{\"type\": \"calendar\", \"event_id\": 7}',NULL,'2026-04-17 20:06:59','2026-04-17 20:06:59'),(542,2,10,'calendar_event','? Nuevo Evento · CONDOMINIO ZUBIRI','Hola evento — 01/04/2026','{\"type\": \"calendar\", \"event_id\": 7}','2026-04-20 23:08:53','2026-04-17 20:06:59','2026-04-17 20:06:59'),(543,2,11,'calendar_event','? Nuevo Evento · CONDOMINIO ZUBIRI','Hola evento — 01/04/2026','{\"type\": \"calendar\", \"event_id\": 7}','2026-04-17 20:07:10','2026-04-17 20:06:59','2026-04-17 20:06:59'),(544,2,4,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: ohv','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-17 22:23:34','2026-04-17 20:27:06','2026-04-17 20:27:06'),(545,2,18,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: ohv','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-17 20:27:06','2026-04-17 20:27:06'),(546,2,11,'ticket','? Daniel Zubiri respondió tu reporte','Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"9\"}','2026-04-17 20:28:15','2026-04-17 20:27:27','2026-04-17 20:27:27'),(547,2,4,'poll_activity','Cambio de voto','? El residente Benjamin Lopencio cambió su voto en la encuesta \'otra encuesta de prueba\'','{\"type\": \"poll\"}','2026-04-17 22:23:34','2026-04-17 20:30:11','2026-04-17 20:30:11'),(548,2,18,'poll_activity','Cambio de voto','? El residente Benjamin Lopencio cambió su voto en la encuesta \'otra encuesta de prueba\'','{\"type\": \"poll\"}',NULL,'2026-04-17 20:30:11','2026-04-17 20:30:11'),(549,2,11,'access_exit','Tu visita ha salido','Salida - NIKA acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 103, \"condominio_id\": 2}','2026-04-17 21:29:45','2026-04-17 21:28:51','2026-04-17 21:28:51'),(550,2,11,'parcel_delivered','Paquete entregado al residente','? Paquete entregado al residente Paquete recogido por: Benjamin Lopencio','{\"tipo\": \"paquete_salida\", \"unit_id\": 296, \"parcel_id\": 28, \"condominio_id\": 2}','2026-04-17 21:29:42','2026-04-17 21:29:14','2026-04-17 21:29:14'),(551,2,11,'access_exit','Tu visita ha salido','Salida - MARIA DE LOD ANGELES acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 62, \"condominio_id\": 2}','2026-04-17 22:14:01','2026-04-17 22:13:47','2026-04-17 22:13:47'),(552,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado','{\"category\": \"general\", \"announcement_id\": 132}',NULL,'2026-04-17 22:26:45','2026-04-17 22:26:45'),(553,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado','{\"category\": \"general\", \"announcement_id\": 132}',NULL,'2026-04-17 22:26:45','2026-04-17 22:26:45'),(554,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado','{\"category\": \"general\", \"announcement_id\": 132}','2026-04-20 23:08:53','2026-04-17 22:26:45','2026-04-17 22:26:45'),(555,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','Comunicado','{\"category\": \"general\", \"announcement_id\": 132}','2026-04-17 22:27:41','2026-04-17 22:26:45','2026-04-17 22:26:45'),(556,2,4,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-20 18:57:50','2026-04-18 12:57:36','2026-04-18 12:57:36'),(557,2,18,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-18 12:57:36','2026-04-18 12:57:36'),(558,2,11,'access_entry','Tu visita ha llegado','Entrada - saul acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 64, \"condominio_id\": 2}','2026-04-18 15:11:51','2026-04-18 13:14:48','2026-04-18 13:14:48'),(559,2,7,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Junta Administrativa','{\"type\": \"poll\"}',NULL,'2026-04-18 16:51:47','2026-04-18 16:51:47'),(560,2,9,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Junta Administrativa','{\"type\": \"poll\"}',NULL,'2026-04-18 16:51:47','2026-04-18 16:51:47'),(561,2,10,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Junta Administrativa','{\"type\": \"poll\"}','2026-04-20 23:08:53','2026-04-18 16:51:47','2026-04-18 16:51:47'),(562,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Junta Administrativa','{\"type\": \"poll\"}','2026-04-18 16:52:06','2026-04-18 16:51:47','2026-04-18 16:51:47'),(563,2,7,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','sALUDOS ','{\"category\": \"general\", \"announcement_id\": 133}',NULL,'2026-04-18 16:53:51','2026-04-18 16:53:51'),(564,2,9,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','sALUDOS ','{\"category\": \"general\", \"announcement_id\": 133}',NULL,'2026-04-18 16:53:51','2026-04-18 16:53:51'),(565,2,10,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','sALUDOS ','{\"category\": \"general\", \"announcement_id\": 133}','2026-04-20 23:08:53','2026-04-18 16:53:51','2026-04-18 16:53:51'),(566,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRI','sALUDOS ','{\"category\": \"general\", \"announcement_id\": 133}','2026-04-18 16:54:10','2026-04-18 16:53:51','2026-04-18 16:53:51'),(567,2,7,'poll_new','Nueva encuesta','? Nueva encuesta disponible: cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD','{\"type\": \"poll\"}',NULL,'2026-04-18 16:55:02','2026-04-18 16:55:02'),(568,2,9,'poll_new','Nueva encuesta','? Nueva encuesta disponible: cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD','{\"type\": \"poll\"}',NULL,'2026-04-18 16:55:02','2026-04-18 16:55:02'),(569,2,10,'poll_new','Nueva encuesta','? Nueva encuesta disponible: cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD','{\"type\": \"poll\"}','2026-04-20 23:08:53','2026-04-18 16:55:02','2026-04-18 16:55:02'),(570,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD','{\"type\": \"poll\"}','2026-04-18 16:55:15','2026-04-18 16:55:02','2026-04-18 16:55:02'),(571,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopencio de la unidad A-100 votó en la encuesta \'Junta Administrativa\'','{\"type\": \"poll\"}','2026-04-20 18:57:50','2026-04-18 16:55:26','2026-04-18 16:55:26'),(572,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopencio de la unidad A-100 votó en la encuesta \'Junta Administrativa\'','{\"type\": \"poll\"}',NULL,'2026-04-18 16:55:26','2026-04-18 16:55:26'),(573,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopencio de la unidad A-100 votó en la encuesta \'cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDIN\'','{\"type\": \"poll\"}','2026-04-20 18:57:50','2026-04-18 17:02:06','2026-04-18 17:02:06'),(574,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopencio de la unidad A-100 votó en la encuesta \'cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDIN\'','{\"type\": \"poll\"}',NULL,'2026-04-18 17:02:06','2026-04-18 17:02:06'),(575,2,4,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-20 18:57:50','2026-04-18 20:30:40','2026-04-18 20:30:40'),(576,2,18,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-18 20:30:40','2026-04-18 20:30:40'),(577,2,4,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,'2026-04-20 18:57:50','2026-04-18 20:31:08','2026-04-18 20:31:08'),(578,2,18,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha agendado una reserva para Gimnasio.',NULL,NULL,'2026-04-18 20:31:08','2026-04-18 20:31:08'),(579,2,4,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: ? Adjunto','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-20 18:57:50','2026-04-18 20:34:11','2026-04-18 20:34:11'),(580,2,18,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: ? Adjunto','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-18 20:34:11','2026-04-18 20:34:11'),(581,2,4,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: cerrado','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-20 18:57:50','2026-04-18 20:34:40','2026-04-18 20:34:40'),(582,2,18,'ticket','? Nuevo comentario en reporte','Benjamin Lopencio: cerrado','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-18 20:34:40','2026-04-18 20:34:40'),(583,2,4,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-20 18:57:50','2026-04-18 20:41:41','2026-04-18 20:41:41'),(584,2,18,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-18 20:41:41','2026-04-18 20:41:41'),(585,2,4,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-20 18:57:50','2026-04-18 20:43:26','2026-04-18 20:43:26'),(586,2,18,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-18 20:43:26','2026-04-18 20:43:26'),(587,2,11,'amenidad','Reserva Rechazada','Tu solicitud de reserva para Jacuzzi el 23/04/2026 a las 15:00 no pudo ser aprobada.',NULL,'2026-04-18 22:03:07','2026-04-18 21:47:03','2026-04-18 21:47:03'),(588,2,11,'amenidad','Reserva Rechazada','Tu solicitud de reserva para Jacuzzi el 23/04/2026 a las 15:00 no pudo ser aprobada.',NULL,'2026-04-18 22:03:09','2026-04-18 21:47:19','2026-04-18 21:47:19'),(589,2,11,'payment_rejected','Pago rechazado','Tu comprobante de pago ha sido rechazado. Motivo: no','{\"tipo\": \"pago_rechazado\", \"payment_id\": 33}','2026-04-19 00:36:15','2026-04-18 22:04:19','2026-04-18 22:04:19'),(590,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $2,500.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 2500, \"payment_id\": 32}','2026-04-19 00:36:12','2026-04-18 22:04:33','2026-04-18 22:04:33'),(591,2,4,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-20 18:57:50','2026-04-18 23:17:59','2026-04-18 23:17:59'),(592,2,18,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-18 23:17:59','2026-04-18 23:17:59'),(593,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $22,000.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 22000, \"payment_id\": 34}','2026-04-19 00:08:34','2026-04-18 23:29:47','2026-04-18 23:29:47'),(594,2,11,'new_charge','Nueva cuota generada','Se ha registrado un nuevo cargo en tu estado de cuenta.','{\"tipo\": \"nueva_cuota\", \"unit_id\": \"296\"}','2026-04-19 13:15:52','2026-04-19 13:13:31','2026-04-19 13:13:31'),(595,2,11,'payment_approved','Pago registrado','Se ha registrado un pago en tu estado de cuenta.','{\"tipo\": \"pago_registrado\", \"unit_id\": \"296\"}','2026-04-19 13:23:12','2026-04-19 13:22:14','2026-04-19 13:22:14'),(596,2,4,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-20 23:06:01','2026-04-20 20:10:52','2026-04-20 20:10:52'),(597,2,18,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopencio de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-20 20:10:52','2026-04-20 20:10:52'),(598,2,4,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-20 23:06:01','2026-04-20 20:19:30','2026-04-20 20:19:30'),(599,2,18,'payment_status','Comprobante Subido','Benjamin Lopencio subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-20 20:19:30','2026-04-20 20:19:30'),(600,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $50.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 50, \"payment_id\": 35}','2026-04-20 20:20:28','2026-04-20 20:20:21','2026-04-20 20:20:21'),(601,2,7,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Opcines','{\"type\": \"poll\"}',NULL,'2026-04-20 20:25:50','2026-04-20 20:25:50'),(602,2,9,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Opcines','{\"type\": \"poll\"}',NULL,'2026-04-20 20:25:50','2026-04-20 20:25:50'),(603,2,10,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Opcines','{\"type\": \"poll\"}','2026-04-20 23:08:53','2026-04-20 20:25:50','2026-04-20 20:25:50'),(604,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: Opcines','{\"type\": \"poll\"}','2026-04-20 20:27:43','2026-04-20 20:25:50','2026-04-20 20:25:50'),(605,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva para Jacuzzi el 22/04/2026 a las 09:00 ha sido aprobada.',NULL,'2026-04-20 20:27:39','2026-04-20 20:27:30','2026-04-20 20:27:30'),(606,2,11,'access_exit','Tu visita ha salido','Salida - saul acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 64, \"condominio_id\": 2}','2026-04-20 20:50:16','2026-04-20 20:48:07','2026-04-20 20:48:07'),(607,2,4,'ticket','? Nuevo comentario en reporte','Benjamin Lopez: que hay','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-20 23:06:01','2026-04-20 20:51:08','2026-04-20 20:51:08'),(608,2,18,'ticket','? Nuevo comentario en reporte','Benjamin Lopez: que hay','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-20 20:51:08','2026-04-20 20:51:08'),(609,2,11,'ticket','? Daniel Zubiri respondió tu reporte','Estimado residente, estamos investigando su problema y le mantendremos informado.','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"9\"}','2026-04-20 20:51:45','2026-04-20 20:51:27','2026-04-20 20:51:27'),(610,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopez de la unidad A-100 votó en la encuesta \'Opcines\'','{\"type\": \"poll\"}','2026-04-20 23:06:01','2026-04-20 20:54:43','2026-04-20 20:54:43'),(611,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopez de la unidad A-100 votó en la encuesta \'Opcines\'','{\"type\": \"poll\"}',NULL,'2026-04-20 20:54:43','2026-04-20 20:54:43'),(612,2,4,'calendar_event_new','Nuevo evento en calendario','? El residente Benjamin Lopez (Unidad A-100) ha creado un evento: \'pagos\' — Fecha: 2026-04-21 00:00:00','{\"type\": \"calendar\"}','2026-04-20 23:06:01','2026-04-20 22:01:15','2026-04-20 22:01:15'),(613,2,18,'calendar_event_new','Nuevo evento en calendario','? El residente Benjamin Lopez (Unidad A-100) ha creado un evento: \'pagos\' — Fecha: 2026-04-21 00:00:00','{\"type\": \"calendar\"}',NULL,'2026-04-20 22:01:15','2026-04-20 22:01:15'),(614,5,21,'announcement','? Nuevo Aviso · LA ESTADIA','POrueba','{\"category\": \"general\", \"announcement_id\": 135}','2026-04-20 22:19:46','2026-04-20 22:19:39','2026-04-20 22:19:39'),(615,5,4,'payment_status','Comprobante Subido','Antonio Cuellas subió un comprobante de pago para A101','{\"action_url\": \"admin/finanzas/pagos-por-unidad/8c898245893b39e118f83bb0\"}','2026-04-20 22:43:57','2026-04-20 22:21:03','2026-04-20 22:21:03'),(616,5,21,'payment_approved','Pago aprobado','Tu comprobante de pago por $4,000.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 4000, \"payment_id\": 36}','2026-04-20 22:21:54','2026-04-20 22:21:25','2026-04-20 22:21:25'),(617,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Antonio Cuellar de la unidad A-101 votó en la encuesta \'Opcines\'','{\"type\": \"poll\"}','2026-04-20 23:06:01','2026-04-20 22:32:50','2026-04-20 22:32:50'),(618,2,18,'poll_activity','Nuevo voto en encuesta','?️ El residente Antonio Cuellar de la unidad A-101 votó en la encuesta \'Opcines\'','{\"type\": \"poll\"}',NULL,'2026-04-20 22:32:50','2026-04-20 22:32:50'),(619,5,4,'poll_activity','Cambio de voto','? El residente Antonio Cuellar cambió su voto en la encuesta \'Opcines\'','{\"type\": \"poll\"}','2026-04-20 22:43:57','2026-04-20 22:33:50','2026-04-20 22:33:50'),(620,5,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Antonio Cuellar de la unidad A101 votó en la encuesta \'Aopciones\'','{\"type\": \"poll\"}','2026-04-20 22:43:57','2026-04-20 22:34:14','2026-04-20 22:34:14'),(621,5,4,'poll_activity','Cambio de voto','? El residente Antonio Cuellar cambió su voto en la encuesta \'Aopciones\'','{\"type\": \"poll\"}','2026-04-20 22:43:57','2026-04-20 22:34:31','2026-04-20 22:34:31'),(622,5,4,'poll_activity','Cambio de voto','? El residente Antonio Cuellar cambió su voto en la encuesta \'Aopciones\'','{\"type\": \"poll\"}','2026-04-20 22:43:57','2026-04-20 22:35:01','2026-04-20 22:35:01'),(623,2,11,'ticket','? Daniel Zubiri respondió tu reporte','oK','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"9\"}','2026-04-21 08:46:03','2026-04-21 08:30:29','2026-04-21 08:30:29'),(624,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: colores','{\"type\": \"poll\"}','2026-04-26 22:39:54','2026-04-26 22:22:52','2026-04-26 22:22:52'),(625,2,23,'poll_new','Nueva encuesta','? Nueva encuesta disponible: colores','{\"type\": \"poll\"}',NULL,'2026-04-26 22:22:52','2026-04-26 22:22:52'),(626,2,11,'calendar_event','? Nuevo Evento · CONDOMINIO ZUBIRY','envto de prueba — 26/04/2026','{\"type\": \"calendar\", \"event_id\": 9}','2026-04-26 22:39:54','2026-04-26 22:26:41','2026-04-26 22:26:41'),(627,2,23,'calendar_event','? Nuevo Evento · CONDOMINIO ZUBIRY','envto de prueba — 26/04/2026','{\"type\": \"calendar\", \"event_id\": 9}',NULL,'2026-04-26 22:26:41','2026-04-26 22:26:41'),(628,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Daniel Zubiri de la unidad Sin unidad votó en la encuesta \'colores\'','{\"type\": \"poll\"}','2026-04-26 22:29:52','2026-04-26 22:28:34','2026-04-26 22:28:34'),(629,2,25,'poll_activity','Nuevo voto en encuesta','?️ El residente Daniel Zubiri de la unidad Sin unidad votó en la encuesta \'colores\'','{\"type\": \"poll\"}',NULL,'2026-04-26 22:28:34','2026-04-26 22:28:34'),(630,2,4,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopez de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-26 22:49:19','2026-04-26 22:31:45','2026-04-26 22:31:45'),(631,2,25,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopez de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-26 22:31:45','2026-04-26 22:31:45'),(632,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopez de la unidad A-100 votó en la encuesta \'colores\'','{\"type\": \"poll\"}','2026-04-26 22:49:19','2026-04-26 22:32:16','2026-04-26 22:32:16'),(633,2,25,'poll_activity','Nuevo voto en encuesta','?️ El residente Benjamin Lopez de la unidad A-100 votó en la encuesta \'colores\'','{\"type\": \"poll\"}',NULL,'2026-04-26 22:32:16','2026-04-26 22:32:16'),(634,2,4,'poll_activity','Cambio de voto','? El residente Benjamin Lopez cambió su voto en la encuesta \'Opcines\'','{\"type\": \"poll\"}','2026-04-26 22:49:19','2026-04-26 22:33:37','2026-04-26 22:33:37'),(635,2,25,'poll_activity','Cambio de voto','? El residente Benjamin Lopez cambió su voto en la encuesta \'Opcines\'','{\"type\": \"poll\"}',NULL,'2026-04-26 22:33:37','2026-04-26 22:33:37'),(636,2,4,'ticket','? Nuevo comentario en reporte','Benjamin Lopez: oj','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}','2026-04-26 22:46:42','2026-04-26 22:34:42','2026-04-26 22:34:42'),(637,2,25,'ticket','? Nuevo comentario en reporte','Benjamin Lopez: oj','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"9\"}',NULL,'2026-04-26 22:34:42','2026-04-26 22:34:42'),(638,2,11,'access_entry','Tu visita ha llegado','Entrada - paco acaba de registrar su acceso mediante un código QR autorizado.','{\"tipo\": \"entrada\", \"unit_id\": 296, \"visita_id\": 68, \"condominio_id\": 2}','2026-04-26 22:39:54','2026-04-26 22:36:33','2026-04-26 22:36:33'),(639,2,11,'access_exit','Tu visita ha salido','Salida - paco acaba de registrar su salida mediante un código QR autorizado.','{\"tipo\": \"salida\", \"unit_id\": 296, \"visita_id\": 68, \"condominio_id\": 2}','2026-04-26 22:39:54','2026-04-26 22:36:51','2026-04-26 22:36:51'),(640,2,4,'payment_status','Comprobante Subido','Benjamin Lopez subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-26 22:46:37','2026-04-26 22:39:23','2026-04-26 22:39:23'),(641,2,25,'payment_status','Comprobante Subido','Benjamin Lopez subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-26 22:39:23','2026-04-26 22:39:23'),(642,2,11,'payment_approved','Pago aprobado','Tu comprobante de pago por $100.00 ha sido aprobado por la administración.','{\"tipo\": \"pago_aprobado\", \"amount\": 100, \"payment_id\": 37}','2026-04-26 22:39:54','2026-04-26 22:39:39','2026-04-26 22:39:39'),(643,2,11,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRY','Anuncio','{\"category\": \"maintenance\", \"announcement_id\": 137}','2026-04-26 22:40:32','2026-04-26 22:40:12','2026-04-26 22:40:12'),(644,2,23,'announcement','? Nuevo Aviso · CONDOMINIO ZUBIRY','Anuncio','{\"category\": \"maintenance\", \"announcement_id\": 137}',NULL,'2026-04-26 22:40:12','2026-04-26 22:40:12'),(645,2,11,'ticket','✅ Reporte Resuelto','La administración ha marcado tu reporte como resuelto.','{\"type\": \"ticket_resolved\", \"ticket_id\": \"9\"}','2026-04-27 11:03:14','2026-04-26 22:46:54','2026-04-26 22:46:54'),(646,2,11,'amenidad','Reserva Aprobada','Tu solicitud de reserva ha sido aprobada.','{\"type\": \"amenity\", \"booking_id\": \"26\"}','2026-04-27 11:03:14','2026-04-26 22:47:19','2026-04-26 22:47:19'),(647,2,4,'poll_activity','Nuevo voto en encuesta','?️ El residente Daniel Zubiri de la unidad Sin unidad votó en la encuesta \'Opcines\'','{\"type\": \"poll\"}','2026-04-27 06:52:57','2026-04-26 22:52:26','2026-04-26 22:52:26'),(648,2,25,'poll_activity','Nuevo voto en encuesta','?️ El residente Daniel Zubiri de la unidad Sin unidad votó en la encuesta \'Opcines\'','{\"type\": \"poll\"}',NULL,'2026-04-26 22:52:27','2026-04-26 22:52:27'),(649,2,11,'poll_new','Nueva encuesta','? Nueva encuesta disponible: perros','{\"type\": \"poll\"}','2026-04-27 06:20:33','2026-04-26 23:02:30','2026-04-26 23:02:30'),(650,2,23,'poll_new','Nueva encuesta','? Nueva encuesta disponible: perros','{\"type\": \"poll\"}',NULL,'2026-04-26 23:02:30','2026-04-26 23:02:30'),(651,2,11,'announcement','📢 Nuevo Aviso · CONDOMINIO ZUBIRI','hOLA','{\"category\": \"general\", \"announcement_id\": 138}','2026-04-27 06:21:15','2026-04-27 06:21:06','2026-04-27 06:21:06'),(652,2,23,'announcement','📢 Nuevo Aviso · CONDOMINIO ZUBIRI','hOLA','{\"category\": \"general\", \"announcement_id\": 138}',NULL,'2026-04-27 06:21:06','2026-04-27 06:21:06'),(653,2,4,'poll_activity','Nuevo voto en encuesta','🗳️ El residente Benjamin Lopez de la unidad A-100 votó en la encuesta \'perros\'','{\"type\": \"poll\"}','2026-04-27 06:52:57','2026-04-27 06:21:33','2026-04-27 06:21:33'),(654,2,25,'poll_activity','Nuevo voto en encuesta','🗳️ El residente Benjamin Lopez de la unidad A-100 votó en la encuesta \'perros\'','{\"type\": \"poll\"}',NULL,'2026-04-27 06:21:33','2026-04-27 06:21:33'),(655,2,4,'payment_status','Comprobante Subido','Benjamin Lopez subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}','2026-04-27 12:12:28','2026-04-27 11:03:32','2026-04-27 11:03:32'),(656,2,25,'payment_status','Comprobante Subido','Benjamin Lopez subió un comprobante de pago para A-100','{\"action_url\": \"admin/finanzas/pagos-por-unidad/cdcf26c159547991ef12696f\"}',NULL,'2026-04-27 11:03:32','2026-04-27 11:03:32'),(657,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','Hola','{\"category\": \"maintenance\", \"announcement_id\": 139}','2026-04-27 12:01:48','2026-04-27 11:37:14','2026-04-27 11:37:14'),(658,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','Hola','{\"category\": \"maintenance\", \"announcement_id\": 139}',NULL,'2026-04-27 11:37:14','2026-04-27 11:37:14'),(659,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','NUEVO ANUNCIO ','{\"category\": \"general\", \"announcement_id\": 140}','2026-04-27 12:23:47','2026-04-27 12:21:49','2026-04-27 12:21:49'),(660,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','NUEVO ANUNCIO ','{\"category\": \"general\", \"announcement_id\": 140}',NULL,'2026-04-27 12:21:49','2026-04-27 12:21:49'),(661,2,4,'poll_activity','Cambio de voto','🔄 El residente Benjamin Lopez cambió su voto en la encuesta \'perros\'','{\"type\": \"poll\"}','2026-04-27 12:52:12','2026-04-27 12:48:47','2026-04-27 12:48:47'),(662,2,25,'poll_activity','Cambio de voto','🔄 El residente Benjamin Lopez cambió su voto en la encuesta \'perros\'','{\"type\": \"poll\"}',NULL,'2026-04-27 12:48:47','2026-04-27 12:48:47'),(663,2,11,'payment_rejected','Pago rechazado','Tu comprobante de pago ha sido rechazado. Motivo: noseve','{\"tipo\": \"pago_rechazado\", \"payment_id\": 38}','2026-04-27 13:28:10','2026-04-27 12:58:52','2026-04-27 12:58:52'),(664,2,4,'poll_activity','Nuevo voto en encuesta','🗳️ El residente Daniel Zubiri de la unidad Sin unidad votó en la encuesta \'perros\'','{\"type\": \"poll\"}','2026-04-27 13:16:52','2026-04-27 13:15:41','2026-04-27 13:15:41'),(665,2,25,'poll_activity','Nuevo voto en encuesta','🗳️ El residente Daniel Zubiri de la unidad Sin unidad votó en la encuesta \'perros\'','{\"type\": \"poll\"}',NULL,'2026-04-27 13:15:41','2026-04-27 13:15:41'),(666,2,4,'poll_activity','Cambio de voto','🔄 El residente Benjamin Lopez cambió su voto en la encuesta \'perros\'','{\"type\": \"poll\"}','2026-04-27 14:35:34','2026-04-27 13:28:39','2026-04-27 13:28:39'),(667,2,25,'poll_activity','Cambio de voto','🔄 El residente Benjamin Lopez cambió su voto en la encuesta \'perros\'','{\"type\": \"poll\"}',NULL,'2026-04-27 13:28:39','2026-04-27 13:28:39'),(668,2,4,'ticket','🔧 Nuevo Reporte','Benjamin Lopez reportó: nuevo el ptet','{\"type\": \"ticket_created\", \"ticket_id\": 10}','2026-04-27 14:33:19','2026-04-27 13:29:51','2026-04-27 13:29:51'),(669,2,25,'ticket','🔧 Nuevo Reporte','Benjamin Lopez reportó: nuevo el ptet','{\"type\": \"ticket_created\", \"ticket_id\": 10}',NULL,'2026-04-27 13:29:51','2026-04-27 13:29:51'),(670,2,4,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopez de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,'2026-04-27 14:34:57','2026-04-27 13:34:32','2026-04-27 13:34:32'),(671,2,25,'amenidad','Nueva Reserva de Amenidad','Benjamin Lopez de la unidad A-100 ha solicitado una reserva para Jacuzzi.',NULL,NULL,'2026-04-27 13:34:32','2026-04-27 13:34:32'),(672,2,4,'calendar_event_new','Nuevo evento en calendario','📅 El residente Benjamin Lopez (Unidad A-100) ha creado un evento: \'nuevo\' — Fecha: 2026-04-27 00:00:00','{\"type\": \"calendar\"}','2026-04-27 15:21:20','2026-04-27 13:53:46','2026-04-27 13:53:46'),(673,2,25,'calendar_event_new','Nuevo evento en calendario','📅 El residente Benjamin Lopez (Unidad A-100) ha creado un evento: \'nuevo\' — Fecha: 2026-04-27 00:00:00','{\"type\": \"calendar\"}',NULL,'2026-04-27 13:53:46','2026-04-27 13:53:46'),(674,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: hola','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 17:55:25','2026-04-27 14:33:40','2026-04-27 14:33:40'),(675,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: giica','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 17:55:25','2026-04-27 14:53:45','2026-04-27 14:53:45'),(676,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: hoivsb','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 17:55:25','2026-04-27 15:03:11','2026-04-27 15:03:11'),(677,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: hola s\nestamos verificando \ndamos a mañana','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 17:55:25','2026-04-27 15:11:27','2026-04-27 15:11:27'),(678,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: geaid sm\nvamos a escalar después','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 16:37:38','2026-04-27 15:21:12','2026-04-27 15:21:12'),(679,2,4,'ticket','💬 Nuevo comentario en reporte','Benjamin Lopez: ojvd','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"10\"}','2026-04-27 22:17:25','2026-04-27 16:37:47','2026-04-27 16:37:47'),(680,2,25,'ticket','💬 Nuevo comentario en reporte','Benjamin Lopez: ojvd','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"10\"}',NULL,'2026-04-27 16:37:47','2026-04-27 16:37:47'),(681,2,4,'ticket','💬 Nuevo comentario en reporte','Benjamin Lopez: ok \nkjs','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"10\"}','2026-04-27 22:16:28','2026-04-27 17:55:16','2026-04-27 17:55:16'),(682,2,25,'ticket','💬 Nuevo comentario en reporte','Benjamin Lopez: ok \nkjs','{\"type\": \"ticket_resident_comment\", \"ticket_id\": \"10\"}',NULL,'2026-04-27 17:55:16','2026-04-27 17:55:16'),(683,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','Noticacion con video','{\"category\": \"maintenance\", \"announcement_id\": 141}','2026-04-27 19:16:50','2026-04-27 19:15:54','2026-04-27 19:15:54'),(684,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','Noticacion con video','{\"category\": \"maintenance\", \"announcement_id\": 141}',NULL,'2026-04-27 19:15:54','2026-04-27 19:15:54'),(685,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','puro videopuaiousdasd','{\"category\": \"maintenance\", \"announcement_id\": 142}','2026-04-27 19:43:05','2026-04-27 19:35:56','2026-04-27 19:35:56'),(686,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','puro videopuaiousdasd','{\"category\": \"maintenance\", \"announcement_id\": 142}',NULL,'2026-04-27 19:35:56','2026-04-27 19:35:56'),(687,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','4 imagenes','{\"category\": \"event\", \"announcement_id\": 143}','2026-04-27 19:41:24','2026-04-27 19:40:49','2026-04-27 19:40:49'),(688,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','4 imagenes','{\"category\": \"event\", \"announcement_id\": 143}',NULL,'2026-04-27 19:40:49','2026-04-27 19:40:49'),(689,2,11,'announcement','📢 Nuevo Aviso - ZUBIRI CONDO','nuevo comunicado \npara todos','{\"category\": \"general\", \"announcement_id\": 144}','2026-04-27 22:49:27','2026-04-27 22:16:10','2026-04-27 22:16:10'),(690,2,23,'announcement','📢 Nuevo Aviso - ZUBIRI CONDO','nuevo comunicado \npara todos','{\"category\": \"general\", \"announcement_id\": 144}',NULL,'2026-04-27 22:16:10','2026-04-27 22:16:10'),(691,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: 📷 Adjunto','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 22:49:36','2026-04-27 22:17:11','2026-04-27 22:17:11'),(692,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: ok \ndamos continuidad','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 22:49:36','2026-04-27 22:17:13','2026-04-27 22:17:13'),(693,2,11,'ticket','💬 Nuevo comentario en tu reporte','La administración comentó: ohv','{\"type\": \"ticket_admin_comment\", \"ticket_id\": \"10\"}','2026-04-27 22:49:36','2026-04-27 22:42:45','2026-04-27 22:42:45'),(694,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','Nuevaapp','{\"category\": \"general\", \"announcement_id\": 145}','2026-04-28 17:41:36','2026-04-28 09:54:24','2026-04-28 09:54:24'),(695,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','Nuevaapp','{\"category\": \"general\", \"announcement_id\": 145}',NULL,'2026-04-28 09:54:24','2026-04-28 09:54:24'),(696,2,11,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','test','{\"category\": \"general\", \"announcement_id\": 146}','2026-04-28 17:41:30','2026-04-28 13:54:12','2026-04-28 13:54:12'),(697,2,23,'announcement','📢 Nuevo Aviso · ZUBIRI CONDO','test','{\"category\": \"general\", \"announcement_id\": 146}',NULL,'2026-04-28 13:54:12','2026-04-28 13:54:12');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parcels`
--

DROP TABLE IF EXISTS `parcels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parcels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `received_by` bigint unsigned NOT NULL,
  `courier` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `quantity` int unsigned DEFAULT '1',
  `parcel_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Paquete',
  `tracking_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('at_gate','delivered_to_resident','returned','pending') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'at_gate',
  `delivered_at` datetime DEFAULT NULL,
  `picked_up_by` bigint unsigned DEFAULT NULL COMMENT 'User ID of resident who picked up',
  `picked_up_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `signature_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parcels_unit_id_foreign` (`unit_id`),
  KEY `parcels_received_by_foreign` (`received_by`),
  KEY `condominium_id_status_created_at` (`condominium_id`,`status`,`created_at`),
  CONSTRAINT `parcels_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `parcels_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `parcels_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parcels`
--

LOCK TABLES `parcels` WRITE;
/*!40000 ALTER TABLE `parcels` DISABLE KEYS */;
INSERT INTO `parcels` VALUES (1,2,297,6,'Mercado Libre','writable/uploads/parcels/parcel_1775074896_1775074896_36fb732c59a07e9ff124.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-01 14:36:59',10,'Angeles Lopez','writable/uploads/parcels/sig_1775075819_69cd81ebac303.png','2026-04-01 14:21:36','2026-04-01 14:36:59'),(2,2,296,6,'Amazon','writable/uploads/parcels/parcel_1775076127_1775076127_09993d6b3c8ec60492c2.jpg',2,'Paquete',NULL,'delivered_to_resident','2026-04-01 15:43:55',11,'benjamin lopez','writable/uploads/parcels/sig_1775079835_69cd919b6c26d.png','2026-04-01 14:42:07','2026-04-01 15:43:55'),(3,2,296,6,'UPS','writable/uploads/parcels/parcel_1775079966_1775079966_3f11370e12f343d42a42.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-01 16:19:17',NULL,'Entrega desde administración',NULL,'2026-04-01 15:46:06','2026-04-01 16:19:17'),(4,2,297,6,'Estafeta','writable/uploads/parcels/parcel_1775081999_1775081999_74bab2e77722b37642e4.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-01 16:31:46',10,'Angeles Lopez','writable/uploads/parcels/sig_1775082706_69cd9cd2a3c23.png','2026-04-01 16:19:59','2026-04-01 16:31:46'),(5,2,296,6,'Otro','writable/uploads/parcels/parcel_1775082744_1775082744_0b6cd3224b1736f66fac.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-01 20:31:43',11,'benjamin lopez','writable/uploads/parcels/sig_1775097103_69cdd50f75e02.png','2026-04-01 16:32:24','2026-04-01 20:31:43'),(6,2,419,6,'FedEx','writable/uploads/parcels/parcel_1775113276_1775113276_bef9104313fbaa2fc115.jpg',2,'Paquete',NULL,'delivered_to_resident','2026-04-02 01:07:08',NULL,'JUAN GOMEZ','writable/uploads/parcels/sig_1775113628_69ce159c98692.png','2026-04-02 01:01:16','2026-04-02 01:07:08'),(7,2,297,6,'DHL','writable/uploads/parcels/parcel_1775113599_1775113599_fde0b185b49dc1b587ea.jpg',3,'Paquete',NULL,'delivered_to_resident','2026-04-06 12:36:35',10,'Angeles Lopez','writable/uploads/parcels/sig_1775500595_69d3fd33a90c7.png','2026-04-02 01:06:39','2026-04-06 12:36:35'),(8,2,420,14,'DHL','writable/uploads/parcels/parcel_1775669168_1775669168_9dca8ce5ae4d6ddd034c.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-08 15:43:29',NULL,'ARACELI MONTOYA','writable/uploads/parcels/sig_1775684609_69d6cc01bcc41.png','2026-04-08 11:26:08','2026-04-08 15:43:29'),(9,2,420,14,'Amazon','writable/uploads/parcels/parcel_1775757248_1775757248_db0a6dc6ceca483d135c.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-09 11:59:34',7,'Daniel','writable/uploads/parcels/sig_1775757574_69d7e906b220c.png','2026-04-09 11:54:08','2026-04-09 11:59:34'),(10,2,424,14,'UPS','writable/uploads/parcels/parcel_1775762142_1775762142_2a32b98f7c5b71eb7fcd.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-09 18:50:37',NULL,'ethan','writable/uploads/parcels/sig_1775782237_69d8495da6b14.png','2026-04-09 13:15:42','2026-04-09 18:50:37'),(11,2,297,14,'FedEx','writable/uploads/parcels/parcel_1775766262_1775766262_bbd98198c04fbec60ca2.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-09 14:24:37',NULL,'pepe','writable/uploads/parcels/sig_1775766277_69d80b0586ab3.png','2026-04-09 14:24:22','2026-04-09 14:24:37'),(12,2,420,14,'Mercado Libre','writable/uploads/parcels/parcel_1775788010_1775788010_cdf745f426923536176f.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-10 08:36:29',7,'Daniel','writable/uploads/parcels/sig_1775831789_69d90aed99a7e.png','2026-04-09 20:26:50','2026-04-10 08:36:29'),(13,2,296,14,'Estafeta','writable/uploads/parcels/parcel_1775789467_1775789467_3793f0df8ebfa2982354.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-10 09:42:48',11,'benjamin lopez','writable/uploads/parcels/sig_1775835768_69d91a782b555.png','2026-04-09 20:51:07','2026-04-10 09:42:48'),(14,2,421,14,'Mercado Libre','writable/uploads/parcels/parcel_1775796679_1775796679_024a18bc74a4868aaf01.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-10 08:34:40',NULL,'hvdeb','writable/uploads/parcels/sig_1775831680_69d90a804c45b.png','2026-04-09 22:51:19','2026-04-10 08:34:40'),(15,2,420,14,'DHL','writable/uploads/parcels/parcel_1775831927_1775831927_239dfb28a084ffeba6d7.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-10 09:43:04',NULL,'Daniel auto','writable/uploads/parcels/sig_1775835784_69d91a889fea5.png','2026-04-10 08:38:47','2026-04-10 09:43:04'),(16,2,296,14,'Mercado Libre','writable/uploads/parcels/parcel_1775852520_1775852520_c606805ef06da2104153.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-10 15:56:29',11,'benjamin lopez','writable/uploads/parcels/sig_1775858189_69d9720d4f430.png','2026-04-10 14:22:00','2026-04-10 15:56:29'),(17,2,428,14,'Mercado Libre','writable/uploads/parcels/parcel_1775855422_1775855422_2eed56013da339c62533.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-10 18:20:46',NULL,'pauo','writable/uploads/parcels/sig_1775866846_69d993de667d0.png','2026-04-10 15:10:22','2026-04-10 18:20:46'),(18,2,296,14,'Mercado Libre','writable/uploads/parcels/parcel_1775855801_1775855801_3419a11d4fc78831483c.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-12 13:13:09',11,'benjamin lopez','writable/uploads/parcels/sig_1776021189_69dbeec5b3975.png','2026-04-10 15:16:41','2026-04-12 13:13:09'),(19,2,428,14,'Otro','writable/uploads/parcels/parcel_1775855923_1775855923_56f16efa8da6edc9b95e.jpg',2,'Paquete',NULL,'delivered_to_resident','2026-04-10 18:20:32',NULL,'Juan pap','writable/uploads/parcels/sig_1775866832_69d993d053392.png','2026-04-10 15:18:43','2026-04-10 18:20:32'),(20,2,296,14,'Mercado Libre','writable/uploads/parcels/parcel_1776058616_1776058616_bff5998773c597ef7e6d.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-12 23:41:51',11,'benjamin zub','writable/uploads/parcels/sig_1776058911_69dc821f4bdca.png','2026-04-12 23:36:56','2026-04-12 23:41:51'),(21,2,296,14,'Mercado Libre','writable/uploads/parcels/parcel_1776059807_1776059807_cc7b3fb466136e04f085.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-13 10:03:58',11,'benjamin zubiri','writable/uploads/parcels/sig_1776096238_69dd13ee0f36e.png','2026-04-12 23:56:47','2026-04-13 10:03:58'),(22,2,296,11,'Mercado Libre','writable/uploads/parcels/parcel_1776222134_1776222134_62bb72b6d0bd9673ccb2.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-16 12:07:33',10,'Angeles Lopez','writable/uploads/parcels/sig_1776362853_69e12565355ee.png','2026-04-14 21:02:14','2026-04-16 12:07:33'),(23,2,296,14,'Mercado Libre','writable/uploads/parcels/parcel_1776449314_1776449314_7ad0b0e538b008dd0505.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-17 12:10:55',11,'benjamin zubiri3','writable/uploads/parcels/sig_1776449455_69e277af8ba6b.png','2026-04-17 12:08:34','2026-04-17 12:10:55'),(24,2,296,14,'Mercado Libre','writable/uploads/parcels/parcel_1776449855_1776449855_58c7da0928c087c65af7.jpg',3,'Sobre',NULL,'delivered_to_resident','2026-04-17 12:19:56',11,'benjamin zubiri3','writable/uploads/parcels/sig_1776449996_69e279cc55200.png','2026-04-17 12:17:35','2026-04-17 12:19:56'),(25,2,296,14,'99 Minutos','writable/uploads/parcels/parcel_1776451216_1776451216_d46924080b09a6b37608.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-17 13:02:08',11,'benjamin zubiri3','writable/uploads/parcels/sig_1776452528_69e283b0cee67.png','2026-04-17 12:40:16','2026-04-17 13:02:08'),(26,2,423,14,'Amazon','writable/uploads/parcels/parcel_1776451766_1776451766_498d19a34eda7e624cdf.jpg',2,'Paquete',NULL,'delivered_to_resident','2026-04-17 13:02:20',NULL,'Angeles','writable/uploads/parcels/sig_1776452540_69e283bc50929.png','2026-04-17 12:49:26','2026-04-17 13:02:20'),(27,2,296,14,'Amazon','writable/uploads/parcels/parcel_1776452854_1776452854_976788e2d86bf8c00e60.jpg',2,'Sobre',NULL,'delivered_to_resident','2026-04-17 15:41:28',11,'Benjamin Lopencio','writable/uploads/parcels/sig_1776462088_69e2a9088d4fd.png','2026-04-17 13:07:34','2026-04-17 15:41:28'),(28,2,296,14,'FedEx','writable/uploads/parcels/parcel_1776462713_1776462713_0980be6c5fd8932cb049.jpg',1,'Paquete',NULL,'delivered_to_resident','2026-04-17 21:29:14',11,'Benjamin Lopencio','writable/uploads/parcels/sig_1776482954_69e2fa8a60ed1.png','2026-04-17 15:51:53','2026-04-17 21:29:14'),(29,8,482,27,'UPS','writable/uploads/parcels/parcel_1777321836_1777321836_f8e9e12fa006dbb04545.jpg',1,'Sobre',NULL,'delivered_to_resident','2026-04-27 14:32:29',NULL,'Pqci','writable/uploads/parcels/sig_1777321949_69efc7dda21e3.png','2026-04-27 14:30:36','2026-04-27 14:32:29');
/*!40000 ALTER TABLE `parcels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_reminder_logs`
--

DROP TABLE IF EXISTS `payment_reminder_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_reminder_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reminder_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `sent_date` date NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_reminder_logs_user_id_foreign` (`user_id`),
  KEY `reminder_id_user_id_sent_date` (`reminder_id`,`user_id`,`sent_date`),
  CONSTRAINT `payment_reminder_logs_reminder_id_foreign` FOREIGN KEY (`reminder_id`) REFERENCES `payment_reminders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payment_reminder_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_reminder_logs`
--

LOCK TABLES `payment_reminder_logs` WRITE;
/*!40000 ALTER TABLE `payment_reminder_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_reminder_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_reminders`
--

DROP TABLE IF EXISTS `payment_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_reminders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `trigger_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `trigger_value` int NOT NULL DEFAULT '0',
  `message_title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `message_body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_reminders_condominium_id_foreign` (`condominium_id`),
  CONSTRAINT `payment_reminders_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_reminders`
--

LOCK TABLES `payment_reminders` WRITE;
/*!40000 ALTER TABLE `payment_reminders` DISABLE KEYS */;
INSERT INTO `payment_reminders` VALUES (1,2,'start_of_month',1,'Recordatorio Mensual de Cuota','¡Es inicio de mes! Recuerda pagar tu cuota de mantenimiento antes de la fecha de vencimiento.',1,'2026-04-18 17:51:24','2026-04-18 17:51:24',NULL),(2,2,'days_before_due',2,'Pago Por Vencer','Recordatorio amigable: Tu cuota de mantenimiento vence en {x} días.',1,'2026-04-18 17:51:24','2026-04-18 17:51:24',NULL),(3,2,'due_date',0,'Pago Vence Hoy','Tu cuota de mantenimiento vence hoy. Por favor realiza tu pago para evitar cargos por mora.',1,'2026-04-18 17:51:24','2026-04-18 17:51:24',NULL),(4,5,'start_of_month',1,'Recordatorio Mensual de Cuota','¡Es inicio de mes! Recuerda pagar tu cuota de mantenimiento antes de la fecha de vencimiento.',1,'2026-04-20 19:26:15','2026-04-20 19:26:15',NULL),(5,5,'days_before_due',2,'Pago Por Vencer','Recordatorio amigable: Tu cuota de mantenimiento vence en {x} días.',1,'2026-04-20 19:26:15','2026-04-20 19:26:15',NULL),(6,5,'due_date',0,'Pago Vence Hoy','Tu cuota de mantenimiento vence hoy. Por favor realiza tu pago para evitar cargos por mora.',1,'2026-04-20 19:26:15','2026-04-20 19:26:15',NULL),(7,6,'start_of_month',1,'Recordatorio Mensual de Cuota','¡Es inicio de mes! Recuerda pagar tu cuota de mantenimiento antes de la fecha de vencimiento.',1,'2026-04-20 21:42:33','2026-04-20 21:42:33',NULL),(8,6,'days_before_due',2,'Pago Por Vencer','Recordatorio amigable: Tu cuota de mantenimiento vence en {x} días.',1,'2026-04-20 21:42:33','2026-04-20 21:42:33',NULL),(9,6,'due_date',0,'Pago Vence Hoy','Tu cuota de mantenimiento vence hoy. Por favor realiza tu pago para evitar cargos por mora.',1,'2026-04-20 21:42:33','2026-04-20 21:42:33',NULL),(10,7,'start_of_month',1,'Recordatorio Mensual de Cuota','¡Es inicio de mes! Recuerda pagar tu cuota de mantenimiento antes de la fecha de vencimiento.',1,'2026-04-26 22:12:54','2026-04-26 22:12:54',NULL),(11,7,'days_before_due',2,'Pago Por Vencer','Recordatorio amigable: Tu cuota de mantenimiento vence en {x} días.',1,'2026-04-26 22:12:54','2026-04-26 22:12:54',NULL),(12,7,'due_date',0,'Pago Vence Hoy','Tu cuota de mantenimiento vence hoy. Por favor realiza tu pago para evitar cargos por mora.',1,'2026-04-26 22:12:54','2026-04-26 22:12:54',NULL),(16,8,'start_of_month',1,'Recordatorio Mensual de Cuota','¡Es inicio de mes! Recuerda pagar tu cuota de mantenimiento antes de la fecha de vencimiento.',1,'2026-04-27 13:07:21','2026-04-27 13:07:21',NULL),(17,8,'days_before_due',2,'Pago Por Vencer','Recordatorio amigable: Tu cuota de mantenimiento vence en {x} días.',1,'2026-04-27 13:07:21','2026-04-27 13:07:21',NULL),(18,8,'due_date',0,'Pago Vence Hoy','Tu cuota de mantenimiento vence hoy. Por favor realiza tu pago para evitar cargos por mora.',1,'2026-04-27 13:07:21','2026-04-27 13:07:21',NULL);
/*!40000 ALTER TABLE `payment_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `transaction_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','transfer','card','check') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'transfer',
  `reference_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `proof_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `status` enum('pending','approved','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_unit_id_foreign` (`unit_id`),
  KEY `condominium_id_created_at` (`condominium_id`,`created_at`),
  KEY `condominium_id_unit_id` (`condominium_id`,`unit_id`),
  KEY `payments_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `payments_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `payments_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `financial_transactions` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
  CONSTRAINT `payments_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (5,2,296,NULL,5000.00,'transfer','','payments/2/1776125285_587d5c47fbabe2951bdf.jpg','NOTA RESIDENTE','approved','2026-04-13 18:08:05','2026-04-13 19:34:08','2026-04-18 14:59:07'),(19,2,296,NULL,3000.00,'transfer','','payments/2/1776137115_3a0b14d055fd895dc9fe.jpg','','pending','2026-04-13 21:25:15','2026-04-13 21:25:15','2026-04-13 21:52:25'),(20,2,296,NULL,5000.00,'transfer','','payments/2/1776138523_2d4bc97921e441ed40a7.pdf','no se ve el comprobante, mandarlo de nuevo. ','rejected','2026-04-13 21:48:43','2026-04-13 21:56:13',NULL),(21,2,296,NULL,500.00,'transfer','','payments/2/1776138946_a9b64841bb0269bcd82f.jpg','','approved','2026-04-13 21:55:46','2026-04-13 21:57:04',NULL),(22,2,296,NULL,5000.00,'transfer','','payments/2/1776141202_6913a5f83be155ce45cc.jpg','peso','rejected','2026-04-13 22:33:22','2026-04-13 22:34:55',NULL),(23,2,296,NULL,5000.00,'transfer','','payments/2/1776141339_e7da52fb3be5b389cfb9.jpg','peso 5','rejected','2026-04-13 22:35:39','2026-04-13 22:36:52',NULL),(24,2,296,NULL,5000.00,'transfer','','payments/2/1776212484_a0f78488eeb8c33d87ed.pdf','no','rejected','2026-04-14 18:21:24','2026-04-14 18:23:10',NULL),(25,2,296,NULL,5000.00,'transfer','','payments/2/1776212529_8a6bfc6232cd497aae99.jpg','as','rejected','2026-04-14 18:22:09','2026-04-14 18:22:49',NULL),(26,2,296,NULL,5000.00,'transfer','','payments/2/1776217756_00abbecfb94a8435faaf.jpg','NO CORRESPONDE','rejected','2026-04-14 19:49:16','2026-04-14 19:49:42',NULL),(27,2,296,NULL,500.00,'transfer','','payments/2/1776217936_020c00e3ab1e0d8b33d0.pdf','ni','approved','2026-04-14 19:52:16','2026-04-14 19:53:15','2026-04-18 14:58:52'),(28,2,296,NULL,5000.00,'transfer','','payments/2/1776240437_7b3f58a3c404b690c581.jpg','duplicado','rejected','2026-04-15 02:07:17','2026-04-16 18:58:01',NULL),(29,2,296,NULL,5000.00,'transfer','','payments/2/1776385130_06928c3948f62fb13c58.jpg','','approved','2026-04-16 18:18:50','2026-04-16 18:21:52','2026-04-16 20:58:12'),(30,2,296,NULL,5000.00,'transfer','','payments/2/1776396905_8a47635b15a2ba7e616c.jpg','','approved','2026-04-16 21:35:05','2026-04-17 12:20:51','2026-04-18 14:58:42'),(31,2,296,NULL,500.00,'transfer','','payments/2/1776450126_342abd35bec35a5a1018.jpg','','approved','2026-04-17 12:22:06','2026-04-17 12:22:27','2026-04-18 14:58:32'),(32,2,296,297,2500.00,'transfer','','payments/2/1776538656_24f28b87825249a9d3b4.jpg','','approved','2026-04-18 12:57:36','2026-04-18 22:04:33',NULL),(33,2,296,NULL,5000.00,'transfer','','payments/2/1776566606_19bbb16d1c3966021b55.jpg','no','rejected','2026-04-18 20:43:26','2026-04-18 22:04:19',NULL),(34,2,296,350,22000.00,'transfer','','payments/2/1776575879_7fc10ce8622473ea4863.jpg','','approved','2026-04-18 23:17:59','2026-04-18 23:29:47',NULL),(35,2,296,393,50.00,'transfer','','payments/2/1776737970_c78319573c93fa578d91.jpg','','approved','2026-04-20 20:19:30','2026-04-20 20:20:21',NULL),(36,5,456,394,4000.00,'transfer','','payments/5/1776745263_671b7fe5e6f16a66f6d3.jpg','','approved','2026-04-20 22:21:03','2026-04-20 22:21:25',NULL),(37,2,296,395,100.00,'transfer','','payments/2/1777264763_a943a39d3b6a715fe9d8.jpg','','approved','2026-04-26 22:39:23','2026-04-26 22:39:38',NULL),(38,2,296,NULL,50.00,'transfer','','payments/2/1777309412_577cf32d837fed33976d.jpg','noseve','rejected','2026-04-27 11:03:32','2026-04-27 12:58:52',NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `device_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `personal_access_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `personal_access_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (5,8,'a4571237b9ae8956afe2983b77045088b6a00e74e575877f1daeb0ad13a1f231','PWA Resident',NULL,'2027-03-13 04:26:27','2026-03-13 04:26:27','2026-03-13 04:26:27'),(8,12,'210be81b6bfb993490beafab0ab3633a0ae5f522e445d86689209f2ee3dc4e39','PWA Resident',NULL,'2027-03-13 05:14:17','2026-03-13 05:14:17','2026-03-13 05:14:17'),(10,11,'252656667d4afcc7795bdb1b52e087f951f62df063570b07f24b0c119897cde0','PWA Resident',NULL,'2027-03-27 22:46:35','2026-03-27 22:46:35','2026-03-27 22:46:35'),(12,6,'63abd570ddffc0a33dc7a8cd2c3fe973487905761be66d75b18ad767f509d306','PWA Security Gate','2026-03-28 00:17:52','2027-03-28 00:15:22','2026-03-28 00:15:22','2026-03-28 00:17:52'),(13,6,'e69318a240cabfb6d6273eb5912842785fc0245d0f4cd881623099e8b3183167','PWA Security Gate','2026-03-28 01:43:58','2027-03-28 00:18:51','2026-03-28 00:18:51','2026-03-28 01:43:58'),(14,6,'141409675c4cbc2734d65842a49a472f96fa9e91669d07f7d367a56c4700f78d','PWA Security Gate','2026-03-28 14:28:23','2027-03-28 14:28:20','2026-03-28 14:28:20','2026-03-28 14:28:23'),(16,6,'ebb1bc966f7c9ccca630ff143cbb97e3ed5a00ecbc789a9aca104f34fd3ce74e','PWA Security Gate','2026-04-01 15:43:55','2027-03-28 18:28:54','2026-03-28 18:28:54','2026-04-01 15:43:55'),(17,6,'683c39c02d0e6d7f8292c2222fe9d77042579dc9b103bcba5f95c4cac5e4bc35','PWA Security Gate','2026-03-29 14:28:34','2027-03-29 14:26:51','2026-03-29 14:26:51','2026-03-29 14:28:34'),(18,13,'199e47931a1a421f8ea9f3127ba43ed31dda474302a854bd73659c14778380b6','PWA Security Gate','2026-03-30 14:15:27','2027-03-30 13:37:17','2026-03-30 13:37:17','2026-03-30 14:15:27'),(19,6,'2d4f8742a9809d966b3f29bf1964b3777c5f5da8270fe632ec3a440b9506cf95','PWA Security Gate','2026-03-30 14:16:44','2027-03-30 14:16:29','2026-03-30 14:16:29','2026-03-30 14:16:44'),(20,6,'808c05f5a000d34f969ee0d89cc35940bc5458e16a240a763712054acf11b742','PWA Security Gate','2026-03-30 16:31:32','2027-03-30 14:18:01','2026-03-30 14:18:01','2026-03-30 16:31:32'),(21,13,'b2da6ad6a726f81d65c3a9be4c11776919e220b61823817ba53156105837bce0','PWA Security Gate','2026-03-30 21:00:33','2027-03-30 21:00:33','2026-03-30 21:00:33','2026-03-30 21:00:33'),(31,13,'aea7256c0c020305c91108f6f21ac4ce08243af8548b39598c34813f755c9f4a','App Guardia Flutter',NULL,'2027-03-31 00:02:03','2026-03-31 00:02:03','2026-03-31 00:02:03'),(32,13,'d632b0e74ca4cbd1c9154512cf1246bfa7a12e5ddf12f58cff16e5264a9ddce9','App Guardia Flutter',NULL,'2027-03-31 00:10:43','2026-03-31 00:10:43','2026-03-31 00:10:43'),(33,13,'d9d2c51c5dbd56097af87c3750d85833fc0c21097493d73956755ce26a24d0c2','App Guardia Flutter',NULL,'2027-03-31 00:15:47','2026-03-31 00:15:47','2026-03-31 00:15:47'),(34,13,'f6009ff216640766600a9f2fe6714a9f21a2163a6909325ff0e88814a5393c97','App Guardia Flutter',NULL,'2027-03-31 00:21:14','2026-03-31 00:21:14','2026-03-31 00:21:14'),(35,6,'c84d82d150e4ab349a4602f5171ca1c5764b404c04d52cfe0c7ac5ae19e17cf9','PWA Security Gate','2026-03-31 00:28:07','2027-03-31 00:26:20','2026-03-31 00:26:20','2026-03-31 00:28:07'),(36,13,'9f491b2919843f7301ce8d5206888a1dcde1fd4e4caddcb310ca297a411caf7d','App Guardia Flutter','2026-03-31 00:31:15','2027-03-31 00:29:54','2026-03-31 00:29:54','2026-03-31 00:31:15'),(37,13,'8104f9799981320b11965ff8ecd3c526421c34ae68e8a74ad5c064280124a25a','App Guardia Flutter','2026-03-31 10:15:39','2027-03-31 10:15:25','2026-03-31 10:15:25','2026-03-31 10:15:39'),(39,14,'e7ba82ae516adcf8282d30f0f1e518f6e72547246ebdd9cf36f7c20fd566a4f0','PWA Security Gate','2026-04-12 14:53:59','2027-04-06 13:21:54','2026-04-06 13:21:54','2026-04-12 14:53:59'),(40,11,'9151c384da0ed95d61334767fc557e712dd8c9b4914a008e49c70a72b6248316','PWA Resident',NULL,'2027-04-06 19:40:57','2026-04-06 19:40:57','2026-04-06 19:40:57'),(41,14,'b275e66e2a9feee1d03ba9ee7bdebfe0f064eb8e9cdd5ff013181ee0ff958fa9','PWA Security Gate','2026-04-06 22:15:06','2027-04-06 21:01:58','2026-04-06 21:01:58','2026-04-06 22:15:06'),(43,11,'2e9d2761fa63713c2e21d4f1a79664503bcaeafd00c057808085b4a6802456a0','PWA Resident',NULL,'2027-04-08 18:09:40','2026-04-08 18:09:40','2026-04-08 18:09:40'),(44,14,'540d6290bb0ea73724462c57b0a61187c377d136502442a2f4ac35e5a4f21cf2','App Guardia Flutter','2026-04-09 13:44:25','2027-04-09 13:39:11','2026-04-09 13:39:11','2026-04-09 13:44:25'),(45,14,'29060deecb34dfa1c60233f2a8f8d7eef77e5dc20395a435d5a93efbfae4f2ad','App Guardia Flutter','2026-04-09 18:24:28','2027-04-09 18:20:56','2026-04-09 18:20:56','2026-04-09 18:24:28'),(46,14,'0ae294560c8769e8fb9edd9b72197617f56679b096bebcfe84a810dc407698af','App Guardia Flutter','2026-04-14 12:37:16','2027-04-09 18:31:14','2026-04-09 18:31:14','2026-04-14 12:37:16'),(47,14,'3f51f5995d5de976b8a134369b086c38af3362e728bea397747f42f48cdc5e7a','App Guardia Flutter','2026-04-09 22:08:45','2027-04-09 20:24:13','2026-04-09 20:24:13','2026-04-09 22:08:45'),(48,14,'53006efa04e4b37611f687b294ab33d49b102d8da278084cedb71033533dfd03','App Guardia Flutter','2026-04-09 22:15:20','2027-04-09 22:09:47','2026-04-09 22:09:47','2026-04-09 22:15:20'),(49,14,'8d278b83d464368fbdb5f0e4962a9ee82cbfafcc823166265dc5bac906c57288','App Guardia Flutter','2026-04-10 13:19:05','2027-04-09 22:27:55','2026-04-09 22:27:55','2026-04-10 13:19:05'),(50,14,'e6f1be6079ce4250d4f9729069e7e49fba625ac3204cb1c8028661f30f7418cd','App Guardia Flutter','2026-04-10 14:49:58','2027-04-10 14:17:59','2026-04-10 14:17:59','2026-04-10 14:49:58'),(51,14,'c6477a3c273ca3568b7decfce845f5cb8f519e43bbc9343804874a2a5eb24205','App Guardia Flutter','2026-04-10 15:56:33','2027-04-10 14:50:52','2026-04-10 14:50:52','2026-04-10 15:56:33'),(52,14,'9703442bf4bfd4d2a2d1880f28ed06506983445a6ce87754d59addfba1fc482a','App Guardia Flutter','2026-04-12 11:29:54','2027-04-10 16:03:30','2026-04-10 16:03:30','2026-04-12 11:29:54'),(53,11,'bd27c30c79b2e76f80e91c943381e7b5aa4f3b13e7fc2cece7379765c9197d0a','App Guardia Flutter','2026-04-12 12:03:06','2027-04-12 12:02:24','2026-04-12 12:02:24','2026-04-12 12:03:06'),(54,11,'365c21f25a8953a75cb537e71f0ce314e72c742a34ffc4901d5d144d946a3cd3','App Guardia Flutter','2026-04-12 12:08:39','2027-04-12 12:05:51','2026-04-12 12:05:51','2026-04-12 12:08:39'),(55,11,'41751df96014444d6cbc6a9aa9b075f2077a851bf8fa24cf2c78adec47bf22b4','App Guardia Flutter','2026-04-12 12:12:24','2027-04-12 12:12:23','2026-04-12 12:12:23','2026-04-12 12:12:24'),(56,11,'550027c467d3321a52632a6bc6c2b3e531f317920270b99b691aeac06d212236','App Guardia Flutter','2026-04-12 12:22:11','2027-04-12 12:16:43','2026-04-12 12:16:43','2026-04-12 12:22:11'),(57,11,'4e527b699cd55194003959fd31c2401e790b353e136ef4d276e1dfc541581ba3','App Guardia Flutter','2026-04-12 12:39:23','2027-04-12 12:22:29','2026-04-12 12:22:29','2026-04-12 12:39:23'),(59,11,'60aadb6d515ffb2ccbee5cc1d66c3d400656e19a8153324967ae5c2d3b08fd07','App Guardia Flutter','2026-04-12 12:39:58','2027-04-12 12:39:58','2026-04-12 12:39:58','2026-04-12 12:39:58'),(61,11,'0982e92e038930d3b3860b0017928d8fadd46d1f4975ed16c0cd0d738935258f','App Guardia Flutter','2026-04-12 12:47:20','2027-04-12 12:45:41','2026-04-12 12:45:41','2026-04-12 12:47:20'),(64,11,'23ebf900bd57e13e2c64eb44eaf02a40161b7842237f2eeb5f2abcaa169411f1','App Guardia Flutter',NULL,'2027-04-12 12:59:58','2026-04-12 12:59:58','2026-04-12 12:59:58'),(65,14,'e734aa44d8b17376bccf07fb2c7f0eee2ec05646049b8775ffaeb28d6aa33247','App Guardia Flutter','2026-04-12 13:13:12','2027-04-12 13:12:48','2026-04-12 13:12:48','2026-04-12 13:13:12'),(66,19,'c7e189204b917e12072ec3b08102d29602ff746c444ef38f3122a373e25a206d','App Guardia Flutter','2026-04-12 13:16:47','2027-04-12 13:16:27','2026-04-12 13:16:27','2026-04-12 13:16:47'),(67,14,'f6daf57620f99679469dec779157ec8f840b69050ab746ee70227fca718d857f','App Guardia Flutter','2026-04-12 13:17:56','2027-04-12 13:17:20','2026-04-12 13:17:20','2026-04-12 13:17:56'),(68,11,'19a214a86ba7b67a1769db5a0be7422bd550961d80ad72e07c0a551fa09cf379','App Guardia Flutter',NULL,'2027-04-12 13:18:22','2026-04-12 13:18:22','2026-04-12 13:18:22'),(69,11,'326569f666a9d714e8cd7feddf8e63b09c180fde5bc6480347c210240fae663f','App Guardia Flutter','2026-04-12 13:56:44','2027-04-12 13:21:45','2026-04-12 13:21:45','2026-04-12 13:56:44'),(70,11,'20a791a017f3a94b7183bc270f075701dda5cfdc4740ace99254f920d61c3b99','App Guardia Flutter',NULL,'2027-04-12 14:01:17','2026-04-12 14:01:17','2026-04-12 14:01:17'),(71,11,'1aec5ad42668d002e2ea87d711cb3f1b25ac3208f46745f537b900f525d0e495','App Guardia Flutter',NULL,'2027-04-12 14:04:31','2026-04-12 14:04:31','2026-04-12 14:04:31'),(72,11,'3fc26f81ca0859bb03385451dc5f55f6a222c2d76cbbc7ed258d9fd65c107637','App Guardia Flutter',NULL,'2027-04-12 14:09:10','2026-04-12 14:09:10','2026-04-12 14:09:10'),(73,11,'24dd1783a46465fb24b2b74355183c497d3e44a4b904845c59abd6e86a331cf9','App Guardia Flutter','2026-04-12 14:22:44','2027-04-12 14:18:08','2026-04-12 14:18:08','2026-04-12 14:22:44'),(74,11,'5ab9706405359cb112d61aedef241d9dee3abaac0af95e1241a3be4117e73ede','App Guardia Flutter','2026-04-12 14:33:27','2027-04-12 14:23:14','2026-04-12 14:23:14','2026-04-12 14:33:27'),(75,11,'86b01df78357655a0ed5bc8d26bf1a5fa62ae204975b3ee1a7d00ae685532abd','App Guardia Flutter','2026-04-12 14:54:42','2027-04-12 14:34:52','2026-04-12 14:34:52','2026-04-12 14:54:42'),(76,11,'c855496b36b26e9773d651fe280b19cc6ab9d6b46b6042d0c2a2753bfe07b1a9','App Guardia Flutter','2026-04-12 16:13:26','2027-04-12 15:06:23','2026-04-12 15:06:23','2026-04-12 16:13:26'),(77,14,'d75218d431514e0a49e4aff5c2ae162ba75273739557ab19ca05fa196d0d68d6','App Guardia Flutter','2026-04-12 16:44:04','2027-04-12 16:42:22','2026-04-12 16:42:22','2026-04-12 16:44:04'),(78,11,'cc6425ae84c89553f1f795b7b14e5d24a883c39634126350d48a23ad9129809a','App Guardia Flutter','2026-04-12 21:59:49','2027-04-12 16:44:23','2026-04-12 16:44:23','2026-04-12 21:59:49'),(79,11,'bc2f05056cd4c8bb8405f1190b036a5153472b421f5d63f8afa551a75fb9a515','App Guardia Flutter','2026-04-12 22:24:20','2027-04-12 22:00:11','2026-04-12 22:00:11','2026-04-12 22:24:20'),(80,14,'eb33ad4563cfce8abcf393eb8badc574c019f28b9e4044013e8988ee4f65e114','App Guardia Flutter','2026-04-12 22:38:53','2027-04-12 22:24:49','2026-04-12 22:24:49','2026-04-12 22:38:53'),(81,11,'845bbe62c8a43f47be7149f19a59166c9922b51e6ea1a7d2e8d7350fb25e1d99','App Guardia Flutter','2026-04-12 23:06:03','2027-04-12 22:39:25','2026-04-12 22:39:25','2026-04-12 23:06:03'),(82,14,'ce88cc54d30b6985bf0c717b35bb9d38b9ecae7d5ce4c62731b1ea696d6acd1a','PWA Security Gate','2026-04-12 23:07:17','2027-04-12 23:07:12','2026-04-12 23:07:12','2026-04-12 23:07:17'),(83,11,'0f74e4527174eddc0f8c0d9097bfbbb3f06b4951ee4c81edfc4ab1cdeb568d0a','Generic PWA Device',NULL,'2027-04-12 23:07:56','2026-04-12 23:07:56','2026-04-12 23:07:56'),(84,11,'3c1d95edaaa1b921943a6a3cd133bbbe90dd1fb9a65fd9d1c71dfebca73fcf2e','Generic PWA Device',NULL,'2027-04-12 23:08:02','2026-04-12 23:08:02','2026-04-12 23:08:02'),(85,14,'0c77f6e5916c3576b73973541f0adfe01a2971af727e7dfe8af5f3198b252912','Generic PWA Device',NULL,'2027-04-12 23:10:02','2026-04-12 23:10:02','2026-04-12 23:10:02'),(86,14,'41e32e0343dac2ad535bcd00bd7a8f32278b2eec852a1b787fa926f89745d1ab','Generic PWA Device',NULL,'2027-04-12 23:13:09','2026-04-12 23:13:09','2026-04-12 23:13:09'),(87,14,'7c626c39cd1fcb364207a6617c9ce121b19f0f9f2ab3dfde39a757bc78070c6b','Generic PWA Device','2026-04-12 23:19:42','2027-04-12 23:14:09','2026-04-12 23:14:09','2026-04-12 23:19:42'),(88,14,'d0e6d46af542236dec174dc10c99260bde78089ac74316e025fa8e305088df34','Generic PWA Device','2026-04-12 23:57:57','2027-04-12 23:24:27','2026-04-12 23:24:27','2026-04-12 23:57:57'),(89,11,'7b6b2b959068ffb19cf11a62f65876c74791b2cd6f461fef1fb30edcdc5d34e7','Generic PWA Device','2026-04-13 00:10:24','2027-04-12 23:58:17','2026-04-12 23:58:17','2026-04-13 00:10:24'),(90,14,'eada352db210a01a3ef972f188f71b6b1b2750c6f1632b39e76d247656160cb7','Generic PWA Device','2026-04-13 00:13:05','2027-04-13 00:11:39','2026-04-13 00:11:39','2026-04-13 00:13:05'),(91,11,'2d78f3d67ef77b216c1ca341a5d398101f75386320e578950bf95f7592bad64a','Generic PWA Device','2026-04-13 01:19:46','2027-04-13 00:13:34','2026-04-13 00:13:34','2026-04-13 01:19:46'),(92,11,'2c6c0ff6e72d49412b3e021efe33e72bc08e2dfde868d332abf8026ca3ad7860','Generic PWA Device','2026-04-13 09:55:22','2027-04-13 09:55:07','2026-04-13 09:55:07','2026-04-13 09:55:22'),(93,14,'7e459de3418290b806333fdc62e792fe425d81aef647b4c13554ea261221cb38','Generic PWA Device','2026-04-13 10:14:42','2027-04-13 10:03:00','2026-04-13 10:03:00','2026-04-13 10:14:42'),(94,11,'8de1a9e3dbd7f8e6b70f7cbc497c54dd9e993982bad450d6b0a56d2e20be732b','Generic PWA Device','2026-04-13 11:07:27','2027-04-13 10:04:23','2026-04-13 10:04:23','2026-04-13 11:07:27'),(95,11,'0b7c46ef9a17f798eaad3e268d2905b8c4e8b9f0bf78e587a09ce77fc24c9683','Generic PWA Device','2026-04-13 18:38:29','2027-04-13 11:18:03','2026-04-13 11:18:03','2026-04-13 18:38:29'),(96,14,'bbcfdc3b082138a0426c411ace083ff6c079736685d93faf610ebcac49eb3010','Generic PWA Device','2026-04-13 19:06:18','2027-04-13 18:57:09','2026-04-13 18:57:09','2026-04-13 19:06:18'),(97,11,'02df1e1242dc21813f61dae8c2732a3208058e884120629b0671b40a5296936c','Generic PWA Device','2026-04-13 19:05:02','2027-04-13 19:00:18','2026-04-13 19:00:18','2026-04-13 19:05:02'),(98,11,'1655c8c771d3ad452f5de47093bf2b2a756165964ab50aae7b0cf6c46e7e24a4','Generic PWA Device','2026-04-13 19:08:25','2027-04-13 19:05:22','2026-04-13 19:05:22','2026-04-13 19:08:25'),(99,11,'8f51a90304cfc1608e0ed768839a3ed580a8f01456daa255aa2d8c8ab371b194','Generic PWA Device','2026-04-13 20:49:22','2027-04-13 19:11:35','2026-04-13 19:11:35','2026-04-13 20:49:22'),(100,11,'c4e5418edd42664699a389a4c336f85acc0ef02d4345d39f18a9ad566188449c','Generic PWA Device','2026-04-13 22:47:20','2027-04-13 20:51:24','2026-04-13 20:51:24','2026-04-13 22:47:20'),(101,14,'15fcf049031c848bd904056f133ab270b4a04df35e535acef55b26a797a2d666','Generic PWA Device','2026-04-13 22:08:43','2027-04-13 22:07:55','2026-04-13 22:07:55','2026-04-13 22:08:43'),(102,11,'555da5020ee13f24315a18b245a7a3c8f22b782d2b8375001af061bfb8ef9e42','Generic PWA Device','2026-04-13 22:46:42','2027-04-13 22:13:35','2026-04-13 22:13:35','2026-04-13 22:46:42'),(103,11,'f35eec9ac5ac7d21b7d94fc5271b4e3dcd6940167b0e912f1dc91cb3393e6a3e','Generic PWA Device','2026-04-14 21:58:53','2027-04-13 22:50:33','2026-04-13 22:50:33','2026-04-14 21:58:53'),(104,11,'868a1704bc02528e54148b1121329346bfc2719399eed14b068c63f058b89f04','Generic PWA Device','2026-04-15 02:53:24','2027-04-14 12:36:33','2026-04-14 12:36:33','2026-04-15 02:53:24'),(105,14,'465482590ddea491ffd2e30bf2e3f08868f2c3a0a49de79b6049d5ae9e819ff1','Generic PWA Device','2026-04-14 21:20:22','2027-04-14 20:53:07','2026-04-14 20:53:07','2026-04-14 21:20:22'),(106,11,'7dfbc7173117392110de245d83a56a318f2e31a0d1a8cdc2e385c6a174094a67','Generic PWA Device','2026-04-14 23:10:41','2027-04-14 21:35:37','2026-04-14 21:35:37','2026-04-14 23:10:41'),(107,11,'1ef0a71e21bf75b8d1136a09e4fa2f6971502f6b3ed01761cda5ae8fb6211543','Generic PWA Device','2026-04-14 23:46:41','2027-04-14 23:20:53','2026-04-14 23:20:53','2026-04-14 23:46:41'),(108,11,'077a2b58fd0575d775aebb212393c6f1c040a739b5e8256451822eaf2f2d0402','Generic PWA Device','2026-04-14 23:57:27','2027-04-14 23:47:05','2026-04-14 23:47:05','2026-04-14 23:57:27'),(109,11,'61f4c740a7e1bdac2feee6c45d8e2aeca3b035a19a70614a85e769475fcbfbf7','Generic PWA Device','2026-04-14 23:58:18','2027-04-14 23:57:59','2026-04-14 23:57:59','2026-04-14 23:58:18'),(110,11,'6553fb48917d0d906b1fbe0a9a162b34c9f29192d1b11be22add6f47fa82a159','Generic PWA Device','2026-04-15 01:02:04','2027-04-15 00:04:54','2026-04-15 00:04:54','2026-04-15 01:02:04'),(111,11,'0c28c57e1a45b1261db876420c45f9e0ac6d0966c2f958ed3ccdb82015bbf559','Generic PWA Device','2026-04-15 02:01:11','2027-04-15 01:16:28','2026-04-15 01:16:28','2026-04-15 02:01:11'),(112,11,'da7468d33826797e66db122fd180fde616bebba4e5879db2d53dab3e7eb2584b','Generic PWA Device','2026-04-15 07:23:47','2027-04-15 02:03:42','2026-04-15 02:03:42','2026-04-15 07:23:47'),(113,14,'4e9afec1fce51732a62ac6536500518f887607028b39528ff7f1bc50cfd9033a','Generic PWA Device','2026-04-15 02:55:21','2027-04-15 02:55:13','2026-04-15 02:55:13','2026-04-15 02:55:21'),(114,11,'53b0afd2229d3a560d6293b26eb6026f11d7363606070f091ae04a63f08b22b3','Generic PWA Device','2026-04-17 10:47:31','2027-04-15 02:56:32','2026-04-15 02:56:32','2026-04-17 10:47:31'),(115,14,'b87175248a237333a1cf7e696f592da35193a5f3136558b76e64fcc5c38b38a0','Generic PWA Device','2026-04-15 07:25:50','2027-04-15 07:24:04','2026-04-15 07:24:04','2026-04-15 07:25:50'),(116,4,'658d691ca1eed27d9dd0457f706d77ebe70b9501e2a0f0bfa179688f9f521b33','Generic PWA Device','2026-04-15 07:26:55','2027-04-15 07:26:53','2026-04-15 07:26:53','2026-04-15 07:26:55'),(117,11,'6e9606548e1d4d44e26232eda4396efda046e98715ee7938315fad6a52013724','Generic PWA Device','2026-04-15 12:38:06','2027-04-15 07:27:13','2026-04-15 07:27:13','2026-04-15 12:38:06'),(118,11,'ff4d9baf213279f9f63d42009126cdc3baa8ee44f9793e17ad96f161eb9bbb6a','Generic PWA Device','2026-04-15 12:45:35','2027-04-15 12:38:28','2026-04-15 12:38:28','2026-04-15 12:45:35'),(119,11,'e477384ab32f610babfc807ccd0f2d98ab647788f41cfddf29543367334a89f1','Generic PWA Device','2026-04-15 12:51:25','2027-04-15 12:47:44','2026-04-15 12:47:44','2026-04-15 12:51:25'),(120,11,'38ba19784055b5c893508508ef41ca91a561c4ccdc6e9a55cb3f00530d59eb34','Generic PWA Device','2026-04-15 13:59:51','2027-04-15 12:57:29','2026-04-15 12:57:29','2026-04-15 13:59:51'),(121,11,'ffeeb554552bcbb0f4ae69f4d5a550651b607b6afb7cd9d84356304fc86de43f','Generic PWA Device','2026-04-16 11:18:32','2027-04-15 14:17:24','2026-04-15 14:17:24','2026-04-16 11:18:32'),(122,14,'647eae32500a7b3410bc5682b7ec32c65735b78105abf8979cddfaac9f1af74a','Generic PWA Device','2026-04-16 12:14:07','2027-04-16 12:06:10','2026-04-16 12:06:10','2026-04-16 12:14:07'),(123,11,'95552046bea184a22186bef44080af524a415ede56642f11244bb936636b9bd5','Generic PWA Device','2026-04-16 12:20:59','2027-04-16 12:14:26','2026-04-16 12:14:26','2026-04-16 12:20:59'),(124,11,'0a4b58650f4db4161529dc03e6d16a840f9bfcc20b7e3c334f1edc4ea551b3d6','Generic PWA Device','2026-04-16 12:35:43','2027-04-16 12:26:24','2026-04-16 12:26:24','2026-04-16 12:35:43'),(127,11,'4f249b18249ec1472f9097f9a1a4d5bfaf04e8910b2f7c6fd3c1b7f6545d9f1d','Generic PWA Device','2026-04-16 21:25:26','2027-04-16 12:40:59','2026-04-16 12:40:59','2026-04-16 21:25:26'),(128,14,'5172b4ed8dbc8a13cc91b4434bad02ddd58a4328201273a804de2b2472126578','Generic PWA Device','2026-04-16 21:26:04','2027-04-16 21:26:01','2026-04-16 21:26:01','2026-04-16 21:26:04'),(129,11,'63c9a8d3cb4e78ddd68aa93db7a63b1afe0040af4b5aa9c0ab5fdd5d3977e1be','Generic PWA Device','2026-04-16 23:09:58','2027-04-16 21:32:22','2026-04-16 21:32:22','2026-04-16 23:09:58'),(130,11,'a305c6b9af8c3af50712b414461b1f069dd81c3b12069e3bf8e59a4cd9d6e381','Generic PWA Device','2026-04-17 12:53:52','2027-04-16 23:15:17','2026-04-16 23:15:17','2026-04-17 12:53:52'),(131,14,'c2424ea151d0da5f830a1a28c4293e853789e45ce79209693ed76457419ce4e6','Generic PWA Device','2026-04-17 12:53:47','2027-04-17 10:48:20','2026-04-17 10:48:20','2026-04-17 12:53:47'),(133,14,'1595cb9b47431ced68f1c0cca18620e1206d875960bd5cdbf22fe8f8d653f6a4','Generic PWA Device','2026-04-17 13:19:22','2027-04-17 12:55:14','2026-04-17 12:55:14','2026-04-17 13:19:22'),(134,11,'dfb5fc7bf21e53b29b51d2ae5ad4f6d7377eb5425ac483ca977c9e0ebe567ea2','Generic PWA Device','2026-04-17 20:44:17','2027-04-17 13:19:41','2026-04-17 13:19:41','2026-04-17 20:44:17'),(135,11,'0f0bdc8757b1c45b535cbb40489c90b4fb9e87025ee0da3ec7f867afc9456c55','Generic PWA Device','2026-04-17 21:19:09','2027-04-17 20:54:46','2026-04-17 20:54:46','2026-04-17 21:19:09'),(136,11,'c7168c25a92630e98bf9e3213ab6e1fc4d7803300b44d86c6938cca9378e3e36','Generic PWA Device','2026-04-17 21:22:32','2027-04-17 21:22:18','2026-04-17 21:22:18','2026-04-17 21:22:32'),(137,11,'dd6e4a78fedf6f243ebddb1a0b9b704b78d20ddc43a3c020a8e70b3ba98c26ea','Generic PWA Device','2026-04-17 21:24:05','2027-04-17 21:23:25','2026-04-17 21:23:25','2026-04-17 21:24:05'),(138,20,'4506b76ca895d42d977d63588edfb39842612a1140702e73d4eb1be0822dbaec','Generic PWA Device','2026-04-17 21:29:17','2027-04-17 21:27:36','2026-04-17 21:27:36','2026-04-17 21:29:17'),(139,11,'185575e0281d1cbae00e83753a55a19c5ee38f7b82fe4df6b3ae95b57088b62a','Generic PWA Device','2026-04-17 21:30:39','2027-04-17 21:29:32','2026-04-17 21:29:32','2026-04-17 21:30:39'),(140,11,'18f19eb1f77cafc3468a750aee0d724ac3957ecac133cbe9b62cc2724c513ac0','Generic PWA Device','2026-04-17 21:31:07','2027-04-17 21:31:02','2026-04-17 21:31:02','2026-04-17 21:31:07'),(141,11,'292a4f058f6e67e1c59b642913038ec9c0b11ae83200b08837cc6d7eeba993be','Generic PWA Device','2026-04-17 21:36:06','2027-04-17 21:35:59','2026-04-17 21:35:59','2026-04-17 21:36:06'),(142,11,'703fc7940d80c974b837c42192e10ce53c00f07de17a3ce4b5dfac371fae9f04','Generic PWA Device','2026-04-17 21:36:27','2027-04-17 21:36:22','2026-04-17 21:36:22','2026-04-17 21:36:27'),(143,11,'552ceb67becd1823f640372d2529a461426c13a5b4621f233e6dd15704d02424','Generic PWA Device','2026-04-18 13:41:33','2027-04-17 21:36:53','2026-04-17 21:36:53','2026-04-18 13:41:33'),(144,11,'d4d2daae02ded0098cf784653d358c28f70a59c89945821fa3f3c63fc1567941','Generic PWA Device','2026-04-18 15:11:54','2027-04-18 15:01:25','2026-04-18 15:01:25','2026-04-18 15:11:54'),(145,11,'9cdcb14860b26d6d66bfb5f9911091ed92b88cf220350f386d8ea1996ca7269f','Generic PWA Device','2026-04-18 20:17:20','2027-04-18 15:12:43','2026-04-18 15:12:43','2026-04-18 20:17:20'),(146,11,'23ab34e60d0e9f21ced1ad72ca84bad4b0deec97eb6605169eef095bdd9ddb54','Generic PWA Device','2026-04-18 20:45:40','2027-04-18 20:29:15','2026-04-18 20:29:15','2026-04-18 20:45:40'),(147,11,'8ade12a2f602cf6ee529adafd34bbe07a66af6238a13276f220527fea4d0c831','Generic PWA Device','2026-04-20 19:50:00','2027-04-18 21:20:29','2026-04-18 21:20:29','2026-04-20 19:50:00'),(148,4,'711b1361ce24712c7e2ddd7016645c19c959b3acdf63df271bc84b70231cde59','Generic PWA Device','2026-04-20 19:50:26','2027-04-20 19:50:23','2026-04-20 19:50:23','2026-04-20 19:50:26'),(149,11,'21b676a07a7a523bec74d6f9d5810674f8028c9076ffa07a160c6206dfbe5cee','Generic PWA Device','2026-04-20 19:51:03','2027-04-20 19:51:01','2026-04-20 19:51:01','2026-04-20 19:51:03'),(150,11,'6c852160775225bcb788c64effb8f7a59a8ed9429bf8dd3e29b537f0ee972eb1','Generic PWA Device','2026-04-20 19:57:42','2027-04-20 19:57:31','2026-04-20 19:57:31','2026-04-20 19:57:42'),(151,11,'73838cfbbb854386effb972e30cdd49c6f6e2f461f8efd2fff271574233fe296','Generic PWA Device','2026-04-20 20:05:35','2027-04-20 20:01:36','2026-04-20 20:01:36','2026-04-20 20:05:35'),(152,11,'37e1c1baa5ef85af3b61e8d7cb1919b736a0ee76d6bf474c8c0842af5a8c6c41','Generic PWA Device','2026-04-20 20:11:23','2027-04-20 20:05:55','2026-04-20 20:05:55','2026-04-20 20:11:23'),(153,11,'d6f7814c74f3cabe0c71b043994f2d6fd64753270a7a2e64545cabfe542d0c7d','Generic PWA Device','2026-04-20 20:15:04','2027-04-20 20:14:36','2026-04-20 20:14:36','2026-04-20 20:15:04'),(154,11,'515caf7ec08dab2828a7d9ed25ba56296ea4a56b0d1a7fff45f686a71b697c87','Generic PWA Device','2026-04-20 20:20:28','2027-04-20 20:19:07','2026-04-20 20:19:07','2026-04-20 20:20:28'),(155,11,'c29c6c05b53b81cdd4db4d1d8060a08792fabaf406372e6c93e24749046822dc','Generic PWA Device','2026-04-20 20:32:45','2027-04-20 20:25:29','2026-04-20 20:25:29','2026-04-20 20:32:45'),(156,11,'7f14fe4941b43e3920e2633a117a52a5dc493de089dcf09808d5d37bbf8fce34','Generic PWA Device','2026-04-20 20:39:16','2027-04-20 20:36:19','2026-04-20 20:36:19','2026-04-20 20:39:16'),(157,11,'3f3fef1ca1616423213fc5503cf0a0ea792dddeb914e449429f7443da0ef183a','Generic PWA Device','2026-04-20 20:45:53','2027-04-20 20:44:41','2026-04-20 20:44:41','2026-04-20 20:45:53'),(158,14,'ad11b112d6c5b6d42bc7df96ce471d46929d06908831d6cf160a85e9f52a9b62','Generic PWA Device','2026-04-20 20:49:14','2027-04-20 20:46:19','2026-04-20 20:46:19','2026-04-20 20:49:14'),(159,11,'e9720059bbcbc8192327b5764c6231f18bc216e5a268a7a43a5551fd5d36dfeb','Generic PWA Device','2026-04-20 21:51:49','2027-04-20 20:49:31','2026-04-20 20:49:31','2026-04-20 21:51:49'),(160,11,'5af3faa7cb83f1336281932fadfaa2fe0ee52d56434f48cae21843c5ff00fa73','Generic PWA Device','2026-04-20 22:18:16','2027-04-20 21:52:13','2026-04-20 21:52:13','2026-04-20 22:18:16'),(162,21,'bd0651e95bb2b9a902ee854368b2073388633dde683bd5ed91e007b8dbc30d99','Generic PWA Device','2026-04-20 22:49:23','2027-04-20 22:18:48','2026-04-20 22:18:48','2026-04-20 22:49:23'),(163,21,'49b3d9e25987a8b37b1441133105854b0e004b1d33ae43a5579468d947b600d8','Generic PWA Device','2026-04-20 22:59:42','2027-04-20 22:49:39','2026-04-20 22:49:39','2026-04-20 22:59:42'),(164,21,'6f040452b4ec494ad140d467f6fc833ce9ab4874193d0e1c04f5de6faba5d414','Generic PWA Device','2026-04-20 23:03:18','2027-04-20 22:59:56','2026-04-20 22:59:56','2026-04-20 23:03:18'),(170,11,'879e9e148910ed5c94061f5a2bb85c6c9c532517cc299a27d3ee1b4cbceeee5a','Generic PWA Device','2026-04-21 00:31:44','2027-04-21 00:04:20','2026-04-21 00:04:20','2026-04-21 00:31:44'),(171,11,'51657be0f995d36772ae1af607cf242b80b9fd4681a14cdcda209e09270d34f2','Generic PWA Device','2026-04-21 08:46:09','2027-04-21 08:45:12','2026-04-21 08:45:12','2026-04-21 08:46:09'),(172,11,'9702742ee621e6a2a8b2d681518a7c0576b98cb64ba887b1fb1fa051089e55a7','Generic PWA Device','2026-04-26 21:26:34','2027-04-26 21:26:13','2026-04-26 21:26:13','2026-04-26 21:26:34'),(173,4,'9a7f03df76fe9d941d4cceda1a4a8b4f99d261b72c94ece7947ed6fdb2e711b0','Generic PWA Device','2026-04-26 22:05:08','2027-04-26 21:26:50','2026-04-26 21:26:50','2026-04-26 22:05:08'),(174,4,'26d0c2da3c13eb232fe5f620a1b4b686c8afde10f3f009ad644688c9ffdd8838','Generic PWA Device','2026-04-26 22:31:15','2027-04-26 22:17:16','2026-04-26 22:17:16','2026-04-26 22:31:15'),(175,11,'0b31a136ef543a31d02568d5e31f8392b0f22877c8f9b9bcc9c3e163618bcdaa','Generic PWA Device','2026-04-26 22:35:16','2027-04-26 22:31:32','2026-04-26 22:31:32','2026-04-26 22:35:16'),(176,14,'404d8c2f275a014311f339f49e4cc359b6bf2ea1e634fd267c2b1bec256f98e5','Generic PWA Device','2026-04-26 22:36:54','2027-04-26 22:35:37','2026-04-26 22:35:37','2026-04-26 22:36:54'),(177,11,'7425d021a96dab123f34adb7da61a6b181b89e61325f7761d2c405ee6123bd9c','Generic PWA Device','2026-04-26 22:46:07','2027-04-26 22:37:26','2026-04-26 22:37:26','2026-04-26 22:46:07'),(178,4,'0ced8f0c5cf519d7149015b3d60a699a68599f647e41d91b77dc28d5695f6cc5','Generic PWA Device','2026-04-26 22:54:47','2027-04-26 22:46:31','2026-04-26 22:46:31','2026-04-26 22:54:47'),(179,4,'d4b68f15d471c14e11edaa811f0a49100bead5251fdd56e7fbff8cd6d6c5323d','Generic PWA Device','2026-04-26 23:03:08','2027-04-26 23:02:07','2026-04-26 23:02:07','2026-04-26 23:03:08'),(180,11,'f71507628187ad9a23459c43c1f26c22652b9ee4f20bc7c9a9e1889525326041','Generic PWA Device','2026-04-27 06:26:53','2027-04-27 06:20:22','2026-04-27 06:20:22','2026-04-27 06:26:53'),(181,11,'ff62a8ad2e8689060db8746fb4e7371fdac09aa836573e0413b9d3fa7e7a5a6b','Generic PWA Device','2026-04-27 10:00:55','2027-04-27 09:44:07','2026-04-27 09:44:07','2026-04-27 10:00:55'),(182,4,'b5976223c230eb1849463afa2d1377b0709c564e0d14e1c339e6531c758b9c33','Generic PWA Device','2026-04-27 10:21:10','2027-04-27 10:01:10','2026-04-27 10:01:10','2026-04-27 10:21:10'),(183,4,'c5d619e890e98e2d43f0c5dee5e4cfebc91e523fba472f147adf295af38b9298','Generic PWA Device','2026-04-27 11:02:54','2027-04-27 10:44:22','2026-04-27 10:44:22','2026-04-27 11:02:54'),(184,11,'f2d1d12d8584d91a1dbde4b44c7ccc497154d6c944d9e58016d6e5d3c77260d5','Generic PWA Device','2026-04-27 11:50:02','2027-04-27 11:03:09','2026-04-27 11:03:09','2026-04-27 11:50:02'),(185,11,'5c53490a864069667107682ea442d38caad28d096401b7bd1f30eefa27ea64d4','Generic PWA Device','2026-04-27 12:11:58','2027-04-27 11:56:37','2026-04-27 11:56:37','2026-04-27 12:11:58'),(186,4,'54ef0288dfbf3add1adaad520155acb92e05c56b2ba5e4b72f3519fbaa0b4430','Generic PWA Device','2026-04-27 12:22:11','2027-04-27 12:12:11','2026-04-27 12:12:11','2026-04-27 12:22:11'),(187,11,'06ac42dd664550b05930c228cccbb2533be6f97d1e2c81d1aa750cd67453bbbf','Generic PWA Device','2026-04-27 12:24:31','2027-04-27 12:23:40','2026-04-27 12:23:40','2026-04-27 12:24:31'),(188,11,'83ab292542a246921f0175f3c7810c9fb2a056a4d7229ef0db5629eb6c274e1e','Generic PWA Device','2026-04-27 12:49:24','2027-04-27 12:46:09','2026-04-27 12:46:09','2026-04-27 12:49:24'),(189,4,'549b96b653425aa3135fabffff65e9d55e9d23883ad5b8e7aa7cf7f6733f0215','Generic PWA Device','2026-04-27 12:54:52','2027-04-27 12:51:55','2026-04-27 12:51:55','2026-04-27 12:54:52'),(190,11,'eb340349a95afc1531ef5324ce7aa6c90bf12cf6b3ecf1b1f87e08baece775d1','Generic PWA Device','2026-04-27 13:03:01','2027-04-27 12:55:08','2026-04-27 12:55:08','2026-04-27 13:03:01'),(191,14,'e7188c4572b0015cd6c14eee7188daec8dd7941c1f48d0d311e29f3f1dd32254','Generic PWA Device','2026-04-27 13:03:30','2027-04-27 13:03:28','2026-04-27 13:03:28','2026-04-27 13:03:30'),(192,4,'b9c53d02332c53d28a918a8ef074abce9ec779d71808486b59912ab310acb320','Generic PWA Device','2026-04-27 13:17:04','2027-04-27 13:11:18','2026-04-27 13:11:18','2026-04-27 13:17:04'),(193,11,'36a50b2b2ae9479a52ee1082a681ebdf0556deae0f4d42a10470d3fa8b464bcf','Generic PWA Device','2026-04-27 14:18:13','2027-04-27 13:24:36','2026-04-27 13:24:36','2026-04-27 14:18:13'),(194,11,'bc5a0ef4fb828e5c79894676bcaa3e44f23a931e53277786945c61b2721e35e0','Generic PWA Device','2026-04-27 14:27:20','2027-04-27 14:25:36','2026-04-27 14:25:36','2026-04-27 14:27:20'),(195,27,'884f7d67fda5575f61773959590c3fb04f1d7de6e88f464edc49f70ba86388ab','Generic PWA Device','2026-04-27 14:32:34','2027-04-27 14:28:33','2026-04-27 14:28:33','2026-04-27 14:32:34'),(196,4,'d8c90fcbb2a8190935eb07edf32dd496be9b3237815812c1b81ebdea3694bbae','Generic PWA Device','2026-04-27 16:37:14','2027-04-27 14:33:13','2026-04-27 14:33:13','2026-04-27 16:37:14'),(197,11,'897cf7c384592c139fafd8d2c3f6a85f2acec1393bb746c96470e26c3fb0ca2f','Generic PWA Device','2026-04-27 16:38:11','2027-04-27 16:37:31','2026-04-27 16:37:31','2026-04-27 16:38:11'),(198,11,'7e35f3151d1c3bba43948fd158989bf6b1c33cfc1afe7a7d395fa5196e63fa86','Generic PWA Device','2026-04-27 19:11:37','2027-04-27 17:54:44','2026-04-27 17:54:44','2026-04-27 19:11:37'),(199,11,'6884cb0c1b8eabc42a8c1fc5703014b2c118d6b9718f963aaf9f6c660da7975a','Generic PWA Device','2026-04-27 19:16:03','2027-04-27 19:15:36','2026-04-27 19:15:36','2026-04-27 19:16:03'),(200,11,'5e7cae479156a0bb4c6e0b37daefbb1dd1fa34af84f73f66a7a09f06ac35621a','Generic PWA Device','2026-04-27 22:15:02','2027-04-27 19:16:37','2026-04-27 19:16:37','2026-04-27 22:15:02'),(201,4,'7d56a9236a715aa6b17f876f07934033921f8188673783688ac9932043d35a07','Generic PWA Device','2026-04-27 22:48:59','2027-04-27 22:15:31','2026-04-27 22:15:31','2026-04-27 22:48:59'),(202,11,'c9f786c9035907dedd13689a992f2e0c611cd2f01f4782e9179fa53c7dc8ac73','Generic PWA Device','2026-04-27 22:55:45','2027-04-27 22:49:17','2026-04-27 22:49:17','2026-04-27 22:55:45'),(203,11,'4d95ec6559f8d586714e33ac9d0da2e532a9a61fc1347d175206760e14d9793b','Generic PWA Device','2026-04-28 17:41:55','2027-04-27 23:47:45','2026-04-27 23:47:45','2026-04-28 17:41:55');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `max_condominiums` int NOT NULL DEFAULT '1',
  `min_units` int unsigned DEFAULT '1',
  `max_units` int unsigned DEFAULT '50',
  `price_monthly` decimal(10,2) DEFAULT '0.00',
  `price_yearly` decimal(10,2) DEFAULT '0.00',
  `stripe_price_id_monthly` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `stripe_price_id_yearly` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `features` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int DEFAULT '0',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'Plan Comunidad',NULL,1,1,50,499.00,4990.00,'price_1TOkXuLwATpiMe6d8hz4mTht','price_1TOkc1LwATpiMe6dA6iOkVKu',NULL,1,1,999.00,'active','2026-03-12 03:36:16','2026-04-26 21:54:44',NULL),(2,'Plan Residencial','plan-residencial',1,51,150,899.00,8990.00,'price_1TOrK9LwATpiMe6diJp9OARN','price_1TOrKTLwATpiMe6dUxKkUsNj',NULL,1,2,0.00,'active','2026-04-26 21:55:40','2026-04-26 21:55:40',NULL),(3,'Plan Condominio','plan-condominio',1,151,450,1499.00,14990.00,'price_1TOrLaLwATpiMe6dkPqh2JmY','price_1TOrM6LwATpiMe6d6cDYTfKW',NULL,1,3,0.00,'active','2026-04-26 21:58:06','2026-04-26 21:58:06',NULL);
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_options`
--

DROP TABLE IF EXISTS `poll_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` bigint unsigned NOT NULL,
  `option_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `vote_count` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`),
  CONSTRAINT `poll_options_poll_id_foreign` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_options`
--

LOCK TABLES `poll_options` WRITE;
/*!40000 ALTER TABLE `poll_options` DISABLE KEYS */;
INSERT INTO `poll_options` VALUES (1,5,'a','2026-04-01 23:03:54','2026-04-01 23:03:54',0),(2,5,'b','2026-04-01 23:03:54','2026-04-01 23:03:54',0),(3,5,'c','2026-04-01 23:03:54','2026-04-01 23:03:54',0),(4,6,'A','2026-04-01 23:14:33','2026-04-01 23:14:33',0),(5,6,'B','2026-04-01 23:14:33','2026-04-01 23:14:33',0),(6,6,'DAS','2026-04-01 23:14:33','2026-04-01 23:14:33',0),(7,7,'13','2026-04-08 10:48:14','2026-04-08 10:48:14',0),(8,7,'as','2026-04-08 10:48:14','2026-04-08 10:48:14',0),(9,7,'v','2026-04-08 10:48:14','2026-04-08 10:48:14',0),(10,8,'a','2026-04-08 21:33:26','2026-04-08 21:33:26',0),(11,8,'b','2026-04-08 21:33:26','2026-04-08 21:33:26',0),(12,8,'c','2026-04-08 21:33:26','2026-04-08 21:33:26',0),(17,10,'a','2026-04-17 00:22:42','2026-04-17 00:22:42',0),(18,10,'b','2026-04-17 00:22:42','2026-04-17 00:22:42',1),(19,10,'c','2026-04-17 00:22:42','2026-04-17 00:22:42',0),(20,11,'A','2026-04-17 00:36:27','2026-04-17 00:36:27',0),(21,11,'B','2026-04-17 00:36:27','2026-04-17 00:36:27',0),(22,12,'A','2026-04-17 00:36:30','2026-04-17 00:36:30',0),(23,12,'B','2026-04-17 00:36:30','2026-04-17 00:36:30',0),(24,13,'A','2026-04-17 00:36:38','2026-04-17 00:36:38',0),(25,13,'B','2026-04-17 00:36:38','2026-04-17 00:36:38',1),(26,14,'a','2026-04-17 00:38:54','2026-04-17 00:38:54',0),(27,14,'b','2026-04-17 00:38:54','2026-04-17 00:38:54',1),(28,15,'a','2026-04-17 00:55:47','2026-04-17 00:55:47',1),(29,15,'b','2026-04-17 00:55:47','2026-04-17 00:55:47',0),(30,16,'1','2026-04-18 16:51:47','2026-04-18 16:51:47',1),(31,16,'2','2026-04-18 16:51:47','2026-04-18 16:51:47',0),(32,17,'A','2026-04-18 16:55:02','2026-04-18 16:55:02',1),(33,17,'B','2026-04-18 16:55:02','2026-04-18 16:55:02',0),(34,18,'a','2026-04-20 20:25:50','2026-04-20 20:25:50',0),(35,18,'b','2026-04-20 20:25:50','2026-04-20 20:25:50',2),(36,18,'c','2026-04-20 20:25:50','2026-04-20 20:25:50',1),(37,19,'a','2026-04-20 20:39:50','2026-04-20 20:39:50',1),(38,19,'b','2026-04-20 20:39:50','2026-04-20 20:39:50',0),(39,20,'a','2026-04-26 22:22:52','2026-04-26 22:22:52',2),(40,20,'b','2026-04-26 22:22:52','2026-04-26 22:22:52',0),(41,21,'a','2026-04-26 23:02:30','2026-04-26 23:02:30',2),(42,21,'b','2026-04-26 23:02:30','2026-04-26 23:02:30',0);
/*!40000 ALTER TABLE `poll_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_vote_logs`
--

DROP TABLE IF EXISTS `poll_vote_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_vote_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `previous_option_id` int unsigned NOT NULL,
  `new_option_id` int unsigned NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_vote_logs`
--

LOCK TABLES `poll_vote_logs` WRITE;
/*!40000 ALTER TABLE `poll_vote_logs` DISABLE KEYS */;
INSERT INTO `poll_vote_logs` VALUES (1,10,11,17,18,'2026-04-17 00:31:48'),(2,14,11,26,27,'2026-04-17 00:52:06'),(3,15,11,28,29,'2026-04-17 09:35:47'),(4,15,11,29,28,'2026-04-17 20:30:11'),(5,18,21,34,35,'2026-04-20 22:33:50'),(6,19,21,37,38,'2026-04-20 22:34:31'),(7,19,21,38,37,'2026-04-20 22:35:01'),(8,18,11,34,35,'2026-04-26 22:33:37'),(9,21,11,41,42,'2026-04-27 18:48:47'),(10,21,11,42,41,'2026-04-27 19:28:39');
/*!40000 ALTER TABLE `poll_vote_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_votes`
--

DROP TABLE IF EXISTS `poll_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` bigint unsigned NOT NULL,
  `option_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`),
  KEY `option_id` (`option_id`),
  CONSTRAINT `poll_votes_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `poll_votes_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `poll_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_votes`
--

LOCK TABLES `poll_votes` WRITE;
/*!40000 ALTER TABLE `poll_votes` DISABLE KEYS */;
INSERT INTO `poll_votes` VALUES (2,10,18,11,'2026-04-17 00:23:13','2026-04-17 00:23:13'),(3,14,27,11,'2026-04-17 00:44:11','2026-04-17 00:44:11'),(4,15,28,11,'2026-04-17 01:06:41','2026-04-17 01:06:41'),(5,13,25,11,'2026-04-17 10:24:21','2026-04-17 10:24:21'),(6,16,30,11,'2026-04-18 16:55:26','2026-04-18 16:55:26'),(7,17,32,11,'2026-04-18 17:02:06','2026-04-18 17:02:06'),(8,18,35,11,'2026-04-20 20:54:43','2026-04-20 20:54:43'),(9,18,35,21,'2026-04-20 22:32:50','2026-04-20 22:32:50'),(10,19,37,21,'2026-04-20 22:34:14','2026-04-20 22:34:14'),(11,20,39,4,'2026-04-26 22:28:34','2026-04-26 22:28:34'),(12,20,39,11,'2026-04-26 22:32:16','2026-04-26 22:32:16'),(13,18,36,4,'2026-04-26 22:52:26','2026-04-26 22:52:26'),(14,21,41,11,'2026-04-27 06:21:33','2026-04-27 06:21:33'),(15,21,41,4,'2026-04-27 13:15:41','2026-04-27 13:15:41');
/*!40000 ALTER TABLE `poll_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `polls` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hash_id` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `condominium_id` bigint unsigned NOT NULL,
  `title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'General',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_polls_hash_id` (`hash_id`),
  KEY `condominium_id_created_at` (`condominium_id`,`created_at`),
  CONSTRAINT `polls_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polls`
--

LOCK TABLES `polls` WRITE;
/*!40000 ALTER TABLE `polls` DISABLE KEYS */;
INSERT INTO `polls` VALUES (5,'a695055afa771b6e0c93f526',2,'as',NULL,'2026-04-01 00:00:00','2026-04-01 23:14:00',0,'2026-04-01 23:03:54','2026-04-01 23:27:35','2026-04-01 23:27:35','General'),(6,'f4b60bd00612c1d9d33811ff',2,'prUEBA 2',NULL,'2026-04-01 00:00:00','2026-04-02 00:28:52',0,'2026-04-01 23:14:33','2026-04-08 09:37:29','2026-04-08 09:37:29','General'),(7,'f0fa52e0c9e457b71a55ec89',2,'Imagen para marcas',NULL,'2026-04-08 00:00:00','2026-04-08 23:59:59',1,'2026-04-08 10:48:14','2026-04-08 19:16:19','2026-04-08 19:16:19','Eventos'),(8,'6e61951979c28a275627c505',2,'Nueva encuensta',NULL,'2026-04-08 00:00:00','2026-04-15 23:59:59',1,'2026-04-08 21:33:26','2026-04-17 00:34:40','2026-04-17 00:34:40','Eventos'),(10,'c9bad0ca63d6c37b1e877c0a',2,'Nueva encuensta \n\nDaots para encuensta \nas\ndsa\nd\nsad\nsad\n asd sad',NULL,'2026-04-17 00:00:00','2026-04-17 00:34:56',0,'2026-04-17 00:22:42','2026-04-17 00:34:56',NULL,'General'),(11,'5d38746ff7a73898b6ba71c2',2,'nUEVA DANIEL',NULL,'2026-04-17 00:00:00','2026-04-24 23:59:59',1,'2026-04-17 00:36:27','2026-04-17 00:38:22','2026-04-17 00:38:22','General'),(12,'7729d59fdfe8a041de1442ca',2,'nUEVA DANIEL',NULL,'2026-04-17 00:00:00','2026-04-24 23:59:59',1,'2026-04-17 00:36:30','2026-04-17 00:38:28','2026-04-17 00:38:28','General'),(13,'aa73b197bcd298270d940100',2,'nUEVA DANIEL',NULL,'2026-04-17 00:00:00','2026-04-24 23:59:59',1,'2026-04-17 00:36:38','2026-04-18 15:53:11','2026-04-18 15:53:11','General'),(14,'68389c8ddfae92bb628fdbfa',2,'nueva 3',NULL,'2026-04-17 00:00:00','2026-04-24 23:59:59',1,'2026-04-17 00:38:54','2026-04-18 15:53:05','2026-04-18 15:53:05','General'),(15,'f77490ba8a66025663dd6fec',2,'otra encuesta de prueba',NULL,'2026-04-17 00:00:00','2026-04-17 23:59:59',1,'2026-04-17 00:55:47',NULL,NULL,'Reglas'),(16,'44f6563dcef0340ed0cdfd53',2,'Junta Administrativa',NULL,'2026-04-18 00:00:00','2026-04-18 23:59:59',1,'2026-04-18 16:51:47',NULL,NULL,'Finanzas'),(17,'19ceea73ce9252471e34505b',2,'cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDINIA SD cUANDOS E HARA LA JUNTA JASJ KDE LA PESA AMDIN',NULL,'2026-04-18 00:00:00','2026-04-25 23:59:59',1,'2026-04-18 16:55:02','2026-04-20 19:45:24','2026-04-20 19:45:24','General'),(18,'27b3b023879a62c675b8f25d',2,'Opcines',NULL,'2026-04-20 00:00:00','2026-04-27 23:59:59',1,'2026-04-20 20:25:50','2026-04-26 22:52:34','2026-04-26 22:52:34','General'),(19,'ef7126efd6de2d93512e4b23',5,'Aopciones',NULL,'2026-04-20 00:00:00','2026-04-27 23:59:59',1,'2026-04-20 20:39:50','2026-04-26 22:47:58','2026-04-26 22:47:58','General'),(20,'541549db4a0f5ee19bd83ee7',2,'colores',NULL,'2026-04-26 22:22:52','2026-05-28 23:59:00',1,'2026-04-26 22:22:52','2026-04-26 22:53:50','2026-04-26 22:53:50','General'),(21,'f458ab2cfdc39a8da9b805f6',2,'perros',NULL,'2026-04-26 23:02:30','2026-04-28 23:59:00',1,'2026-04-26 23:02:30',NULL,NULL,'General');
/*!40000 ALTER TABLE `polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_codes`
--

DROP TABLE IF EXISTS `qr_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qr_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `visitor_id` bigint unsigned DEFAULT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `visitor_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `valid_from` datetime NOT NULL,
  `valid_until` datetime NOT NULL,
  `usage_limit` int NOT NULL DEFAULT '1',
  `times_used` int NOT NULL DEFAULT '0',
  `status` enum('active','expired','revoked','renovado','used') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `visit_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vehicle_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `vehicle_plate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `qr_codes_unit_id_foreign` (`unit_id`),
  KEY `qr_codes_created_by_foreign` (`created_by`),
  KEY `qr_codes_visitor_id_foreign` (`visitor_id`),
  KEY `condominium_id_valid_from` (`condominium_id`,`valid_from`),
  CONSTRAINT `qr_codes_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `qr_codes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `qr_codes_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `qr_codes_visitor_id_foreign` FOREIGN KEY (`visitor_id`) REFERENCES `visitors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_codes`
--

LOCK TABLES `qr_codes` WRITE;
/*!40000 ALTER TABLE `qr_codes` DISABLE KEYS */;
INSERT INTO `qr_codes` VALUES (8,2,296,1,NULL,'4d59c046887e0dd3761d8b1520bbb678','pai','2026-03-27 00:00:00','2026-03-27 23:59:59',1,0,'expired','2026-03-28 00:41:25','2026-03-28 00:46:24','Amigo','Auto',NULL),(9,2,297,1,NULL,'09a379bc1f3fcbfec1a07fc5e94b9944','ta','2026-03-27 00:00:00','2026-03-27 23:59:59',1,0,'expired','2026-03-28 00:47:07','2026-03-28 00:47:38','Amigo','Auto',NULL),(10,2,297,1,NULL,'9e8a7c87b6661ba9a8ec4299fca1cbe0','tae','2026-03-27 00:00:00','2026-03-27 23:59:59',1,0,'revoked','2026-03-28 01:20:21','2026-03-28 18:31:33','Amigo','Auto',NULL),(11,2,296,4,NULL,'03de940270a008a158445fe6dd9adbb9','DANIEL PRUEBA TEMPORAL ','2026-03-28 00:00:00','2026-03-30 23:59:59',999,0,'active','2026-03-28 12:59:57','2026-03-28 12:59:57','Amigo','Auto',NULL),(12,2,296,1,NULL,'fcf4a8b8a577010fa8cb51b47c1cd807','NIKA','2026-03-30 00:00:00','2026-03-30 23:59:59',1,0,'active','2026-03-30 01:01:12','2026-03-30 01:01:12','Amigo','Auto','NO'),(13,2,296,1,NULL,'b787d60eea4e537bf3342a1b1e0d7dec','FRODO','2026-03-30 00:00:00','2026-03-30 23:59:59',1,0,'revoked','2026-03-30 14:11:34','2026-03-30 15:07:28','Amigo','Auto',NULL),(14,2,296,1,NULL,'2435e8c50d7306cbaba4902c71540673','artur','2026-03-31 00:00:00','2026-03-31 23:59:59',1,0,'active','2026-03-31 00:27:20','2026-03-31 00:27:20','Amigo','Auto',NULL),(15,2,296,1,NULL,'e503e31e6373f8de4ac20394823b89d2','ARTURO','2026-04-01 00:00:00','2026-04-01 23:59:59',1,0,'active','2026-04-01 16:16:16','2026-04-01 16:16:16','Amigo','Auto',NULL),(16,2,296,1,NULL,'fe279074848b4dce01b031e53e9b532d','Test Toast Visitante','2026-04-01 00:00:00','2026-04-01 23:59:59',1,0,'active','2026-04-01 16:26:25','2026-04-01 16:26:25','Familia','Sin vehículo',NULL),(17,2,297,1,NULL,'3e20e401f57c9cf71f6ba9e5f4d91807','Test Toast Visitante 2','2026-04-01 00:00:00','2026-04-01 23:59:59',1,0,'active','2026-04-01 16:27:17','2026-04-01 16:27:17','Familia','Sin vehículo',NULL),(18,2,296,1,NULL,'ebd178fdcfcb0a5499c4e1cd068ce1b0','ARTURO','2026-04-01 00:00:00','2026-04-03 23:59:59',999,0,'renovado','2026-04-01 16:30:59','2026-04-02 01:12:01','Amigo','Motocicleta',NULL),(19,2,296,1,NULL,'bd1c11b5945862a70e052fa4b046c437','tat','2026-04-01 00:00:00','2026-04-01 23:59:59',1,0,'revoked','2026-04-01 20:32:22','2026-04-01 20:59:10','Familia','Auto',NULL),(20,2,297,4,NULL,'8d86be34ac253ea637c40243f151202f','Arturo','2026-04-09 00:00:00','2026-04-09 23:59:59',1,0,'used','2026-04-09 11:38:20','2026-04-09 22:12:38','Amigo','Auto',NULL),(21,2,419,4,NULL,'527eb0ecc25df32079a0f945a13814d8','ANGELES','2026-04-09 00:00:00','2026-04-09 23:59:59',1,0,'revoked','2026-04-09 20:28:11','2026-04-09 21:33:27','Amigo','Auto',NULL),(22,2,296,4,NULL,'533d65473730d16db771675d9991fbd3','DANIEL QR TEMPORAL','2026-04-10 00:00:00','2026-04-10 23:59:59',999,0,'used','2026-04-10 08:43:20','2026-04-10 08:46:04','Familia','Auto',NULL),(23,2,296,4,NULL,'689b9e4b042e0320ae8421e8903db2d4','MAÑANA','2026-04-11 00:00:00','2026-04-11 23:59:59',1,0,'renovado','2026-04-10 08:47:29','2026-04-10 08:47:37','Familia','Sin vehículo',NULL),(24,2,419,4,NULL,'ad77ee09293e5c4b8955c9188794efb8','memo','2026-04-10 00:00:00','2026-04-10 23:59:59',1,0,'used','2026-04-10 08:52:23','2026-04-10 09:02:00','Amigo','Sin vehículo',NULL),(25,2,296,4,NULL,'40692ea542c9500767b42a5e8df6bf79','DANO','2026-04-10 00:00:00','2026-04-10 23:59:59',999,0,'renovado','2026-04-10 09:03:01','2026-04-10 15:43:32','Familia','Auto',NULL),(26,2,296,4,NULL,'314a7711d9403e90fa18dc9435cf0f40','mina','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'used','2026-04-12 16:42:54','2026-04-12 22:25:13','Amigo','Auto',NULL),(27,2,296,11,NULL,'3b07b4404aba1c2ed9775c644f9e76e3','pqci','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'revoked','2026-04-12 20:57:52','2026-04-12 21:11:43','Amigo','car',NULL),(28,2,296,11,NULL,'b57b800d2ca1250858b1026dfe80ca77','Felipe','2026-04-12 00:00:00','2026-04-19 23:59:59',999,0,'revoked','2026-04-12 21:07:12','2026-04-12 21:11:48','Familia','car',NULL),(29,2,296,11,NULL,'4454692bf8dc1c75e1466341e50fe53f','paco y','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'revoked','2026-04-12 21:10:20','2026-04-12 21:10:29','Familia','car',NULL),(30,2,296,11,NULL,'e9f1f3490082a2ba4c1b97d39fda7ab7','Arturo','2026-04-12 00:00:00','2026-04-19 23:59:59',999,0,'revoked','2026-04-12 21:13:37','2026-04-12 21:24:46','Familia','car',NULL),(31,2,296,11,NULL,'f74c79dc732506aa7a32969222c178c4','mari','2026-04-12 00:00:00','2026-04-12 23:59:59',999,0,'revoked','2026-04-12 21:16:58','2026-04-12 21:44:59','Entrega de comida','motorcycle',NULL),(32,2,296,11,NULL,'5c22dae4fa968d794b2d6159d302ec1f','Pepe','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'revoked','2026-04-12 21:25:06','2026-04-12 21:45:04','Amigo','car',NULL),(33,2,296,11,NULL,'0e698b5c40eb220a8b3dc57613f27dca','Mario','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'revoked','2026-04-12 21:26:23','2026-04-12 21:47:27','Amigo','car',NULL),(34,2,296,11,NULL,'06539365e370529c33a46e980176dfcd','pau','2026-04-12 00:00:00','2026-04-19 23:59:59',999,0,'revoked','2026-04-12 21:28:06','2026-04-12 21:44:48','Familia','car',NULL),(35,2,296,11,NULL,'b10a34a8e68ffc427b4d7c9be03bd5cc','terry','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'revoked','2026-04-12 21:42:09','2026-04-12 21:48:15','Familia','car',NULL),(36,2,296,11,NULL,'ffab3977bbaee4f8fa9a8ab238042b75','temporal','2026-04-12 00:00:00','2026-04-13 23:59:59',999,0,'revoked','2026-04-12 21:45:20','2026-04-12 21:45:29','Amigo','car',NULL),(37,2,296,11,NULL,'aca66b53f2021dcc749668fc5b306423','pepe','2026-04-12 00:00:00','2026-04-13 23:59:59',999,0,'revoked','2026-04-12 21:50:48','2026-04-12 21:52:25','Familia','car',NULL),(38,2,296,11,NULL,'e646bc0c273793651cf254805197c2eb','una','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'used','2026-04-12 21:51:41','2026-04-12 22:38:11','Amigo','motorcycle',NULL),(39,2,296,11,NULL,'3a4e1b5ac95bf4904eef4e2d62c592ad','temp','2026-04-12 00:00:00','2026-04-13 23:59:59',999,0,'revoked','2026-04-12 21:53:28','2026-04-12 21:54:30','Familia','car',NULL),(40,2,296,11,NULL,'d482b94afa2d4330bcfc174f48c4bdbd','trmp','2026-04-12 00:00:00','2026-04-13 23:59:59',999,0,'revoked','2026-04-12 21:54:53','2026-04-12 21:57:54','Amigo','car',NULL),(41,2,296,11,NULL,'6b5df44ba77519adf6f150c10dcc8656','tempo','2026-04-12 00:00:00','2026-04-13 23:59:59',999,0,'revoked','2026-04-12 21:58:08','2026-04-12 22:02:18','Amigo','car',NULL),(42,2,296,11,NULL,'e4cc84239a2de61c707b4e0729ecee0f','ubo','2026-04-12 00:00:00','2026-04-12 23:59:59',999,0,'renovado','2026-04-12 22:12:48','2026-04-12 22:25:43','Amigo','car',NULL),(43,2,296,11,NULL,'3a80f1dbe80611644a14ca9943076b97','temporal','2026-04-12 00:00:00','2026-04-13 23:59:59',999,0,'active','2026-04-12 22:15:01','2026-04-12 22:15:01','Amigo','car',NULL),(44,2,296,11,NULL,'df32d5043e45ed2bf0e8d38eb4158f3b','angeles López','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'used','2026-04-12 22:18:15','2026-04-13 00:13:02','Familia','car',NULL),(45,2,296,11,NULL,'504d80a22ce122026eaf7d756dcd5397','zubiri','2026-04-12 00:00:00','2026-04-12 23:59:59',1,0,'used','2026-04-12 22:49:57','2026-04-12 23:55:36','Amigo','car',NULL),(46,2,296,11,NULL,'0730d6b749f213fcb3bf623104a38747','pau','2026-04-13 00:00:00','2026-04-13 23:59:59',1,0,'active','2026-04-13 11:02:35','2026-04-13 11:02:35','Familia','car',NULL),(47,2,296,11,NULL,'bc5de6b3fb4024b627260e7c4f0573d2','paco','2026-04-13 00:00:00','2026-04-13 23:59:59',1,0,'active','2026-04-13 21:04:44','2026-04-13 21:04:44','Amigo','car',NULL),(48,2,296,11,NULL,'b44e589d76e01007821cf7cab4e1501c','nika','2026-04-13 00:00:00','2026-04-13 23:59:59',1,0,'active','2026-04-13 21:10:57','2026-04-13 21:10:57','Amigo','car',NULL),(49,2,296,11,NULL,'cd873aee9b29dbd19419b84f05381d04','etja','2026-04-13 00:00:00','2026-04-13 23:59:59',1,0,'active','2026-04-13 21:19:53','2026-04-13 21:19:53','Amigo','car',NULL),(50,2,296,11,NULL,'cb63ded890aacd18c3ffb5ee52a4df7a','pauo','2026-04-13 00:00:00','2026-04-13 23:59:59',1,0,'active','2026-04-13 22:13:47','2026-04-13 22:13:47','Familia','car',NULL),(51,2,296,11,NULL,'ec0a0df5268b01a8598a2461d24b7e5f','pilo','2026-04-13 00:00:00','2026-04-13 23:59:59',1,0,'active','2026-04-13 22:50:49','2026-04-13 22:50:49','Familia','car',NULL),(52,2,296,11,NULL,'0fcb4131d3061869a4e5e7f6f521bd42','pqci','2026-04-14 00:00:00','2026-04-15 23:59:59',999,0,'revoked','2026-04-14 18:30:42','2026-04-15 21:34:58','Proveedor de servicios','car',NULL),(53,2,296,11,NULL,'736791aa5edbd2a69a1b509ce5435a65','silok','2026-04-14 00:00:00','2026-04-14 23:59:59',1,0,'active','2026-04-14 19:55:00','2026-04-14 19:55:00','Familia','car',NULL),(54,2,296,11,NULL,'da6da63f1dbeb4a20d8e4a5cc8fd6b0c','Derek','2026-04-14 00:00:00','2026-04-14 23:59:59',1,0,'used','2026-04-14 20:05:36','2026-04-14 21:19:25','Familia','car',NULL),(55,2,296,11,NULL,'3636dbf51b2ad3dfe2d2a4b1cc740eea','mauo','2026-04-15 00:00:00','2026-04-15 23:59:59',1,0,'active','2026-04-15 02:30:46','2026-04-15 02:30:46','Familia','car',NULL),(56,2,296,11,NULL,'455752d44e0c7145720ae49bff44eeb8','memo','2026-04-15 00:00:00','2026-04-15 23:59:59',1,0,'active','2026-04-15 21:15:37','2026-04-15 21:15:37','Empleado','car',NULL),(57,2,421,10,NULL,'68f641b0022af43da7b929e24d900056','paco angeles','2026-04-16 00:00:00','2026-04-16 23:59:59',1,0,'active','2026-04-16 12:37:03','2026-04-16 12:37:03','Familia','car',NULL),(58,2,296,11,NULL,'05b55cb4523a9511b56f68b3edaddc9a','mauro','2026-04-16 00:00:00','2026-04-16 23:59:59',1,0,'active','2026-04-16 13:53:30','2026-04-16 13:53:30','Amigo','car',NULL),(59,2,296,11,NULL,'e35cc9827bfc4f7119dc41a9ad3090bc','dulce','2026-04-17 00:00:00','2026-04-17 23:59:59',1,0,'used','2026-04-17 08:41:15','2026-04-17 12:25:12','Familia','car',NULL),(60,2,296,4,NULL,'e447475d31b373a57c1ff7ed3cef182b','DENISE','2026-04-17 00:00:00','2026-04-17 23:59:59',1,0,'used','2026-04-17 12:57:27','2026-04-17 13:10:52','Amigo','Sin vehículo',NULL),(61,2,296,4,NULL,'8522301a44166ab9a35c4157b2a440b8','PEPELOBO','2026-04-17 00:00:00','2026-04-17 23:59:59',1,0,'used','2026-04-17 13:18:17','2026-04-17 13:22:07','Empleado','Auto',NULL),(62,2,296,11,NULL,'7d3e3491cdc971af6081589d84a272f4','MARIA DE LOD ANGELES','2026-04-17 00:00:00','2026-04-17 23:59:59',1,0,'used','2026-04-17 15:53:49','2026-04-17 22:13:46','Amigo','car',NULL),(63,2,296,11,NULL,'332e8dd0f5f299b310208faa1cf46714','Ethan','2026-04-17 00:00:00','2026-04-17 23:59:59',1,0,'active','2026-04-17 20:10:33','2026-04-17 20:10:33','Amigo','car',NULL),(64,2,296,11,NULL,'3a8692a73011073492aaeabe6abd2c59','saul','2026-04-18 00:00:00','2026-04-18 23:59:59',1,0,'used','2026-04-18 13:12:59','2026-04-20 20:48:07','Proveedor de servicios','car',NULL),(65,2,296,11,NULL,'2cdc6aee2f59c4cbae13dee318d67be4','wakanda','2026-04-19 00:00:00','2026-04-19 23:59:59',1,0,'active','2026-04-19 13:25:48','2026-04-19 13:25:48','Familia','car',NULL),(66,2,296,11,NULL,'ed54b9128c7a3964d2011215dc9dd73a','helod','2026-04-20 00:00:00','2026-04-20 23:59:59',1,0,'active','2026-04-20 20:07:49','2026-04-20 20:07:49','Familia','car',NULL),(67,5,465,4,NULL,'7ec9309da3877f3249c5bbdecb071d46','puty','2026-04-20 00:00:00','2026-04-20 23:59:59',1,0,'active','2026-04-20 20:47:49','2026-04-20 20:47:49','Amigo','Sin vehículo',NULL),(68,2,296,11,NULL,'9d3a5b9697f4efe77772d0ad00208aee','paco','2026-04-26 00:00:00','2026-04-26 23:59:59',1,0,'used','2026-04-26 22:35:08','2026-04-26 22:36:51','Familia','car',NULL),(69,2,296,11,NULL,'42e98b4cf8fe64bdbc64c06157d27e72','pqci','2026-04-27 00:00:00','2026-04-28 23:59:59',999,0,'revoked','2026-04-27 09:44:46','2026-04-27 13:01:05','Familia','car',NULL),(70,2,296,11,NULL,'a081b117c0532d018efc072a57f68cdc','clara','2026-04-27 00:00:00','2026-04-27 23:59:59',999,0,'active','2026-04-27 13:33:01','2026-04-27 13:33:01','Amigo','motorcycle',NULL),(71,8,480,4,NULL,'f5387a5a52c489719a81b3694cf6b545','PAOC','2026-04-27 00:00:00','2026-04-27 23:59:59',1,0,'used','2026-04-27 14:28:56','2026-04-27 14:31:43','Amigo','Sin vehículo',NULL);
/*!40000 ALTER TABLE `qr_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resident_invitations`
--

DROP TABLE IF EXISTS `resident_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resident_invitations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `invitation_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `invited_by` bigint unsigned DEFAULT NULL,
  `invited_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `resident_invitations_unit_id_foreign` (`unit_id`),
  KEY `resident_invitations_invited_by_foreign` (`invited_by`),
  KEY `idx_condo_email` (`condominium_id`,`email`),
  KEY `idx_token` (`token`),
  KEY `idx_status` (`invitation_status`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `resident_invitations_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `resident_invitations_invited_by_foreign` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `resident_invitations_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resident_invitations`
--

LOCK TABLES `resident_invitations` WRITE;
/*!40000 ALTER TABLE `resident_invitations` DISABLE KEYS */;
INSERT INTO `resident_invitations` VALUES (1,2,296,'ethan@gmail.com','ethan',NULL,'owner','71f6a802885a683a2c5079af79e5b4f7f13554d05449573c92dbe78bb42822dd','accepted',1,'2026-03-13 01:37:49','2026-03-13 01:49:50','2026-03-20 01:37:49','2026-03-13 01:37:49','2026-03-13 01:37:49'),(2,2,296,'angeles@gmail.com','Angeles Lopez',NULL,'owner','a311380071521c20525f0d3b6d90a4b14e0c88877642fa1b72efd5264923b6e1','accepted',1,'2026-03-13 02:28:01','2026-03-13 02:28:39','2026-03-20 02:28:01','2026-03-13 02:28:01','2026-03-13 02:28:01'),(5,2,NULL,'benji@gmail.com','benjamin lopez',NULL,'owner','2dd733817da66a0096eb362d548a7e8db2d30e40124caea8c1215f30e20b81df','accepted',1,'2026-03-13 04:42:00','2026-03-13 04:50:55','2026-03-20 04:42:00','2026-03-13 04:42:00','2026-03-13 04:42:00'),(8,2,297,'ethan@gmail.com','ethan',NULL,'owner','1fd10c9724372ca00b4c02133c44800cd0f236bca5c1eecb0410be06136bc16d','accepted',1,'2026-04-08 15:31:00','2026-04-09 11:26:51','2026-04-15 15:31:00','2026-04-08 15:31:00','2026-04-08 15:31:00'),(9,2,419,'araceli@gmail.com','araceli',NULL,'owner','252b1216d3671275036eeb67cf2a9c68daf9f949da500aee5cceb12f521af03b','expired',1,'2026-04-08 15:31:00',NULL,'2026-04-15 15:31:00','2026-04-08 15:31:00','2026-04-20 23:23:44'),(10,5,456,'acuellar@gmai.com','Antonio Cuellas',NULL,'owner','fb0684d2c268e1ffa33e64212159a9682b5f05fe5307fe7c060e0fa300841eed','accepted',1,'2026-04-20 22:12:23','2026-04-20 22:17:37','2026-04-27 22:12:23','2026-04-20 22:12:23','2026-04-20 22:12:23'),(11,2,297,'acuellar@gmai.com','Atonio Cuellar',NULL,'owner','238465e7fc189e74f6610f09a2af60af5ef7f463c2801dd7c642a89071bc2202','accepted',1,'2026-04-20 22:22:21','2026-04-20 22:22:51','2026-04-27 22:22:21','2026-04-20 22:22:21','2026-04-20 22:22:21'),(12,5,456,'acuellar@gmai.com','Antonio Cuellar',NULL,'owner','8a6503f58b608e6870314908de20119084b404e3b1905a98ad47166d5ee1a02e','accepted',1,'2026-04-20 22:48:42','2026-04-20 22:49:04','2026-04-27 22:48:42','2026-04-20 22:48:42','2026-04-20 22:48:42'),(13,2,420,'araceli@gmail.com','Araceli',NULL,'owner','9f319ec3ac4301d1cdf4eefda7c3e59af66185b4f0c8b24738538b18f2a5271c','accepted',1,'2026-04-20 23:24:39','2026-04-20 23:25:21','2026-04-27 23:24:39','2026-04-20 23:24:39','2026-04-20 23:24:39'),(14,2,419,'araceli@gmail.com','Aracelo',NULL,'owner','a710d195bf4b95c865c1d76d9a291c79058c49f6c5460990574e9becaf9d500c','accepted',1,'2026-04-20 23:39:35','2026-04-20 23:40:05','2026-04-27 23:39:35','2026-04-20 23:39:35','2026-04-20 23:39:35'),(15,2,419,'areceli@gmail.com','ARACELI',NULL,'owner','03f52cf562c20fd26c3bad6ec73113560c14e91880fc55e8be10837b7d8d6f80','accepted',1,'2026-04-20 23:55:41','2026-04-20 23:57:02','2026-04-27 23:55:41','2026-04-20 23:55:41','2026-04-20 23:55:41'),(16,2,420,'daniel@dani.com','danielo',NULL,'owner','eabe0efd62c62618ba4624a8db243554258208d2b2909d71d09b8d2ba0b7f77a','accepted',1,'2026-04-20 23:59:25','2026-04-20 23:59:54','2026-04-27 23:59:25','2026-04-20 23:59:25','2026-04-20 23:59:25');
/*!40000 ALTER TABLE `resident_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `residents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `type` enum('owner','tenant') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'owner',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `residents_user_id_foreign` (`user_id`),
  KEY `condominium_id_user_id` (`condominium_id`,`user_id`),
  KEY `condominium_id_unit_id` (`condominium_id`,`unit_id`),
  KEY `residents_unit_id_foreign` (`unit_id`),
  CONSTRAINT `residents_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `residents_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `residents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residents`
--

LOCK TABLES `residents` WRITE;
/*!40000 ALTER TABLE `residents` DISABLE KEYS */;
INSERT INTO `residents` VALUES (109,2,11,296,'owner',1,NULL,'2026-04-16 12:42:18'),(116,2,23,419,'owner',1,NULL,NULL);
/*!40000 ALTER TABLE `residents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id_permission_id` (`role_id`,`permission_id`),
  KEY `role_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'SUPER_ADMIN','Dueño del SaaS','2026-03-11 18:19:57','2026-03-11 18:19:57'),(2,'ADMIN','Administrador de un Condominio (Tenant)','2026-03-11 18:19:57','2026-03-11 18:19:57'),(3,'SECURITY','Guardia de Caseta','2026-03-11 18:19:57','2026-03-11 18:19:57'),(4,'RESIDENT','Condómino / Habitante de Unidad','2026-03-11 18:19:57','2026-03-11 18:19:57');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saas_payments`
--

DROP TABLE IF EXISTS `saas_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saas_payments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` int unsigned NOT NULL,
  `plan_id` int unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_type` enum('cash','transfer','deposit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'transfer',
  `reference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'monthly',
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `recorded_by` int unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id` (`condominium_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saas_payments`
--

LOCK TABLES `saas_payments` WRITE;
/*!40000 ALTER TABLE `saas_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `saas_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id` (`condominium_id`),
  CONSTRAINT `sections_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,2,'Torre A','2026-03-11 22:33:34','2026-04-08 19:43:07'),(2,2,'Torre B','2026-03-11 22:33:34','2026-03-11 22:33:34'),(3,2,'Torre C','2026-03-11 22:33:34','2026-03-11 22:33:34'),(5,5,'TORRE A','2026-04-20 22:06:35','2026-04-20 22:06:35'),(6,5,'TORRE B','2026-04-20 22:06:48','2026-04-20 22:06:48');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_members`
--

DROP TABLE IF EXISTS `staff_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_members` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` int unsigned NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `staff_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'security' COMMENT 'security, maintenance, other',
  `device_id` int unsigned DEFAULT NULL COMMENT 'Optional link to security device credentials',
  `photo_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_document_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id` (`condominium_id`),
  KEY `staff_type` (`staff_type`),
  KEY `device_id` (`device_id`),
  KEY `deleted_at` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_members`
--

LOCK TABLES `staff_members` WRITE;
/*!40000 ALTER TABLE `staff_members` DISABLE KEYS */;
INSERT INTO `staff_members` VALUES (1,2,'Daniel','Sosa','security',2,'writable/uploads/staff/staff_1775503737_a6ddd3e1.jpg',NULL,'active','2026-04-06 12:56:16','2026-04-06 13:28:57',NULL),(2,2,'Marie','Popis','maintenance',NULL,'writable/uploads/staff/staff_1775504171_5f73ba47.jpg',NULL,'active','2026-04-06 13:21:33','2026-04-06 13:36:11',NULL);
/*!40000 ALTER TABLE `staff_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `starts_at` date NOT NULL,
  `expires_at` date DEFAULT NULL,
  `status` enum('active','expired','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_plan_id_foreign` (`plan_id`),
  KEY `user_id_status` (`user_id`,`status`),
  KEY `expires_at` (`expires_at`),
  CONSTRAINT `subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,4,1,'2026-03-12','2027-03-12','active','2026-03-12 03:36:16','2026-03-12 03:36:16'),(2,8,1,'2026-03-13','2026-04-12','active','2026-03-13 00:57:50','2026-03-13 00:57:50'),(3,19,1,'2026-04-12','2026-05-12','active','2026-04-12 13:57:27','2026-04-12 13:57:27'),(4,4,1,'2026-04-20','2027-04-20','active','2026-04-20 20:02:49','2026-04-20 20:02:49'),(5,4,1,'2026-04-20','2027-04-20','active','2026-04-20 20:29:44','2026-04-20 20:29:44'),(6,26,1,'2026-04-26','2026-05-11','active','2026-04-26 23:12:42','2026-04-26 23:12:42'),(7,4,1,'2026-04-27','2026-05-12','active','2026-04-27 13:07:13','2026-04-27 13:07:13');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_documents`
--

DROP TABLE IF EXISTS `tenant_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `type` enum('file','folder') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'file',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `access_level` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Todos',
  `size_bytes` bigint unsigned DEFAULT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `hash_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash_id` (`hash_id`),
  KEY `tenant_documents_uploaded_by_foreign` (`uploaded_by`),
  KEY `condominium_id` (`condominium_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `tenant_documents_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tenant_documents_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_documents`
--

LOCK TABLES `tenant_documents` WRITE;
/*!40000 ALTER TABLE `tenant_documents` DISABLE KEYS */;
INSERT INTO `tenant_documents` VALUES (1,2,NULL,'folder','Test',NULL,NULL,'Solo Admins',NULL,NULL,4,'2026-04-06 20:12:09','2026-04-06 20:12:09',NULL,0,'16280a2fc812a52fc8f61ac0'),(2,2,NULL,'file','DIbujos','1775528050_50ea971f50969339c70e.pdf','Financiero','Todos',112767,'application/pdf',4,'2026-04-06 20:14:10','2026-04-16 20:51:02','2026-04-16 20:51:02',1,'1c7424e0fac7feda887ee416'),(3,2,NULL,'folder','Test4',NULL,NULL,'Solo Admins',NULL,NULL,4,'2026-04-06 20:45:49','2026-04-16 20:51:36','2026-04-16 20:51:36',0,'b79db45681c9f29f18b2a7ac'),(4,2,1,'file','Dibujo1.pdf','1775532527_8e36006d36aa73cf89e6.pdf','Legal y Contratos','Propietarios',112767,'application/pdf',4,'2026-04-06 21:28:47','2026-04-16 20:54:57',NULL,1,'bf8040365ccbab8b4da5e83d'),(5,2,NULL,'file','ETIQUETAS TAMBOS_2025.pdf','1775532527_281cfde8973544f40fd5.pdf','Legal y Contratos','Propietarios',174726,'application/pdf',4,'2026-04-06 21:28:47','2026-04-06 21:29:14','2026-04-06 21:29:14',0,'a7fdd47e41c756a08e90d2bf'),(6,2,NULL,'folder','Nueva',NULL,NULL,'Solo Admins',NULL,NULL,4,'2026-04-08 20:45:10','2026-04-16 20:51:31','2026-04-16 20:51:31',0,'994256ce02eacb144fc01119'),(7,2,NULL,'folder','HashTest',NULL,NULL,'Solo Admins',NULL,NULL,4,'2026-04-11 01:30:48','2026-04-16 20:51:25','2026-04-16 20:51:25',0,'28a586393fb8afc592695033'),(8,2,NULL,'folder','Ok',NULL,NULL,'Solo Admins',NULL,NULL,4,'2026-04-16 20:26:32','2026-04-16 20:26:32',NULL,0,'85898bf9067776589ee1bd65'),(9,2,1,'file','recortes.pdf','1776392840_c68fb027ae1b1595ea75.pdf','General','Solo Admins',174362,'application/pdf',4,'2026-04-16 20:27:20','2026-04-16 20:55:02',NULL,0,'b8c89d6adc2641d9ee27b4ba'),(10,2,NULL,'file','COTIZACION-COT-KLN--2.pdf','1776394159_1be9c202a31cf7e99760.pdf','Mantenimiento','Propietarios',400882,'application/pdf',4,'2026-04-16 20:49:19','2026-04-16 20:49:19',NULL,0,'853f4723ac5b299753fbe9dd'),(11,2,1,'file','ARCHIVO NUEVO TODOS.pdf','1776394458_a776f234cdddadec2803.pdf','Mantenimiento','Propietarios',116395,'application/pdf',4,'2026-04-16 20:54:18','2026-04-16 20:54:46',NULL,0,'4c4eef654e3cb58c3a643769'),(12,2,NULL,'file','IMG-20260408-WA0016.jpg','1777351715_7f266d9885dc495caaca.jpg','General','Todos',27000,'image/jpeg',4,'2026-04-27 22:48:35','2026-04-27 22:48:35',NULL,0,'9876ac2fdb5cd184bacb19ba');
/*!40000 ALTER TABLE `tenant_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_comments`
--

DROP TABLE IF EXISTS `ticket_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `condominium_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` enum('reply','internal') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'reply',
  `media_urls` json DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_comments_user_id_foreign` (`user_id`),
  KEY `ticket_id_type` (`ticket_id`,`type`),
  KEY `condominium_id` (`condominium_id`),
  CONSTRAINT `ticket_comments_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_comments`
--

LOCK TABLES `ticket_comments` WRITE;
/*!40000 ALTER TABLE `ticket_comments` DISABLE KEYS */;
INSERT INTO `ticket_comments` VALUES (1,1,2,1,'Estimado residente, estamos investigando su problema y le mantendremos informado.','reply',NULL,'2026-04-06 16:22:32','2026-04-06 16:22:32',NULL),(2,1,2,1,'Revisando internamente','internal',NULL,'2026-04-06 16:22:57','2026-04-06 16:22:57',NULL),(3,1,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-06 16:25:26','2026-04-06 16:25:26',NULL),(4,1,2,4,'oK REVISANDO','internal',NULL,'2026-04-06 16:25:34','2026-04-06 16:25:34',NULL),(5,1,2,4,'','reply','[\"writable/uploads/tickets/msg_1775514342_5365f24b.jpg\"]','2026-04-06 16:25:42','2026-04-06 16:25:42',NULL),(6,3,2,4,'H','reply',NULL,'2026-04-06 16:42:45','2026-04-06 16:42:45',NULL),(7,3,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-06 16:44:21','2026-04-06 16:44:21',NULL),(8,3,2,1,'Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','reply',NULL,'2026-04-06 16:57:57','2026-04-06 16:57:57',NULL),(9,3,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply',NULL,'2026-04-06 17:42:46','2026-04-06 17:42:46',NULL),(10,3,2,4,'','reply','[\"writable/uploads/tickets/msg_1775518982_722d2923.jpg\", \"writable/uploads/tickets/msg_1775518982_bbc4ca62.jpg\"]','2026-04-06 17:43:02','2026-04-06 17:43:02',NULL),(11,4,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-06 19:23:48','2026-04-06 19:23:48',NULL),(12,2,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-06 21:25:56','2026-04-06 21:25:56',NULL),(13,2,2,1,'Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','reply',NULL,'2026-04-07 09:00:56','2026-04-07 09:00:56',NULL),(14,5,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply',NULL,'2026-04-09 01:00:30','2026-04-09 01:00:30',NULL),(15,5,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply',NULL,'2026-04-09 02:16:32','2026-04-09 02:16:32',NULL),(16,5,2,4,'','reply','[\"writable/uploads/tickets/msg_1775722752_f6f92078.jpg\"]','2026-04-09 02:19:12','2026-04-09 02:19:12',NULL),(17,4,2,4,'','reply','[\"writable/uploads/tickets/msg_1775722839_0b8d9dc6.jpg\"]','2026-04-09 02:20:39','2026-04-09 02:20:39',NULL),(18,4,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply',NULL,'2026-04-09 02:21:24','2026-04-09 02:21:24',NULL),(19,4,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-09 02:21:28','2026-04-09 02:21:28',NULL),(20,4,2,4,'Estimado residente, estamos investigando su problema y le mantendremos informado.','reply',NULL,'2026-04-09 02:21:31','2026-04-09 02:21:31',NULL),(21,6,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-13 22:20:10','2026-04-13 22:20:10',NULL),(22,7,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-16 14:00:28','2026-04-16 14:00:28',NULL),(23,7,2,11,'ok s','reply',NULL,'2026-04-16 14:03:56','2026-04-16 14:03:56',NULL),(24,7,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply','[\"writable/uploads/tickets/msg_1776370270_f8780890.jpg\"]','2026-04-16 14:11:10','2026-04-16 14:11:10',NULL),(25,7,2,11,'ya quefo ?','reply',NULL,'2026-04-16 14:24:39','2026-04-16 14:24:39',NULL),(26,7,2,4,'si','reply',NULL,'2026-04-16 14:26:12','2026-04-16 14:26:12',NULL),(27,7,2,4,'El problema ha sido resuelto. Por favor háganos saber si necesita algo más.','reply',NULL,'2026-04-16 14:29:15','2026-04-16 14:29:15',NULL),(28,7,2,4,'Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','reply',NULL,'2026-04-16 14:29:30','2026-04-16 14:29:30',NULL),(29,8,2,4,'El trabajo en su reporte ha comenzado. Le mantendremos informado.','reply',NULL,'2026-04-16 14:42:38','2026-04-16 14:42:38',NULL),(30,8,2,11,'','reply','[\"writable/uploads/tickets/msg_1776384004_ccadb8c9.pdf\"]','2026-04-16 18:00:04','2026-04-16 18:00:04',NULL),(31,8,2,11,'','reply','[\"writable/uploads/tickets/msg_1776384038_37ce5faa.jpg\"]','2026-04-16 18:00:38','2026-04-16 18:00:38',NULL),(32,8,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply',NULL,'2026-04-16 18:00:54','2026-04-16 18:00:54',NULL),(33,6,2,4,'Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','reply',NULL,'2026-04-16 18:06:26','2026-04-16 18:06:26',NULL),(34,5,2,4,'Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','reply',NULL,'2026-04-16 18:06:41','2026-04-16 18:06:41',NULL),(35,8,2,4,'Su reporte ha sido resuelto. Si tiene alguna otra inquietud, por favor háganoslo saber.','reply',NULL,'2026-04-16 21:55:05','2026-04-16 21:55:05',NULL),(36,9,2,11,'ok','reply',NULL,'2026-04-17 10:26:57','2026-04-17 10:26:57',NULL),(37,9,2,11,'hola','reply',NULL,'2026-04-17 15:36:44','2026-04-17 15:36:44',NULL),(38,9,2,11,'ohv','reply',NULL,'2026-04-17 20:27:06','2026-04-17 20:27:06',NULL),(39,9,2,4,'Necesitamos información adicional de su parte para proceder. ¿Podría proporcionarnos más detalles?','reply',NULL,'2026-04-17 20:27:27','2026-04-17 20:27:27',NULL),(40,9,2,11,'','reply','[\"writable/uploads/tickets/msg_1776566051_49cd137f.mp4\"]','2026-04-18 20:34:11','2026-04-18 20:34:11',NULL),(41,9,2,11,'cerrado','reply',NULL,'2026-04-18 20:34:40','2026-04-18 20:34:40',NULL),(42,9,2,11,'que hay','reply',NULL,'2026-04-20 20:51:08','2026-04-20 20:51:08',NULL),(43,9,2,4,'Estimado residente, estamos investigando su problema y le mantendremos informado.','reply',NULL,'2026-04-20 20:51:27','2026-04-20 20:51:27',NULL),(44,9,2,4,'oK','reply',NULL,'2026-04-21 08:30:29','2026-04-21 08:30:29',NULL),(45,9,2,11,'oj','reply',NULL,'2026-04-26 22:34:42','2026-04-26 22:34:42',NULL),(46,10,2,4,'hola','reply',NULL,'2026-04-27 14:33:40','2026-04-27 14:33:40',NULL),(47,10,2,4,'giica','reply',NULL,'2026-04-27 14:53:45','2026-04-27 14:53:45',NULL),(48,10,2,4,'hoivsb','reply',NULL,'2026-04-27 15:03:11','2026-04-27 15:03:11',NULL),(49,10,2,4,'hola s\nestamos verificando \ndamos a mañana','reply',NULL,'2026-04-27 15:11:27','2026-04-27 15:11:27',NULL),(50,10,2,4,'geaid sm\nvamos a escalar después','reply',NULL,'2026-04-27 15:21:12','2026-04-27 15:21:12',NULL),(51,10,2,11,'ojvd','reply',NULL,'2026-04-27 16:37:47','2026-04-27 16:37:47',NULL),(52,10,2,11,'ok \nkjs','reply',NULL,'2026-04-27 17:55:16','2026-04-27 17:55:16',NULL),(53,10,2,4,'','reply','[\"writable/uploads/tickets/msg_1777349831_f2b93956.jpg\"]','2026-04-27 22:17:11','2026-04-27 22:17:11',NULL),(54,10,2,4,'ok \ndamos continuidad','reply',NULL,'2026-04-27 22:17:13','2026-04-27 22:17:13',NULL),(55,10,2,4,'ohv','reply',NULL,'2026-04-27 22:42:45','2026-04-27 22:42:45',NULL);
/*!40000 ALTER TABLE `ticket_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_hash` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned DEFAULT NULL,
  `reported_by` bigint unsigned NOT NULL,
  `subject` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `priority` enum('low','medium','high','critical') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'medium',
  `assigned_to_type` enum('user','staff') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `assigned_to_id` bigint unsigned DEFAULT NULL,
  `status` enum('open','in_progress','resolved','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'open',
  `due_date` datetime DEFAULT NULL,
  `tags` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `media_urls` json DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ticket_hash` (`ticket_hash`),
  KEY `tickets_unit_id_foreign` (`unit_id`),
  KEY `tickets_reported_by_foreign` (`reported_by`),
  KEY `condominium_id_status_created_at` (`condominium_id`,`status`,`created_at`),
  CONSTRAINT `tickets_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_reported_by_foreign` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,'0190ccd51619df9cb381753c',2,NULL,1,'as','as','Mantenimiento','low','staff',2,'resolved',NULL,NULL,NULL,NULL,'2026-04-06 15:02:04','2026-04-06 19:17:09','2026-04-06 19:17:09'),(2,'bd58b1a046ebdf5e4923698f',2,NULL,4,'tat','tat','Mantenimiento','medium','staff',2,'resolved',NULL,NULL,NULL,NULL,'2026-04-06 15:11:49','2026-04-07 09:00:56',NULL),(3,'f3b213ef568ce74e9981f35d',2,NULL,4,'test','test','Seguridad','medium','staff',2,'in_progress',NULL,NULL,NULL,NULL,'2026-04-06 16:42:13','2026-04-06 17:53:28','2026-04-06 17:53:28'),(4,'fc319f0d9d0e6ca214193a3a',2,NULL,4,'Prueba de ticket ','Prueba de ticket ','Seguridad','critical','staff',2,'resolved','2026-04-30 23:59:59','Ewiqueta nuombre','Entrada','[\"writable/uploads/tickets/tk_1775524664_44ca986f.jpg\", \"writable/uploads/tickets/tk_1775524664_4c675014.jpg\"]','2026-04-06 19:17:44','2026-04-09 02:41:20','2026-04-09 02:41:20'),(5,'c0ef55ce7990d2557a39d871',2,NULL,1,'teas','teas','Seguridad','medium','user',4,'resolved',NULL,NULL,NULL,NULL,'2026-04-08 09:08:44','2026-04-16 18:06:41',NULL),(6,'549f5ae9263b8ab650a1b5dc',2,NULL,4,'tiCKET DE PRUEBA','tiCKET DE PRUEBA','Seguridad','medium','user',18,'resolved',NULL,NULL,NULL,'[\"writable/uploads/tickets/tk_1775721411_cf8ddfbc.jpg\"]','2026-04-09 01:56:51','2026-04-16 18:06:26',NULL),(7,'cc593bf80bc841a559f9b074',2,296,11,'orovlea en piso','orovlea en piso','Seguridad','medium','user',4,'resolved',NULL,NULL,NULL,'[\"writable/uploads/tickets/tk_1776369533_24ff836c.jpg\", \"writable/uploads/tickets/tk_1776369533_a95c19d7.jpg\", \"writable/uploads/tickets/tk_1776369533_cbb6e94f.jpg\"]','2026-04-16 13:58:53','2026-04-16 14:29:31',NULL),(8,'c04b8b2a782c75d797043dfa',2,296,11,'prueba video','prueba video','Ruido','medium',NULL,NULL,'resolved',NULL,NULL,NULL,'[\"writable/uploads/tickets/tk_1776372097_e773fa26.mp4\"]','2026-04-16 14:41:37','2026-04-16 21:55:06',NULL),(9,'10f7f3f7b809156b04f9f436',2,296,11,'no funciona luminaria','no funciona luminaria','Servicios','medium',NULL,NULL,'resolved',NULL,NULL,NULL,'[\"writable/uploads/tickets/tk_1776410786_9d19e250.jpg\"]','2026-04-17 01:26:26','2026-04-26 22:46:54',NULL),(10,'70f373e6cfdb3fabffafa38d',2,296,11,'nuevo el ptet','nuevo el ptet','Seguridad','medium',NULL,NULL,'in_progress',NULL,NULL,NULL,'[\"writable/uploads/tickets/tk_1777318191_fd608593.jpg\"]','2026-04-27 13:29:51','2026-04-27 14:33:40',NULL);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_notes`
--

DROP TABLE IF EXISTS `unit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit_notes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` int unsigned NOT NULL,
  `condominium_id` int unsigned NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_notes`
--

LOCK TABLES `unit_notes` WRITE;
/*!40000 ALTER TABLE `unit_notes` DISABLE KEYS */;
INSERT INTO `unit_notes` VALUES (3,129,2,1,'Nota de prueba','2026-03-12 16:12:43','2026-03-12 16:12:43');
/*!40000 ALTER TABLE `unit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned DEFAULT NULL,
  `unit_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `floor` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` enum('house','apartment','commercial','lot') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'house',
  `area` decimal(10,2) DEFAULT NULL,
  `indiviso_percentage` decimal(5,2) DEFAULT NULL,
  `maintenance_fee` decimal(10,2) DEFAULT '0.00',
  `initial_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fee_start_month` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `occupancy_type` enum('owner_occupied','long_term_rent','short_term_rent','vacant') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'owner_occupied',
  `hash_id` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `condominium_id_section_id_unit_number` (`condominium_id`,`section_id`,`unit_number`),
  UNIQUE KEY `hash_id` (`hash_id`),
  KEY `units_section_id_foreign` (`section_id`),
  KEY `condominium_id` (`condominium_id`),
  CONSTRAINT `units_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `units_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=493 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (296,2,1,'A-100','1','apartment',0.00,0.00,5000.00,0.00,'2026-03','2026-03-12 17:55:35','2026-04-18 16:25:02','owner_occupied','cdcf26c159547991ef12696f'),(297,2,1,'A-101','1','house',0.00,0.00,5000.00,0.00,'2026-03','2026-03-12 17:55:35','2026-04-09 12:27:54','owner_occupied','f33bcd8d9ccbfcaa06c3e3e3'),(419,2,1,'A-102','1','apartment',0.00,0.00,5000.00,0.00,'2026-04','2026-03-13 23:21:33','2026-04-08 19:43:07','owner_occupied','db529602406e0533e70b3bbd'),(420,2,1,'A-103','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 19:43:07','owner_occupied','9532806373684be76ff3e271'),(421,2,1,'A-104','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 19:43:07','owner_occupied','a197848cd45486786153242c'),(422,2,1,'A-105','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 19:43:07','owner_occupied','f24ffcbe4f1e0c049c33e697'),(423,2,2,'B-100','1','apartment',0.00,0.00,5000.00,0.00,'2026-03','2026-03-13 23:21:33','2026-04-08 14:44:58','owner_occupied','1df91c5c58fdb9229ccdd740'),(424,2,2,'B-101','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 14:44:58','owner_occupied','5b8e1a81c1df4f408e6067e2'),(425,2,2,'B-102','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 14:44:58','owner_occupied','f2242870b7fae084496d3310'),(426,2,2,'B-103','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 14:44:58','owner_occupied','a4e8675d1629b1773a9b55d0'),(427,2,2,'B-104','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 14:44:58','owner_occupied','ea624d8d0a29170b00ccbfc6'),(428,2,2,'B-105','1','apartment',0.00,0.00,5000.00,0.00,NULL,'2026-03-13 23:21:33','2026-04-08 14:44:58','owner_occupied','13820837d426bbe924677b9a'),(429,2,3,'C-101','','apartment',70.00,0.00,5000.00,0.00,'2026-04','2026-04-08 13:04:53','2026-04-08 14:45:07','owner_occupied','fe9e6415ddf6de1cc5daaec6'),(456,5,5,'A101',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:35','owner_occupied','8c898245893b39e118f83bb0'),(457,5,5,'A105',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:35','owner_occupied','032aa541aa464d17cf9fc874'),(458,5,5,'A106',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:35','owner_occupied','95e995b0e4b1e45624467e93'),(459,5,6,'B101',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:48','owner_occupied','5efe48fb79e42e4159857c75'),(460,5,6,'B102',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:48','owner_occupied','c0d96f393d06b8106aa4e31f'),(461,5,6,'B103',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:48','owner_occupied','ec5d5b2c50ebe0cec927266c'),(462,5,6,'B104',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:48','owner_occupied','aa26700874b6a535a247acb9'),(463,5,6,'B105',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:48','owner_occupied','d39c09dd06176886f58462e4'),(464,5,6,'B106',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:48','owner_occupied','eb3a7e9d84249fc68df9116a'),(465,5,5,'A102',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:35','owner_occupied','8ed41f8b55ea3d80fa07463a'),(466,5,5,'A103',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:35','owner_occupied','3c781a10f5ee20f695c75cd8'),(467,5,5,'A104',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:02:49','2026-04-20 22:06:35','owner_occupied','ff81f8f41c50bce6c6032795'),(468,6,NULL,'1',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','a9fad733314cb64801ebe646'),(469,6,NULL,'2',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','402695bba05dc0e693cd7646'),(470,6,NULL,'3',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','0db3420e8d605e69835a7dbf'),(471,6,NULL,'4',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','26857f1ec101d0308e0ecd80'),(472,6,NULL,'5',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','4ec0fc24c949b688f79bd55c'),(473,6,NULL,'6',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','ddacfa0891d79b2fb0660f7c'),(474,6,NULL,'7',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','57a20b3c35d6cea06973dbc1'),(475,6,NULL,'8',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','a9f3591b0715a6666febccb2'),(476,6,NULL,'9',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','37e5a5eafe3cd0b87b605b18'),(477,6,NULL,'10',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','988f9b05f8ff5b1c1c4094e0'),(478,6,NULL,'11',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','bb127880b5cc54699f76e8c2'),(479,6,NULL,'12',NULL,'apartment',NULL,NULL,4000.00,0.00,NULL,'2026-04-20 20:29:44','2026-04-20 20:29:44','owner_occupied','a71f403ef2febebbf3740052'),(480,8,NULL,'A-100',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','c584be00e039a1936cff78e0'),(481,8,NULL,'A-101',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','081d89c170cf1e69847a62d2'),(482,8,NULL,'A-102',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','c3340c5a7c84d97c492435f4'),(483,8,NULL,'A-103',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','c3105c323e5cf46407bc6d00'),(484,8,NULL,'A-104',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','1205c308d878f8f17795b576'),(485,8,NULL,'A-105',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','db88fe6d59ad216808750d1a'),(486,8,NULL,'B-100',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','df331a717560e11565c6199a'),(487,8,NULL,'B-101',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','95e77c3df8045544e84814f1'),(488,8,NULL,'B-102',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','ac6709dc70ba2c9522b76e4a'),(489,8,NULL,'B-103',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','5d566999b5bff4c00b4f4908'),(490,8,NULL,'B-104',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','2afa7c86263ef2abbb62a3d2'),(491,8,NULL,'B-105',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','99c5c4dca91547aad893a629'),(492,8,NULL,'C-101',NULL,'apartment',NULL,NULL,5000.00,0.00,NULL,'2026-04-27 13:07:13','2026-04-27 13:07:13','owner_occupied','2b1fd0df77025262a274348a');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_condominium_roles`
--

DROP TABLE IF EXISTS `user_condominium_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_condominium_roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `condominium_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `is_owner` tinyint unsigned DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_condominium_id_role_id` (`user_id`,`condominium_id`,`role_id`),
  KEY `user_condominium_roles_role_id_foreign` (`role_id`),
  KEY `condominium_id_user_id` (`condominium_id`,`user_id`),
  CONSTRAINT `user_condominium_roles_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_condominium_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_condominium_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_condominium_roles`
--

LOCK TABLES `user_condominium_roles` WRITE;
/*!40000 ALTER TABLE `user_condominium_roles` DISABLE KEYS */;
INSERT INTO `user_condominium_roles` VALUES (1,4,2,2,1,'2026-03-12 03:36:16',NULL),(2,5,2,4,0,'2026-03-12 03:38:58',NULL),(3,6,2,3,0,'2026-03-12 03:38:58',NULL),(7,11,2,4,0,NULL,NULL),(8,12,2,4,0,NULL,NULL),(10,14,2,3,0,'2026-04-06 12:18:04','2026-04-06 12:18:04'),(17,20,2,3,0,'2026-04-17 21:25:28','2026-04-17 21:25:28'),(18,4,5,2,1,'2026-04-20 20:02:49',NULL),(19,4,6,2,1,'2026-04-20 20:29:44',NULL),(24,23,2,4,0,NULL,NULL),(26,25,2,2,0,'2026-04-21 08:39:07',NULL),(29,1,0,1,0,NULL,NULL),(30,26,7,2,1,'2026-04-26 23:12:42',NULL),(31,4,8,2,1,'2026-04-27 13:07:13',NULL),(32,27,8,3,0,'2026-04-27 14:27:08','2026-04-27 14:27:08');
/*!40000 ALTER TABLE `user_condominium_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('active','inactive','banned') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Super','Admin','superadmin@condominet.local','$2y$10$FEg09VCK61U.cHbW46O/cOLu.sCUi8XdsmlmJF/ykQ3GRYJXgE9Lu',NULL,'1777262818_dae4cb73636a6057bec3.jpg','active','2026-03-11 18:19:57','2026-04-26 22:06:58',NULL),(4,'Daniel','Zubiri','admin@demo.com','$2y$10$LFYNnw79kIthXhB6Xd7Cyu6ORbTAhUfiKQOrIVdQ7kxCeOJZbTTg6','5518277857','1777351138_fc9a3e69da17fd5cefff.jpg','active','2026-03-12 03:36:16','2026-04-27 22:38:58',NULL),(5,'Jane','Tenant','resident@demo.com','$2y$10$W5itvTsVoDvQ51v0xulAXuEeCcHJ8XfqN9Bu3lGP2krH3haUv7a/m','5551234567',NULL,'active','2026-03-12 03:38:58','2026-03-12 03:38:58',NULL),(6,'Officer','Vigilance','guard@demo.com','$2y$10$W5itvTsVoDvQ51v0xulAXuEeCcHJ8XfqN9Bu3lGP2krH3haUv7a/m',NULL,NULL,'active','2026-03-12 03:38:58','2026-03-12 03:38:58',NULL),(7,'Daniel','','daniel2@gmail.com','$2y$2y$10$k7XCb4oWlsK5ohW4lfBZa.5kNJ/2gO6B2P2TEAbHhyiRKukRNQ1QO','5518278371',NULL,'active','2026-03-12 05:20:54','2026-03-12 05:20:54',NULL),(8,'Daniel','ojeda','dojeda@didecom.com','$2y$10$g36IsD19hLcQ.O4kJAeOoeXXikkGY9vVQb8ybgY.cOyZKELEINqBi',NULL,NULL,'active','2026-03-13 00:57:50','2026-03-13 00:57:50',NULL),(9,'ethan','','ethan@gmail.com','$2y$10$bh3tJM9TYIW3VjWDI7UQ4u.mNUhJXE.Ip5QI1ZRoTM8JMYd74w25y','55647748747',NULL,'active','2026-03-13 01:49:50','2026-03-13 01:49:50',NULL),(10,'Angeles','Lopez','angeles@gmail.com','$2y$10$JI1Jpbr1tARK1A4SLQe0BeVzPjsGuB3TrzyHlZj6VpEVz/zEx6eSe','55447714747','1776364589_afc12710af69ef115fd8.jpg','active','2026-03-13 02:28:39','2026-04-16 12:36:29',NULL),(11,'Benjamin','Lopez','benji@gmail.com','$2y$10$aIAoMF.46BLeqKW0Kp6UWuVMSFOmHrXiLUfjslMgEKrAHZPj.oB82','5512348888','1776309910_d708865733a46ae710da.jpg','active','2026-03-13 04:50:55','2026-04-20 20:38:47',NULL),(12,'apio','quijano','opi@gmail.com','$2y$10$PS1uzWJnbzU..nMHaQY.EeWilNOYRnxZjSHNliyNEr3mE51O9lhHu','5554784845',NULL,'active','2026-03-13 05:14:11','2026-03-13 05:14:11',NULL),(13,'AxisCondo','Caseta','caseta-8703@axiscondo.mx','$2y$10$igsfpERMKIpqh3DYn7N1ferszMAUwDuotWBPqI/Y4S3r5GsNN.3kq',NULL,NULL,'inactive','2026-03-30 13:37:00','2026-04-06 12:29:43',NULL),(14,'AxisCondo','Caseta 3','caseta-3-9268@axiscondo.mx','$2y$10$TDQrbATiit3O8AGpfn19MemQ0GxBmow7l.rJshDsp3D6OrpI8xjwm',NULL,NULL,'active','2026-04-06 12:18:04','2026-04-09 18:20:02',NULL),(17,'Marcos','Zubiri','marcos@gmai.com','$2y$10$htyEv4M8en.QptHI1DL8J.8g/WfTLMUC8LfeRmpfcbY2hc0uGDmGK',NULL,NULL,'active','2026-04-08 18:05:31','2026-04-08 18:05:31',NULL),(18,'Angeles|','lopez','ange@gmai.com','$2y$10$gNw3S6bY2zgMevn9cUspuuTQYQs6Xgq/ZN7vAx/cIziwFEx40cDVy',NULL,NULL,'active','2026-04-08 18:17:06','2026-04-08 18:17:06',NULL),(19,'mario','zubiri','mario666@gmail.com','$2y$10$NtH3zpgtG665q8YrNqJ04Ok.LVNh8M87/BvxNAnXCa4Wg5P5XAIwm',NULL,NULL,'active','2026-04-12 13:57:27','2026-04-12 13:57:27',NULL),(20,'AxisCondo','CASETA 7','caseta-7-3200@axiscondo.mx','$2y$10$AIQqwc8e85s/iBeKTUPRHu4oT289lR4Mlk.puHzU./sSCQrazHHJe',NULL,NULL,'active','2026-04-17 21:25:28','2026-04-17 21:25:28',NULL),(21,'Antonio','Cuellar','acuellar@gmai.com','$2y$10$/Z5qa5QhZs7PzkNoa0a02.ltSQZ4J.OEkMZ2MnBw/dJ93Lt8WAdHm','5535252858','1776745445_b27d4ca72cecb85c367c.jpg','active','2026-04-20 22:17:37','2026-04-20 22:31:57',NULL),(22,'Araceli','','araceli@gmail.com','$2y$10$k7XCb4oWlsK5ohW4lfBZa.5kNJ/2gO6B2P2TEAbHhyiRKukRNQ1QO',NULL,NULL,'active','2026-04-20 23:25:21','2026-04-20 23:25:21',NULL),(23,'ARACELI','','areceli@gmail.com','$2y$10$k7XCb4oWlsK5ohW4lfBZa.5kNJ/2gO6B2P2TEAbHhyiRKukRNQ1QO',NULL,NULL,'active','2026-04-20 23:57:02','2026-04-20 23:57:02',NULL),(24,'danielo','','daniel@dani.com','$2y$10$hd6EUyZDCCgdIsqbKXyNQucDowJ3CGPrOsTm8emXFsL3xgH9qpJna',NULL,NULL,'active','2026-04-20 23:59:54','2026-04-20 23:59:54',NULL),(25,'CRISTINA','RESENDIZ','cris@gmai.com','$2y$10$5nNgA0qNZDfHasw5pDqvROGfXi3qCy5nunpwCdEs5aIfpQGGzzYWe',NULL,NULL,'active','2026-04-21 08:39:07','2026-04-21 08:39:07',NULL),(26,'JUAN','OJEDA','juan666@gmai.com','$2y$10$TxaH/208MycY.H8dE4zsU.4U5I/3/Szhhq7AGYD6o9n.XKmVo6oo.',NULL,NULL,'active','2026-04-26 23:12:42','2026-04-26 23:12:42',NULL),(27,'AxisCondo','CASTA FLORE','casta-flore-2085@axiscondo.mx','$2y$10$9BSvlVYP0E4iExp53Hxg4eto3KJTQD/e3BucELlFAsgnluIZBUM2u',NULL,NULL,'active','2026-04-27 14:27:08','2026-04-27 14:27:08',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_invitations`
--

DROP TABLE IF EXISTS `visitor_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitor_invitations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `unit_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `visitor_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `expected_arrival_date` date NOT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `status` enum('pending','arrived','cancelled','expired') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visitor_invitations_unit_id_foreign` (`unit_id`),
  KEY `visitor_invitations_created_by_foreign` (`created_by`),
  KEY `condominium_id_expected_arrival_date` (`condominium_id`,`expected_arrival_date`),
  CONSTRAINT `visitor_invitations_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visitor_invitations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visitor_invitations_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_invitations`
--

LOCK TABLES `visitor_invitations` WRITE;
/*!40000 ALTER TABLE `visitor_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitor_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitors`
--

DROP TABLE IF EXISTS `visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `condominium_id` bigint unsigned NOT NULL,
  `full_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `document_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `document_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `condominium_id_document_number` (`condominium_id`,`document_number`),
  CONSTRAINT `visitors_condominium_id_foreign` FOREIGN KEY (`condominium_id`) REFERENCES `condominiums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitors`
--

LOCK TABLES `visitors` WRITE;
/*!40000 ALTER TABLE `visitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitors` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-29  2:00:01
